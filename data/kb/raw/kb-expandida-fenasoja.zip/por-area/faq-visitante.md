# KB expandida — FAQ geral do visitante (FAQ)

Gerado em 2026-10-17. Índice geral: [../kb-expandida.md](../kb-expandida.md). JSON da área: [faq-visitante.json](faq-visitante.json).

**7 perguntas canônicas · 34 perguntas no total (canônicas + variantes).**

| confirmado | parcial | sem_fonte | conflito | dinâmico |
|---|---|---|---|---|
| 4 | 0 | 3 | 0 | 0 |

| conceito | dado | orientação |
|---|---|---|
| 0 | 2 | 5 |

**Por tipo de fonte:** Curadoria manual sobre fontes oficiais: 7

## Subcategorias

| Subcategoria | Entradas |
|---|---|
| Planejamento | 3 |
| Regras do parque | 3 |
| Saúde e conforto | 1 |

## Entradas

## Planejamento

### FAQ-GER-002 — Como chegar em Santa Rosa para a Fenasoja?

**Variantes:** Como ir pra Santa Rosa? · como chegar fenasoja · como chega em santa rosa rs · Distância de Porto Alegre a Santa Rosa

Santa Rosa fica no Noroeste do Rio Grande do Sul, a cerca de 490 km de Porto Alegre. As rotas rodoviárias, aeroportos mais próximos e opções de hospedagem estão na KB Fenasoja e no site oficial da feira, que deve ser consultado para informações atualizadas.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* VIS-001, VIS-002, SR-001
*Fontes:* [Fenasoja – A região](https://fenasoja.com.br/a-regiao/) (acesso 2026-10-17); [Fenasoja – Informações Turísticas](https://fenasoja.com.br/informacoes-turisticas/) (acesso 2026-10-17)
*Notas:* Encaminhar para VIS-001/VIS-002 da KB Fenasoja.

### FAQ-GER-003 — Quando será a próxima Fenasoja?

**Variantes:** Quando é a Fenasoja 2028? · proxima fenasoja data · qdo vai ser a fenasoja · Data da Fenasoja

A próxima Fenasoja será de 28 de abril a 7 de maio de 2028, no Parque de Exposições de Santa Rosa. Programação, atrações e ingressos ainda devem ser confirmados no site oficial fenasoja.com.br.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* F28-001, F28-007, F28-008
*Fontes:* [Fenasoja – Definidas data e comissão central da Fenasoja 2028](https://fenasoja.com.br/portal-oficial/geral/definidas-data-e-comissao-central-da-fenasoja-2028/) (acesso 2026-10-17)
*Notas:* Resposta espelha F28-001 da KB Fenasoja; a KB Fenasoja tem prioridade.

### FAQ-GER-004 — Quanto custa o estacionamento da Fenasoja?

**Variantes:** Preço do estacionamento Fenasoja · estacionamento fenasoja valor · qto custa pra estacionar na feira · Tem estacionamento na Fenasoja?

Na Fenasoja 2026, o estacionamento interno custou R$ 25 por veículo, com operação especializada. Os valores de 2028 ainda não foram divulgados; o bot deve informar o dado de 2026 como referência e indicar o site oficial.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-04-27 · *relevância Fenasoja:* alta
*KB Fenasoja:* F26-003, F26-002
*Fontes:* [Fenasoja – Estacionamento da Fenasoja 2026 terá custo de R$ 25 (27/04/2026)](https://fenasoja.com.br/portal-oficial/bilheteria/estacionamento-da-fenasoja-2026-tera-custo-de-r-25-e-operacao-especializada/) (acesso 2026-10-17)
*Notas:* Espelha F26-003 da KB Fenasoja.

## Regras do parque

### FAQ-SF-001 — Posso levar meu cachorro na Fenasoja?

**Variantes:** Pode entrar com pet na Fenasoja? · cachorro na fenasoja · posso leva meu dog na feira? · Animais de estimação são permitidos?

SEM FONTE CONFIRMADA. Não encontramos nas fontes oficiais consultadas uma regra sobre entrada de animais de estimação no parque. A orientação é perguntar à organização pelos contatos oficiais antes da visita.

*kind:* `orientação` · *status:* `sem_fonte` · *as_of:* — · *relevância Fenasoja:* média
*KB Fenasoja:* VIS-005, F26-013
*Fontes:* [Fenasoja – Contato](https://fenasoja.com.br/contato/) (acesso 2026-10-17)
*Lacunas:* Regra de pets no parque não localizada.

### FAQ-SF-002 — Onde fica o achados e perdidos da Fenasoja?

**Variantes:** Perdi um objeto na Fenasoja · achados e perdidos fenasoja · perdi meu celular na feira · Onde procurar documento perdido?

SEM FONTE CONFIRMADA. As fontes consultadas não informam o local de achados e perdidos. O visitante deve procurar a administração do parque ou os contatos oficiais da organização.

*kind:* `orientação` · *status:* `sem_fonte` · *as_of:* — · *relevância Fenasoja:* média
*KB Fenasoja:* VIS-005
*Fontes:* [Fenasoja – Contato](https://fenasoja.com.br/contato/) (acesso 2026-10-17)
*Lacunas:* Local de achados e perdidos não localizado.

### FAQ-SF-003 — Posso levar comida e bebida para a Fenasoja?

**Variantes:** Me tira uma dúvida: posso levar comida e bebida para a Fenasoja? · posso levar comida bebida fenasoja? · posso levar comida e bebida pra a fenasja

SEM FONTE CONFIRMADA. Não localizamos nas fontes consultadas regra sobre entrada com alimentos e bebidas no parque. Confirmar com a organização antes da visita.

*kind:* `orientação` · *status:* `sem_fonte` · *as_of:* — · *relevância Fenasoja:* média
*KB Fenasoja:* VIS-005
*Fontes:* [Fenasoja – Contato](https://fenasoja.com.br/contato/) (acesso 2026-10-17)
*Lacunas:* Regra sobre alimentos/bebidas não localizada.

## Saúde e conforto

### FAQ-GER-001 — Como se proteger do calor em uma feira ao ar livre?

**Variantes:** Dicas para o calor na feira · como evitar insolação · ta mt quente, oq fazer · Protetor solar na Fenasoja

O Ministério da Saúde recomenda evitar a exposição ao sol entre 10h e 16h, usar roupas leves e claras, chapéu e protetor solar com FPS acima de 30, beber água ao longo do dia mesmo sem sede e moderar o consumo de bebidas alcoólicas. Sinais como tontura, dor de cabeça, náusea e pele muito quente podem indicar problema causado pelo calor e exigem procurar atendimento.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* VIS-008
*Fontes:* [Ministério da Saúde (BVS) – Como se proteger das altas temperaturas](https://bvsms.saude.gov.br/saiba-como-se-proteger-das-altas-temperaturas-e-da-baixa-umidade-do-ar-no-pais/) (acesso 2026-10-17); [Ministério da Saúde – Insolação](https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/i/insolacao) (acesso 2026-10-17)
*Notas:* Na Fenasoja, apontar postos de saúde/brigada conforme KB Fenasoja (VIS-008).
