# KB expandida — Mercado e economia (MERC)

Gerado em 2026-10-17. Índice geral: [../kb-expandida.md](../kb-expandida.md). JSON da área: [mercado.json](mercado.json).

**105 perguntas canônicas · 572 perguntas no total (canônicas + variantes).**

| confirmado | parcial | sem_fonte | conflito | dinâmico |
|---|---|---|---|---|
| 95 | 1 | 0 | 0 | 9 |

| conceito | dado | orientação |
|---|---|---|
| 82 | 21 | 2 |

**Por tipo de fonte:** Curadoria manual sobre fontes oficiais: 36; Wikipédia (pt) – verbete: 69

## Subcategorias

| Subcategoria | Entradas |
|---|---|
| Comércio exterior e logística | 28 |
| Economia | 20 |
| Commodities e bolsas | 12 |
| Crédito rural e Plano Safra | 11 |
| Preços e cotações (dinâmico) | 11 |
| Crédito e seguro | 9 |
| Exportações e China | 5 |
| Títulos do agronegócio | 3 |
| Seguro rural | 2 |
| Cooperativismo | 2 |
| Política agrícola | 1 |
| Agricultura familiar | 1 |

## Entradas

## Comércio exterior e logística

### MERC-WK-0043 — O que é Exportação?

**Variantes:** Exportação: o que significa? · Me explica o que é Exportação · oq é exportacao · Exportação? · Defina Exportação

Exportação é a saída de bens, produtos e serviços do país de origem. Esta operação pode envolver pagamento, como venda de produtos, ou não, como nas doações.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Exportação](https://pt.wikipedia.org/wiki/Exporta%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Exportação" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0044 — O que é Importação?

**Variantes:** Importação: o que significa? · Me explica o que é Importação · oq é importacao · Importação? · Defina Importação

Importação é o processo comercial e fiscal que consiste em trazer um bem, que pode ser um produto ou um serviço, do exterior para o país de referência. O procedimento deve ser efetuado via nacionalização do produto ou serviço, que ocorre a partir de procedimentos burocráticos ligados à Receita do país de destino, bem como da alfândega, durante o descarregamento e entrega, que pode se dar por via aérea, marítima, rodoviária ou ferroviária. Quando mais de um tipo de transporte é utilizado para entrega, chamamos de transporte multimodal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Importação](https://pt.wikipedia.org/wiki/Importa%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Importação" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0045 — O que é Organização Mundial do Comércio?

**Variantes:** Organização Mundial do Comércio: o que significa? · Me explica o que é Organização Mundial do Comércio · oq é organizacao mundial do comercio · Organização Mundial do Comércio? · Defina Organização Mundial do Comércio

Organização Mundial do Comércio (OMC) é uma instituição criada com o objetivo de supervisionar e liberalizar o comércio internacional. Criada oficialmente em 1 de janeiro de 1995, com o Acordo de Marraquexe, em substituição ao Acordo Geral de Tarifas e Comércio (GATT), que começara em 1947. A organização lida com a regulamentação do comércio entre os seus países-membros; fornece uma estrutura para negociação e formalização de acordos comerciais e um processo de resolução de conflitos que visa reforçar a adesão dos participantes aos acordos da OMC, que são assinados pelos representantes dos governos dos Estados-membros e ratificados pelos parlamentos nacionais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Organização Mundial do Comércio](https://pt.wikipedia.org/wiki/Organiza%C3%A7%C3%A3o_Mundial_do_Com%C3%A9rcio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Organização Mundial do Comércio" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0046 — O que é Mercosul?

**Variantes:** Mercosul: o que significa? · Me explica o que é Mercosul · oq é mercosul · Mercosul? · Defina Mercosul

Mercado Comum do Sul é uma organização intergovernamental regional sul-americana fundada a partir do Tratado de Assunção em 26 de março de 1991 e com sede em Montevidéu. Trata-se de um dos maiores blocos econômicos em produto interno bruto (PIB) e o maior produtor de alimentos do mundo. Seus membros plenos são Argentina, Bolívia, Brasil, Paraguai, Uruguai e Venezuela, porém esta última está suspensa desde 1 de dezembro de 2016. Já Chile, Colômbia, Equador, Guiana, Peru, Suriname e Panamá são países associados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*KB Fenasoja:* VIS-003
*Fontes:* [Wikipédia (pt) – Mercado Comum do Sul](https://pt.wikipedia.org/wiki/Mercado_Comum_do_Sul) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Mercado Comum do Sul" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0047 — O que é Acordo de Associação Mercosul-União Europeia?

**Variantes:** Acordo de Associação Mercosul-União Europeia: o que significa? · Me explica o que é Acordo de Associação Mercosul-União Europeia · oq é acordo de associacao mercosul-uniao europeia · Acordo de Associação Mercosul-União Europeia? · Defina Acordo de Associação Mercosul-União Europeia

Acordo de Associação Mercosul-União Europeia é um tratado com negociações concluídas em 28 de junho de 2019, assinado em 17 de janeiro de 2026 e dependente de ratificação pelos parlamentos dos países dos dois blocos. Ele foi negociado entre os membros do Mercado Comum do Sul (Mercosul) e da União Europeia (UE) para regular o diálogo político, a cooperação e práticas de livre comércio, se configurando também como acordo de livre comércio. A União Europeia é o segundo maior parceiro comercial do Mercosul. A corrente comercial entre os dois grupos de países foi de mais de 90 bilhões de dólares no ano de 2018.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Acordo de Associação Mercosul-União Europeia](https://pt.wikipedia.org/wiki/Acordo_de_Associa%C3%A7%C3%A3o_Mercosul-Uni%C3%A3o_Europeia) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Acordo de Associação Mercosul-União Europeia" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0048 — O que é China?

**Variantes:** China: o que significa? · Me explica o que é China · oq é china · China? · Defina China

É uma república popular socialista unipartidária. Na constituição, descreve-se como um sistema multipartidário de cooperação e consulta política sob a liderança do Partido Comunista da China e como uma "ditadura democrática popular liderada pela classe trabalhadora e baseada na aliança de trabalhadores e camponeses". Tem jurisdição sobre vinte e duas províncias, cinco regiões autônomas (Xinjiang, Mongólia Interior, Tibete, Ningxia e Quancim), quatro municípios (Pequim, Tianjin, Xangai e Xunquim) e duas Regiões Administrativas Especiais com relativa autonomia (Hong Kong e Macau). A capital da RPC é Pequim.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – China](https://pt.wikipedia.org/wiki/China) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "China" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0049 — O que são Relações entre Brasil e China?

**Variantes:** Relações entre Brasil e China: o que significa? · Me explica o que são Relações entre Brasil e China · oq sao relacoes entre brasil e china · Relações entre Brasil e China? · Defina Relações entre Brasil e China

As relações entre o Brasil e a China são relações diplomáticas estabelecidas hoje, entre a República Federativa do Brasil e a República Popular da China. As relações entre os dois estados começaram no início do século XIX e continuaram até ao ano de 1949, quando foram interrompidas pela criação da República Popular da China. Em 1974, 25 anos depois das últimas relações, no governo do general Ernesto Geisel da ditadura militar no Brasil, houve um acordo sobre a criação e funcionamento de uma embaixada do Brasil na cidade de Pequim, China e de uma embaixada chinesa na capital federal, Brasília, e as relações entre os países foram normalizadas e reafirmadas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Relações entre Brasil e China](https://pt.wikipedia.org/wiki/Rela%C3%A7%C3%B5es_entre_Brasil_e_China) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Relações entre Brasil e China" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0050 — O que é Ministério da Agricultura e Pecuária?

**Variantes:** Ministério da Agricultura e Pecuária: o que significa? · Me explica o que é Ministério da Agricultura e Pecuária · oq é ministerio da agricultura e pecuaria · Ministério da Agricultura e Pecuária? · Defina Ministério da Agricultura e Pecuária

O Ministério da Agricultura e Pecuária (também conhecido por seu acrônimo MAPA) é um ministério do Poder Executivo do Brasil cuja competência é formular e implementar as políticas para o desenvolvimento da agropecuária e do agronegócio, integrando os aspectos de mercados tecnológicos, organizacionais e ambientais, para o atendimento dos consumidores do país e do exterior, promovendo segurança alimentar, geração de renda e emprego, redução das desigualdades e inclusão social. O MAPA exerce suas atividades nos estados brasileiros através das Superintendências Federais de Agricultura (SFAs).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Ministério da Agricultura e Pecuária](https://pt.wikipedia.org/wiki/Minist%C3%A9rio_da_Agricultura_e_Pecu%C3%A1ria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Ministério da Agricultura e Pecuária" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0051 — O que é Ministério do Desenvolvimento Agrário e Agricultura Familiar?

**Variantes:** Ministério do Desenvolvimento Agrário e Agricultura Familiar: o que significa? · Me explica o que é Ministério do Desenvolvimento Agrário e Agricultura Familiar · oq é ministerio do desenvolvimento agrario e agricultura familiar · Ministério do Desenvolvimento Agrário e Agricultura Familiar? · Defina Ministério do Desenvolvimento Agrário e Agricultura Familiar

Ministério do Desenvolvimento Agrário e Agricultura Familiar (MDA) é um ministério no Governo Federal responsável pelas ações de reforma agrária, regularização fundiária, regularização de territórios quilombolas, cadastro de imóveis rurais e educação do campo. O órgão tem ainda como competências a promoção da política agrícola, assistência técnica, associativismo, cooperativismo e outras ações destinadas à agricultura familiar e desenvolvimento rural sustentável desse segmento social.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Ministério do Desenvolvimento Agrário e Agricultura Familiar](https://pt.wikipedia.org/wiki/Minist%C3%A9rio_do_Desenvolvimento_Agr%C3%A1rio_e_Agricultura_Familiar) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Ministério do Desenvolvimento Agrário e Agricultura Familiar" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0052 — O que é Companhia Nacional de Abastecimento?

**Variantes:** Companhia Nacional de Abastecimento: o que significa? · Me explica o que é Companhia Nacional de Abastecimento · oq é companhia nacional de abastecimento · Companhia Nacional de Abastecimento? · Defina Companhia Nacional de Abastecimento

A Companhia Nacional de Abastecimento (Conab) é uma empresa pública brasileira vinculada ao Ministério do Desenvolvimento Agrário e Agricultura Familiar (MDA). Exerce, principalmente, o papel do estoque regulador de alimentos e de auxílio à agricultura familiar e ao campesinato no controle das oscilações na renda destes e para lhes assegurar uma remuneração mínima.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Companhia Nacional de Abastecimento](https://pt.wikipedia.org/wiki/Companhia_Nacional_de_Abastecimento) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Companhia Nacional de Abastecimento" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0053 — O que é logística?

**Variantes:** Logística: o que significa? · Me explica o que é logística · oq é logistica · logística? · Defina logística

A logística (gr. logistikḗ, f.fem. de logistikós,ḗ,ón 'relativo ao cálculo; que diz respeito ao raciocínio') é uma especialidade da administração e engenharia responsável por prover recursos e informações para a execução de todas as atividades de uma organização. Sendo uma especialidade da administração que visa a suprir recursos, ela envolve também a aplicação de conhecimentos de outras áreas como a engenharia, economia, contabilidade, estatística, marketing, tecnologia e recursos humanos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Logística](https://pt.wikipedia.org/wiki/Log%C3%ADstica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Logística" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0054 — O que é Porto de Rio Grande?

**Variantes:** Porto de Rio Grande: o que significa? · Me explica o que é Porto de Rio Grande · oq é porto de rio grande · Porto de Rio Grande? · Defina Porto de Rio Grande

O Porto de Rio Grande é um porto localizado na margem direita do canal do Norte, que liga a Lagoa dos Patos ao Oceano Atlântico, no município de Rio Grande, no estado do Rio Grande do Sul, no Brasil. A barra do porto é mantida aberta graças a dois molhes construídos na boca do canal de acesso. No ano de 2009, o Porto movimentou cerca de 150 milhões de toneladas, o equivalente a 3% de toda a movimentação nacional, fazendo, deste porto, o terceiro principal porto do Brasil.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Porto de Rio Grande](https://pt.wikipedia.org/wiki/Porto_de_Rio_Grande) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Porto de Rio Grande" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0055 — O que é Porto de Paranaguá?

**Variantes:** Porto de Paranaguá: o que significa? · Me explica o que é Porto de Paranaguá · oq é porto de paranagua · Porto de Paranaguá? · Defina Porto de Paranaguá

O Porto de Paranaguá, também conhecido como Porto Dom Pedro II, é um porto localizado na cidade de Paranaguá, no estado do Paraná. É o maior porto exportador de produtos agrícolas do Brasil, com destaque para a soja em grão e o farelo de soja. No ano de 2007, o Porto de Paranaguá, movimentou 38,5 milhões de toneladas e gerou uma receita cambial de US$ 11,8 bilhões. O porto está aberto a turistas, estudantes e empresários.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Porto de Paranaguá](https://pt.wikipedia.org/wiki/Porto_de_Paranagu%C3%A1) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Porto de Paranaguá" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0056 — O que é Porto de Santos?

**Variantes:** Porto de Santos: o que significa? · Me explica o que é Porto de Santos · oq é porto de santos · Porto de Santos? · Defina Porto de Santos

Porto de Santos é um porto estuarino, localizado nos municípios de Santos, Guarujá e Cubatão, no estado de São Paulo. É o principal porto brasileiro, o maior complexo portuário da América Latina e um dos maiores do mundo. Possui uma grande variedade de terminais de carga para diversos produtos, que realizam a movimentação de granéis sólidos (principalmente de origem vegetal), líquidos, contêineres, carga geral e passageiros. A área de influência econômica do porto concentra aproximadamente 67% do produto interno bruto (PIB) do país e abrange principalmente os estados de São Paulo, Minas Gerais, Goiás, Mato Grosso e Mato Grosso do Sul.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Porto de Santos](https://pt.wikipedia.org/wiki/Porto_de_Santos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Porto de Santos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0057 — O que é hidrovia?

**Variantes:** Hidrovia: o que significa? · Me explica o que é hidrovia · oq é hidrovia · hidrovia? · Defina hidrovia

Hidrovia é uma rota pré-determinada para o tráfego aquático. Desde tempos muito antigos, o homem utiliza a água como estrada. Nos dias atuais, mares, lagos e rios são constantemente cortados por embarcações do mais diferentes tipos, desde os imponentes navios até as humildes barcaças. Cada um desses veículos foi planejado e construído de forma a preencher certos requisitos que lhe deem o máximo de eficiência na tarefa que lhe cabe.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Hidrovia](https://pt.wikipedia.org/wiki/Hidrovia) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Hidrovia" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0058 — O que é ferrovia?

**Variantes:** Ferrovia: o que significa? · Me explica o que é ferrovia · oq é ferrovia · ferrovia? · Defina ferrovia

Ferrovia (chamada também de via férrea, caminho de ferro (português europeu) ou estrada de ferro (português brasileiro)) é um sistema de transporte baseado em trens (comboio) correndo sobre trilhos (carris) previamente dispostos. O transporte ferroviário é predominante em regiões altamente industrializadas, como a Europa, o extremo leste da Ásia e ainda em locais altamente populosos como a Índia. As ferrovias são o meio de transporte terrestre com maior capacidade de transporte de carga e de passageiros. Em muitos países em desenvolvimento da África e da América Latina, as ferrovias foram preteridas pelas rodovias como tipo de transporte predominante.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Ferrovia](https://pt.wikipedia.org/wiki/Ferrovia) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Ferrovia" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0059 — O que é transporte rodoviário?

**Variantes:** Transporte rodoviário: o que significa? · Me explica o que é transporte rodoviário · oq é transporte rodoviario · transporte rodoviário? · Defina transporte rodoviário

O transporte rodoviário é feito de certos materiais e desloca-se a partir de rodas, normalmente, anda nas estradas, rodovias, ruas e outras vias pavimentadas ou não, com a intenção de movimentar materiais, pessoas ou animais de um determinado ponto a outro. Representa a maior parte do transporte terrestre. O transporte rodoviário em sua maioria é realizado por veículos automotores, como carros, ônibus, BRTs e caminhões. Segundo a ANTT, existem cerca de 130 mil empresas de transporte de cargas no Brasil com mais de 1,6 milhões de veículos que oferecem trabalho, diretamente, a pelo menos 5 milhões de pessoas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Transporte rodoviário](https://pt.wikipedia.org/wiki/Transporte_rodovi%C3%A1rio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Transporte rodoviário" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0060 — O que é frete?

**Variantes:** Frete: o que significa? · Me explica o que é frete · oq é frete · frete? · Defina frete

Frete é o preço que se paga pelo uso ou pela locação de embarcação ou qualquer outro meio de transporte (rodoviário, marítimo, ferroviário ou aéreo) pertencente a outro. Esse preço depende do tipo de carga, do modo de transporte (caminhão, navio, trem, avião), do peso e do volume da carga e da distância a ser percorrida até o ponto de entrega da carga. Afretamento é um contrato mediante o qual o proprietário (fretador) de um meio de transporte, mediante um preço previamente estipulado (frete), compromete-se a cedê-lo, parcial ou totalmente, a outro (afretador) para o transporte de mercadorias ou de outros objetos e equipamentos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Frete](https://pt.wikipedia.org/wiki/Frete) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Frete" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0061 — O que é contêiner?

**Variantes:** Contêiner: o que significa? · Me explica o que é contêiner · oq é conteiner · contêiner? · Defina contêiner

O termo contêiner (português brasileiro) ou contentor (português europeu) é um equipamento utilizado para transportar carga. Um contentor ou contêiner é uma grande caixa de metal ou madeira, geralmente de grandes dimensões, destinado ao acondicionamento e transporte de carga em navios, trens etc. É também conhecido como cofre de carga, pois é dotado de dispositivos de segurança previstos por legislações nacionais e por convenções internacionais. Tem como característica principal constituir hoje em dia uma unidade de carga independente, com dimensões padrão em medidas inglesas (pés). A unidade base geralmente considerada é o TEU.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Contêiner](https://pt.wikipedia.org/wiki/Cont%C3%AAiner) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Contêiner" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0062 — O que é corredor de exportação?

**Variantes:** Corredor de exportação: o que significa? · Me explica o que é corredor de exportação · oq é corredor de exportacao · corredor de exportação? · Defina corredor de exportação

Corredor de exportação é um tipo específico de rota de transporte. Trata-se de conjunto coordenado de facilidades e meios de transporte e armazenamento que viabilizam a movimentação de grandes quantidades de mercadorias com destino a um porto ou posto alfandegário fronteiriço. Tem como premissa básica a redução dos custos de transporte, incluindo também a infraestrutura de armazenamento e terminais de carga cujo destino seja o mercado externo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Corredor de exportação](https://pt.wikipedia.org/wiki/Corredor_de_exporta%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Corredor de exportação" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0063 — O que é armazenagem?

**Variantes:** Armazenagem: o que significa? · Me explica o que é armazenagem · oq é armazenagem · armazenagem? · Defina armazenagem

A armazenagem é constituída por um conjunto de funções de recepção, descarga, carregamento, arrumação e conservação de matérias-primas, produtos acabados ou semi-acabados. Uma vez que este processo envolve mercadorias, este apenas produz resultados quando é realizada uma operação, nas existências em trânsito, com o objectivo de lhes acrescentar valor (Dias, 2005, p. 189). Pode-se definir a missão da armazenagem como o compromisso entre os custos e a melhor solução para as empresas. Na prática isto só é possível se tiver em conta todos os factores que influenciam os custos de armazenagem, bem como a importância relativa dos mesmos (Casadevante, 1974, p. 26).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Armazenagem](https://pt.wikipedia.org/wiki/Armazenagem) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Armazenagem" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0064 — O que é barreira sanitária?

**Variantes:** Barreira sanitária: o que significa? · Me explica o que é barreira sanitária · oq é barreira sanitaria · barreira sanitária? · Defina barreira sanitária

Uma barreira sanitária é um mecanismo legal utilizado pelas autoridades governamentais de um país ou região que impede ou restringe a circulação de animais e plantas. O principal objetivo das barreiras sanitárias é prevenir riscos de contaminação e disseminação de pragas e doenças ou evitar que elas ocorram. Normalmente este termo é usado apenas no caso de animais e seus derivados, enquanto o termo barreira fitossanitária é usado para vegetais e seus derivados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Barreira sanitária](https://pt.wikipedia.org/wiki/Barreira_sanit%C3%A1ria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Barreira sanitária" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0065 — O que é Rumo Logística?

**Variantes:** Rumo Logística: o que significa? · Me explica o que é Rumo Logística · oq é rumo logistica · Rumo Logística? · Defina Rumo Logística

A Rumo é a maior operadora privada de ferrovias de carga do país. Conectando regiões produtoras aos principais portos brasileiros, a companhia transporta grãos, biocombustíveis, açúcar, minérios, celulose, contêineres e bens de consumo, com soluções logísticas eficientes, competitivas e de baixo carbono. A Rumo opera malhas ferroviárias de norte a sul do Brasil, com cerca de 14 mil quilômetros de ferrovias nos estados de Goiás, Mato Grosso, Mato Grosso do Sul, Minas Gerais, Paraná, São Paulo, Santa Catarina, Rio Grande do Sul e Tocantins. A base de ativos é formada por 1.400 locomotivas e 35 mil vagões.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Rumo Logística](https://pt.wikipedia.org/wiki/Rumo_Log%C3%ADstica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Rumo Logística" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0066 — O que é Ferrogrão?

**Variantes:** Ferrogrão: o que significa? · Me explica o que é Ferrogrão · oq é ferrograo · Ferrogrão? · Defina Ferrogrão

Ferrogrão, tecnicamente chamada EF-170, é um projeto de uma ferrovia longitudinal brasileira que formará o corredor ferroviário de exportação do Brasil pela Bacia Amazônica, na Região Norte do país. A ferrovia contará com uma extensão de 933 km, conectando a região produtora de grãos do Centro-Oeste ao Porto de Miritituba na margem direita do rio Tapajós, em Itaituba, no estado do Pará.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Ferrogrão](https://pt.wikipedia.org/wiki/Ferrogr%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Ferrogrão" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0067 — O que é Lagoa dos Patos?

**Variantes:** Lagoa dos Patos: o que significa? · Me explica o que é Lagoa dos Patos · oq é lagoa dos patos · Lagoa dos Patos? · Defina Lagoa dos Patos

A Lagoa dos Patos é uma laguna localizada no estado do Rio Grande do Sul, no Brasil. É a maior laguna costeira estrangulada do mundo e a maior laguna costeira da América do Sul. Tem 265 quilômetros de comprimento, 60 quilômetros de largura (na sua cota máxima), 7 metros de profundidade, e uma superfície de 10 144 km². Estende-se na direção norte-nordeste-sul-sudoeste paralelamente ao Oceano Atlântico, do qual é separada por uma península.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Lagoa dos Patos](https://pt.wikipedia.org/wiki/Lagoa_dos_Patos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Lagoa dos Patos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0068 — O que é Arco Norte?

**Variantes:** Arco Norte: o que significa? · Me explica o que é Arco Norte · oq é arco norte · Arco Norte? · Defina Arco Norte

O Arco Norte é um plano estratégico que abrange portos ou estações de transbordos dos estados de Amapá, Amazonas, Pará, Rondônia e Maranhão. A região é de fundamental importância para escoamento dos grãos de Mato Grosso. O objetivo do plano é integrar os portos e as estações de transbordo destes estados, e desta forma aumentar a exportação pelo Arco Norte, partindo dos portos da Região Norte, ficando mais perto da Europa, do Leste dos Estados Unidos e do Canal do Panamá, que foi duplicado, chegando na China com um custo menor. Os portos situados acima do Paralelo 16° S compõem o chamado Arco Norte, abrangendo os terminais das regiões Norte e Nordeste.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Arco Norte](https://pt.wikipedia.org/wiki/Arco_Norte) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Arco Norte" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0069 — O que são Incoterms?

**Variantes:** Incoterms: o que significa? · Me explica o que são Incoterms · oq sao incoterms · Incoterms? · Defina Incoterms

Incoterms® (do inglês, International Commercial Terms) ou Termos Internacionais de Comércio foram criados pela Câmara de Comércio Internacional em 1936 para resumir em códigos de três letras, conjuntos de cláusulas comumente utilizadas em contratos de compra e venda internacionais de mercadorias, definindo a responsabilidade sobre obrigações, riscos e custos referentes ao transporte.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Incoterms](https://pt.wikipedia.org/wiki/Incoterms) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Incoterms" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0070 — O que é Drawback?

**Variantes:** Drawback: o que significa? · Me explica o que é Drawback · oq é drawback · Drawback? · Defina Drawback

Drawback (inglês: "retirada", "suspensão"; também aportuguesado como "draubaque"), é uma forma de incentivo fiscal à importação / exportação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Drawback](https://pt.wikipedia.org/wiki/Drawback) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Drawback" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Economia

### MERC-WK-0013 — O que é produto interno bruto?

**Variantes:** Produto interno bruto: o que significa? · Me explica o que é produto interno bruto · oq é produto interno bruto · produto interno bruto? · Defina produto interno bruto

Produto interno bruto (PIB) é uma medida monetária do valor de mercado total de todos os bens finais e serviços produzidos e prestados durante um período específico (normalmente um ano) por um país ou por países. O PIB é frequentemente utilizado para medir a atividade econômica de um país ou região. Os principais componentes do PIB são o consumo, os gastos do governo, as exportações líquidas (exportações menos importações) e o investimento. A alteração de qualquer um desses fatores pode aumentar o tamanho da economia.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Produto interno bruto](https://pt.wikipedia.org/wiki/Produto_interno_bruto) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Produto interno bruto" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0014 — O que é inflação?

**Variantes:** Inflação: o que significa? · Me explica o que é inflação · oq é inflacao · inflação? · Defina inflação

Em economia, a inflação é um aumento geral nos preços de bens e serviços em uma economia. Quando o nível geral de preços aumenta, cada unidade de moeda compra menos bens e serviços; consequentemente, a inflação corresponde a uma redução do poder de compra do dinheiro. O oposto da inflação é a deflação, uma diminuição sustentada do nível geral de preços de bens e serviços. A medida comum de inflação é a taxa de inflação, a variação percentual anualizada de um índice de preços geral.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Inflação](https://pt.wikipedia.org/wiki/Infla%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Inflação" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0015 — O que é Índice Nacional de Preços ao Consumidor Amplo?

**Variantes:** Índice Nacional de Preços ao Consumidor Amplo: o que significa? · Me explica o que é Índice Nacional de Preços ao Consumidor Amplo · oq é indice nacional de precos ao consumidor amplo · Índice Nacional de Preços ao Consumidor Amplo? · Defina Índice Nacional de Preços ao Consumidor Amplo

A inflação no Brasil tem sido um grande problema da economia brasileira, principalmente ao longo do século XX. O primeiro grande ciclo inflacionário registrado pelo país ocorre na década de 1940, cuja primeira metade foi marcada pela Segunda Guerra Mundial (1939-1945), quando os preços cresceram em 215,6% no período entre os anos de 1940 e 1949 (12,2% ao ano, em média). Após 1945, no entanto, o governo manteve congelados os preços das moedas estrangeiras, o que manteve a inflação em índices moderados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Inflação no Brasil](https://pt.wikipedia.org/wiki/Infla%C3%A7%C3%A3o_no_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Inflação no Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0016 — O que é taxa Selic?

**Variantes:** Taxa Selic: o que significa? · Me explica o que é taxa Selic · oq é taxa selic · taxa Selic? · Defina taxa Selic

No Brasil, a taxa Selic é a taxa básica de juros da economia. É o principal instrumento de política monetária utilizado pelo Banco Central do Brasil (BC) para controle da inflação. A taxa básica de juros é referência para todas as demais taxas de juros do país — tais como aquelas incidentes sobre empréstimos, financiamentos e aplicações financeiras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Taxa Selic](https://pt.wikipedia.org/wiki/Taxa_Selic) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Taxa Selic" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0017 — O que é Banco Central do Brasil?

**Variantes:** Banco Central do Brasil: o que significa? · Me explica o que é Banco Central do Brasil · oq é banco central do brasil · Banco Central do Brasil? · Defina Banco Central do Brasil

Banco Central do Brasil (também conhecido pelas siglas BC e BCB ou pelo acrônimo BACEN) é uma autarquia federal autônoma integrante do Sistema Financeiro Nacional sem vinculação a nenhum Ministério. Foi criado em 31 de dezembro de 1964 pela Lei nº 4.595/1964 e iniciou suas atividades em março de 1965, tendo em vista que a Lei nº 4.595/1964 entrou em vigor 90 dias após sua publicação. Assim como outros bancos centrais do mundo, o BC é uma das principais autoridades monetárias do país, sendo a principal o Conselho Monetário Nacional (CMN).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Banco Central do Brasil](https://pt.wikipedia.org/wiki/Banco_Central_do_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Banco Central do Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0018 — O que é Comitê de Política Monetária?

**Variantes:** Comitê de Política Monetária: o que significa? · Me explica o que é Comitê de Política Monetária · oq é comite de politica monetaria · Comitê de Política Monetária? · Defina Comitê de Política Monetária

O Comitê de Política Monetária (Copom) é um órgão constituído no âmbito do Banco Central do Brasil em 20 de junho de 1996, por meio da circular n° 2.698, (revogada a partir de 2 de janeiro de 1998, pela Circular nº 2.780, de 12 de novembro de 1997) com as finalidades de estabelecer as diretrizes da política monetária e definir a taxa básica de juros. Tem, ainda, a competência específica de regular a liquidez da economia, por meio dos instrumentos de política monetária.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Comitê de Política Monetária](https://pt.wikipedia.org/wiki/Comit%C3%AA_de_Pol%C3%ADtica_Monet%C3%A1ria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Comitê de Política Monetária" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0019 — O que é taxa de câmbio?

**Variantes:** Taxa de câmbio: o que significa? · Me explica o que é taxa de câmbio · oq é taxa de cambio · taxa de câmbio? · Defina taxa de câmbio

A taxa de câmbio é uma relação entre moedas de dois países que resulta no preço de uma delas medido em relação à outra. Mas, além de expressar quantitativamente a condição de troca entre duas moedas, a taxa de câmbio expressa as relações de troca entre dois países. O câmbio é uma das variáveis macroeconômicas mais importantes, sobretudo para as relações comerciais e financeiras de um país com o conjunto dos demais países. A taxa de câmbio é definida de forma direta quando exprime o preço de uma unidade de moeda estrangeira em moeda nacional - ou seja, exprime a quantidade de moeda nacional necessária para comprar uma unidade de moeda estrangeira.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Taxa de câmbio](https://pt.wikipedia.org/wiki/Taxa_de_c%C3%A2mbio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Taxa de câmbio" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0020 — O que é dólar dos Estados Unidos?

**Variantes:** Dólar dos Estados Unidos: o que significa? · Me explica o que é dólar dos Estados Unidos · oq é dolar dos estados unidos · dólar dos Estados Unidos? · Defina dólar dos Estados Unidos

O dólar dos Estados Unidos, também conhecido como dólar americano, é a moeda oficial dos Estados Unidos e utilizada no mundo inteiro, tanto em reservas internacionais, como em livre circulação em alguns países. Atualmente, sua expedição é controlada pela Reserva Federal dos Estados Unidos. O nome dollar deriva de thaler (em português táler), abreviação de Joachimsthaler, uma moeda de prata cunhada pela primeira vez em 1518, com prata extraída das minas situadas em torno da cidade de Joachimsthal ("Vale de São Joaquim"), atual Jáchymov, na Boêmia.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Dólar dos Estados Unidos](https://pt.wikipedia.org/wiki/D%C3%B3lar_dos_Estados_Unidos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Dólar dos Estados Unidos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0021 — O que é balança comercial?

**Variantes:** Balança comercial: o que significa? · Me explica o que é balança comercial · oq é balanca comercial · balança comercial? · Defina balança comercial

Em contabilidade nacional, a balança comercial resulta da agregação da balança de bens e de serviços, ambas componentes da balança corrente. A balança comercial regista, portanto, as importações e as exportações de bens entre os países. Consequentemente, podemos expressar o saldo da balança comercial da seguinte maneira: Saldo da balança comercial = Exportações − Importações {\displaystyle \operatorname {\text{Saldo da balança comercial}} ={\text{Exportações}}-{\text{Importações}}} Quando as importações são menores que as exportações regista-se um superavit na balança, e no caso contrário registra-se um deficit.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Balança comercial](https://pt.wikipedia.org/wiki/Balan%C3%A7a_comercial) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Balança comercial" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0022 — O que é oferta e procura?

**Variantes:** Oferta e procura: o que significa? · Me explica o que é oferta e procura · oq é oferta e procura · oferta e procura? · Defina oferta e procura

Em economia, a Lei da Oferta e Procura, também conhecida como Lei da Oferta e Demanda, é um modelo de determinação de preços num mercado. Num mercado em concorrência perfeita, os agentes econômicos tomam decisões que variam o preço até que este seja tal que a quantidade procurada seja igual à quantidade oferecida, resultando daí um equilíbrio econômico em que não há incentivos para a alteração de quantidades ou preços.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Lei da oferta e da procura](https://pt.wikipedia.org/wiki/Lei_da_oferta_e_da_procura) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Lei da oferta e da procura" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0023 — O que são Juros?

**Variantes:** Juros: o que significa? · Me explica o que são Juros · oq sao juros · Juros? · Defina Juros

Juro é a remuneração cobrada pelo empréstimo de dinheiro (ou outro item). É expresso como um percentual sobre o valor emprestado (taxa de juro). O juro pode ser compreendido como uma espécie de "aluguel" de dinheiro. A taxa é uma compensação paga pelo tomador do empréstimo para ter o direito de usar o dinheiro até o dia do pagamento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Juro](https://pt.wikipedia.org/wiki/Juro) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Juro" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0024 — O que é Crédito?

**Variantes:** Crédito: o que significa? · Me explica o que é Crédito · oq é credito · Crédito? · Defina Crédito

Crédito (do latim creditu) significa a confiança que se tem em algo. No campo das finanças em particular, é a confiança de que se vai receber de volta o dinheiro emprestado. Aquele que empresta dinheiro a um indivíduo ou a uma instituição, se chama credor, pois ele "crê" que receberá seu dinheiro de volta.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Crédito](https://pt.wikipedia.org/wiki/Cr%C3%A9dito) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Crédito" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0025 — O que é política de preços mínimos?

**Variantes:** Política de preços mínimos: o que significa? · Me explica o que é política de preços mínimos · oq é politica de precos minimos · política de preços mínimos? · Defina política de preços mínimos

O preço mínimo é uma imposição governamental ou de grupos privados, através de regulações ou impostos, que tem como fim o estabelecimento de uma remuneração mínima a uma mercadoria qualquer. Para um preço mínimo ser eficaz, ele obrigatoriamente deve ser maior do que o preço de equilíbrio do mercado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Política de preços mínimos](https://pt.wikipedia.org/wiki/Pol%C3%ADtica_de_pre%C3%A7os_m%C3%ADnimos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Política de preços mínimos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0026 — O que é política agrícola?

**Variantes:** Política agrícola: o que significa? · Me explica o que é política agrícola · oq é politica agricola · política agrícola? · Defina política agrícola

O termo política agrícola se refere a um conjunto de práticas que visam amparar e direcionar o setor referente a economia rural e as atividades agropecuárias. Mais especificamente, quando se fala em políticas agrícolas está se fazendo uma menção às políticas estatais que promovem pesquisas no âmbito da agricultura e pecuária, facilidade no acesso a instrumentos agrícolas, garantia de preços mínimos justos para os produtos destinado a esse tipo de produção, assistência de crédito e implantação de medidas que buscam uma harmonia entre o segmento agropecuário e o setor da indústria nacional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Política agrícola](https://pt.wikipedia.org/wiki/Pol%C3%ADtica_agr%C3%ADcola) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Política agrícola" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0027 — O que é subsídio?

**Variantes:** Subsídio: o que significa? · Me explica o que é subsídio · oq é subsidio · subsídio? · Defina subsídio

O subsídio (do termo latino subsidiu) é um apoio monetário concedido por uma entidade (instituição ou pessoa) a outra entidade individual ou coletiva, no sentido de fomentar o desenvolvimento de uma determinada atividade desta ou o desenvolvimento da própria. Subsídios governamentais fornecidos a empresas (comércio e indústrias) possuem o intuito de reduzir o preço final dos produtos vendidos por tais, para que estes produtos possam competir com os produzidos por outras empresas a preços menores (entre outras razões, por causa dos menores custos de mão de obra e de diferenças de taxas cambiais). Subsídios também podem ser dados com outros objetivos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Subsídio](https://pt.wikipedia.org/wiki/Subs%C3%ADdio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Subsídio" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0028 — O que é tarifa alfandegária?

**Variantes:** Tarifa alfandegária: o que significa? · Me explica o que é tarifa alfandegária · oq é tarifa alfandegaria · tarifa alfandegária? · Defina tarifa alfandegária

Uma tarifa alfandegária é um imposto cobrado pelo governo de um país ou território aduaneiro, ou por uma união supranacional, sobre as importações (ou, excepcionalmente, exportações) de mercadorias. Além de ser uma fonte de receita, os impostos de importação também podem ser uma forma de regulamentação do comércio exterior e uma política que sobrecarrega os produtos estrangeiros para incentivar ou proteger a indústria doméstica. As "tarifas protecionistas" estão entre os instrumentos de protecionismo mais amplamente utilizados, juntamente com cotas de importação e cotas de exportação e outras barreiras não tarifárias ao comércio.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Taxa alfandegária](https://pt.wikipedia.org/wiki/Taxa_alfandeg%C3%A1ria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Taxa alfandegária" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0029 — O que é imposto?

**Variantes:** Imposto: o que significa? · Me explica o que é imposto · oq é imposto · imposto? · Defina imposto

Imposto (do latim imposìtu-, particípio passado de imponère: "impor", "pôr como obrigação") é um tributo cobrado pelas autoridades públicas sobre os recursos ou bens das pessoas físicas ou jurídicas estabelecidas ou que tenham interesses em seu território.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Imposto](https://pt.wikipedia.org/wiki/Imposto) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Imposto" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0030 — O que é reforma tributária do Brasil?

**Variantes:** Reforma tributária do Brasil: o que significa? · Me explica o que é reforma tributária do Brasil · oq é reforma tributaria do brasil · reforma tributária do Brasil? · Defina reforma tributária do Brasil

A reforma tributária do Brasil, promovida por meio da Emenda à Constituição nº 132, é uma medida em curso, com o propósito de promover modificações na arrecadação de tributos no Brasil. A reforma tributária aprovada em 2023 e ainda em implementação, tem como objetivo simplificar o processo de pagamento e cobrança de impostos, taxas e contribuições nos âmbitos federal, estadual e municipal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Reforma tributária do Brasil](https://pt.wikipedia.org/wiki/Reforma_tribut%C3%A1ria_do_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Reforma tributária do Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0031 — O que são ICMS?

**Variantes:** ICMS: o que significa? · Me explica o que são ICMS · oq sao icms · ICMS? · Defina ICMS

Imposto sobre Circulação de Mercadorias e Serviços (ICMS) é um imposto estadual sob administração estadual brasileiro, ou seja, somente os governos dos estados e do Distrito Federal têm competência para instituí-lo (conforme o art. 155, II, da Constituição de 1988). Na aplicação do imposto deve-se considerar diversos fatores, como estado Origem-Destino, Produto, Empresa, Cliente, etc. O controle da arrecadação do ICMS se caracteriza conforme o enquadramento das empresas em Simples Nacional, lucro presumido e lucro real.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Imposto sobre Circulação de Mercadorias e Serviços](https://pt.wikipedia.org/wiki/Imposto_sobre_Circula%C3%A7%C3%A3o_de_Mercadorias_e_Servi%C3%A7os) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Imposto sobre Circulação de Mercadorias e Serviços" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0032 — O que é lei Kandir?

**Variantes:** Lei Kandir: o que significa? · Me explica o que é lei Kandir · oq é lei kandir · lei Kandir? · Defina lei Kandir

A Lei Kandir, lei complementar brasileira nº 87 publicada em 13 de setembro de 1996, entrou em vigor em 01 de novembro de 1996 no Brasil e dispõe sobre o imposto dos estados e do Distrito Federal, nas operações relativas à circulação de mercadorias e serviços (ICMS). A lei Kandir isenta do tributo ICMS os produtos e serviços destinados à exportação. A lei tem este nome em virtude do seu autor, Antônio Kandir, à época ministro do Planejamento do Governo Fernando Henrique Cardoso. Surgiu da necessidade de estimular as exportações.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Lei Kandir](https://pt.wikipedia.org/wiki/Lei_Kandir) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Lei Kandir" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Commodities e bolsas

### MERC-WK-0001 — O que é Chicago Mercantile Exchange?

**Variantes:** Chicago Mercantile Exchange: o que significa? · Me explica o que é Chicago Mercantile Exchange · oq é chicago mercantile exchange · Chicago Mercantile Exchange? · Defina Chicago Mercantile Exchange

A Chicago Mercantile Exchange (CME ou, simplesmente, "The Merc") (NYSE: CME) é uma bolsa de mercadorias dos Estados Unidos, baseada em Chicago. A CME foi fundada em 1898 como a Chicago Butter and Egg Board. Originalmente, a bolsa era uma organização sem fins lucrativos. A bolsa desmutualizou em novembro de 2000, teve oferta pública em dezembro de 2002, e fundiu-se com a Chicago Board of Trade em julho de 2007 para se tornarem a CME Group Inc. O CEO da CME Group é Craig S. Donohue.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Chicago Mercantile Exchange](https://pt.wikipedia.org/wiki/Chicago_Mercantile_Exchange) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Chicago Mercantile Exchange" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0002 — O que é B3?

**Variantes:** B3: o que significa? · Me explica o que é B3 · oq é b3 · B3? · Defina B3

B3 (estilizado como [B]³ em referência às letras iniciais de Brasil, Bolsa, Balcão) é uma bolsa de valores brasileira sediada na cidade de São Paulo. Funciona de forma autorregulada sob a supervisão da Comissão de Valores Mobiliários (CVM) e seu indicador de referência é o Ibovespa. Além da sede localizada no centro da capital paulista na Praça Antônio Prado, a B3 mantém outras unidades na avenida Faria Lima e em Alphaville.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – B3 (bolsa de valores)](https://pt.wikipedia.org/wiki/B3_(bolsa_de_valores)) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "B3 (bolsa de valores)" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0003 — O que é mercado futuro?

**Variantes:** Mercado futuro: o que significa? · Me explica o que é mercado futuro · oq é mercado futuro · mercado futuro? · Defina mercado futuro

Uma bolsa de futuros ou mercado de futuros é uma bolsa financeira central onde as pessoas podem negociar contratos futuros padronizados definidos pela bolsa. Os contratos de futuros são contratos de derivativos para comprar ou vender quantidades específicas de uma mercadoria ou instrumento financeiro a um preço especificado com entrega definida em um momento específico no futuro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Mercado de futuros](https://pt.wikipedia.org/wiki/Mercado_de_futuros) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Mercado de futuros" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0004 — O que é contrato futuro?

**Variantes:** Contrato futuro: o que significa? · Me explica o que é contrato futuro · oq é contrato futuro · contrato futuro? · Defina contrato futuro

Contrato de futuros, também chamado contrato futuro, é um tipo de contrato derivativo. Os contratos de futuros são contratos de compra e venda padronizados, notadamente no que se refere às características do produto negociado, conforme regulamentação da Bolsa. Através desses contratos, as partes compradora e vendedora se comprometem a comprar e vender determinada quantidade de um ativo financeiro ou ativo "real" (bens tangíveis), em uma data futura, a um preço predeterminado. Por serem padronizados, os contratos futuros são negociáveis em bolsa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Contrato de futuros](https://pt.wikipedia.org/wiki/Contrato_de_futuros) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Contrato de futuros" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0005 — O que é opção?

**Variantes:** Opção: o que significa? · Me explica o que é opção · oq é opcao · opção? · Defina opção

Mercado de opções é o mercado onde se negociam opções – instrumentos financeiros utilizados no mercado financeiro. Uma opção confere, ao titular, o direito (e não obrigação) de comprar ou vender um determinado ativo (ação, título ou bem) por um valor determinado, enquanto o lançador é obrigado a concluir a transação de compra ou venda. Uma opção pode ser vista como uma apólice de seguro; em particular a opção de venda é análoga a um seguro de automóvel, pois permite recuperar um valor predeterminado pelo ativo, mesmo que este tenha desvalorizado muito.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Mercado de opções](https://pt.wikipedia.org/wiki/Mercado_de_op%C3%A7%C3%B5es) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Mercado de opções" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0006 — O que é hedge?

**Variantes:** Hedge: o que significa? · Me explica o que é hedge · oq é hedge · hedge? · Defina hedge

Em finanças, chama-se cobertura ao instrumento que visa proteger operações financeiras contra o risco de grandes variações de preço de um determinado ativo. Hedge é uma operação que reduz ou elimina o risco com a variação de preços indesejados. Pensando de maneira diversa, o hedge serve para fixar o preço de um ativo, passivo, taxa de câmbio, taxa de juros, insumo/commodity ou uma dívida em um determinado período.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Cobertura (finanças)](https://pt.wikipedia.org/wiki/Cobertura_(finan%C3%A7as)) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Cobertura (finanças)" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0007 — O que é mercado a termo?

**Variantes:** Mercado a termo: o que significa? · Me explica o que é mercado a termo · oq é mercado a termo · mercado a termo? · Defina mercado a termo

O mercado a termo ou futuro é o mercado financeiro informal de balcão por meio do qual são celebrados contratos a termo. É usado principalmente para negociação em moedas estrangeiras, onde os contratos são usados ​​para proteger contra o risco cambial. As commodities também são negociadas em mercados a termo. Os exemplos incluem produtos agrícolas, como arroz e futuros de energia, como petróleo e gás natural.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Mercado a termo](https://pt.wikipedia.org/wiki/Mercado_a_termo) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Mercado a termo" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0008 — O que é bushel?

**Variantes:** Bushel: o que significa? · Me explica o que é bushel · oq é bushel · bushel? · Defina bushel

O bushel (abreviadamente bsh. ou bu.) é uma unidade de medida de capacidade para mercadorias sólidas e secas (especialmente grãos e farinhas) utilizada nos países anglo-saxões.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Bushel](https://pt.wikipedia.org/wiki/Bushel) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Bushel" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0009 — O que são certificados de recebíveis do agronegócio?

**Variantes:** Certificados de recebíveis do agronegócio: o que significa? · Me explica o que são certificados de recebíveis do agronegócio · oq sao certificados de recebiveis do agronegocio · certificados de recebíveis do agronegócio? · Defina certificados de recebíveis do agronegócio

Certificados de recebíveis do agronegócio CRA, é um tipo de investimento financeiro do Brasil consistindo de títulos de renda fixa lastreados em recebíveis de negócios entre produtores rurais ou suas cooperativas, e terceiros, abrangendo financiamentos ou empréstimos relacionados à produção, à comercialização, ao beneficiamento ou à industrialização de produtos, insumos agropecuários ou máquinas e implementos utilizados na produção agropecuária. CRAs são um investimento de renda fixa e por isso o investidor tem a previsão do fluxo de caixa das remunerações e amortizações do título.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Certificados de recebíveis do agronegócio](https://pt.wikipedia.org/wiki/Certificados_de_receb%C3%ADveis_do_agroneg%C3%B3cio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Certificados de recebíveis do agronegócio" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0010 — O que é letra de crédito do agronegócio?

**Variantes:** Letra de crédito do agronegócio: o que significa? · Me explica o que é letra de crédito do agronegócio · oq é letra de credito do agronegocio · letra de crédito do agronegócio? · Defina letra de crédito do agronegócio

A Letra de Crédito do Agronegócio (LCA) é um investimento de renda fixa lastreado em uma carteira de empréstimos relacionados ao setor agropecuário. A Letra de Crédito do Agronegócio foi criada pela lei nº 11.076 de 2004, é um título emitido por instituições financeiras e utilizado para captação de recursos para participantes da cadeia do agronegócio. A LCA pode ser pré-fixada ou pós-fixada, sendo, neste último caso, muito comum o atrelamento à Taxa DI. A grande vantagem das Letras de Crédito do Agronegócio está na isenção de Imposto de Renda e IOF.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Letra de crédito do agronegócio](https://pt.wikipedia.org/wiki/Letra_de_cr%C3%A9dito_do_agroneg%C3%B3cio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Letra de crédito do agronegócio" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0011 — O que é fundo de investimento?

**Variantes:** Fundo de investimento: o que significa? · Me explica o que é fundo de investimento · oq é fundo de investimento · fundo de investimento? · Defina fundo de investimento

Um fundo de investimento é uma forma de aplicação financeira, formada pela união de vários investidores que se juntam para a realização de um investimento financeiro, não possuindo personalidade jurídica, e sendo constituído tal qual um condomínio, visando um determinado objetivo ou retorno esperado, dividindo as receitas geradas e as despesas necessárias para o empreendimento. A administração e a gestão do fundo são realizadas por especialistas contratados. Os administradores tratam dos aspectos jurídicos e legais do fundo, os gestores da estratégia de montagem da carteira de ativos do fundo, visando o maior lucro possível com o menor nível de risco.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Fundo de investimento](https://pt.wikipedia.org/wiki/Fundo_de_investimento) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Fundo de investimento" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0012 — O que é bolsa de valores?

**Variantes:** Bolsa de valores: o que significa? · Me explica o que é bolsa de valores · oq é bolsa de valores · bolsa de valores? · Defina bolsa de valores

Bolsa de valores é o mercado organizado onde se negociam ações de sociedades de capital aberto (públicas ou privadas) e outros valores mobiliários, tais como as opções. Pode ser organizada na forma de uma sociedade civil sem fins lucrativos, que mantém o local ou o sistema de negociação eletrônico adequado à ação de transações de compra e venda de títulos e valores mobiliários. Porém, o mais usual hoje em dia é que as bolsas de valores atuem como sociedades anônimas, visando ao lucro através de seus serviços.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Bolsa de valores](https://pt.wikipedia.org/wiki/Bolsa_de_valores) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Bolsa de valores" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Crédito rural e Plano Safra

### MERC-PS-001 — O que é o Plano Safra?

**Variantes:** Uma pergunta: o que é o Plano Safra? · plano safra? · o q e o plano safra

O Plano Safra é o pacote anual do governo federal que define o volume de recursos, as linhas e as taxas de juros do crédito rural para custeio, comercialização e investimento da agropecuária. Ele vale de julho de um ano a junho do seguinte e tem uma versão para a agricultura empresarial (médios e grandes produtores, pelo MAPA) e outra para a agricultura familiar (Pronaf, pelo MDA). No ciclo 2025/2026, foram R$ 516,2 bilhões para a agricultura empresarial e R$ 89 bilhões para a familiar.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2025-07-01 · *relevância Fenasoja:* alta
*Fontes:* [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17); [Agência Brasil – Plano Safra 25/26 prevê R$ 89 bilhões para agricultura familiar (30/06/2025)](https://agenciabrasil.ebc.com.br/economia/noticia/2025-06/plano-safra-25-26-preve-rs-89-bilhoes-para-agricultura-familiar) (acesso 2026-10-17); [MAPA – Plano Safra 2025/2026: + Infraestrutura](https://www.gov.br/agricultura/pt-br/assuntos/politica-agricola/plano-safra/2025-2026/infraestrutura) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda).

### MERC-PS-002 — Quanto dinheiro tem o Plano Safra 2025/2026 para a agricultura empresarial?

**Variantes:** Qual o valor do Plano Safra 25/26? · plano safra 2025 2026 valor · qto é o plano safra empresarial · Quantos bilhões tem o Plano Safra dos médios e grandes produtores?

Segundo o governo federal, o Plano Safra 2025/2026 da agricultura empresarial destinou R$ 516,2 bilhões, 1,5% a mais que os R$ 508,6 bilhões do ciclo 2024/2025. Foram R$ 414,7 bilhões para custeio e comercialização e R$ 101,5 bilhões para investimentos. O total inclui R$ 185 bilhões de Letras de Crédito do Agronegócio (LCA) direcionados à emissão de CPRs.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025-07-01 · *relevância Fenasoja:* alta
*Fontes:* [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17); [FAESP/Senar – Informe técnico 28/25: Plano Safra 2025/26](https://faespsenar.com.br/painel-de-dados/wp-content/uploads/2025/08/Informe-tecnico-no-28-25-Plano-Safra-2025-26.pdf) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda).

### MERC-PS-003 — Quais são os juros do Plano Safra 2025/2026?

**Variantes:** Qual a taxa de juros do custeio no Plano Safra? · juros plano safra 25/26 · qto ta o juro do pronamp · Os juros do crédito rural subiram em 2025?

No Plano Safra 2025/2026, o custeio para médios produtores (Pronamp) ficou com juros de 10% ao ano e, para os demais produtores, 14% ao ano, cerca de 2 pontos percentuais acima do ciclo anterior. As linhas de investimento variam de 8,5% a 13,5% ao ano, conforme o programa. A alta foi atribuída à Selic elevada (15% na época do anúncio).

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025-07-01 · *relevância Fenasoja:* alta
*Fontes:* [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17); [FAESP/Senar – Informe técnico 28/25: Plano Safra 2025/26](https://faespsenar.com.br/painel-de-dados/wp-content/uploads/2025/08/Informe-tecnico-no-28-25-Plano-Safra-2025-26.pdf) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda). Taxas atuais devem ser confirmadas no Manual de Crédito Rural/BCB ou com o agente financeiro.

### MERC-PS-004 — O que é o Pronamp?

**Variantes:** Alguém me explica: o que é o Pronamp? · pronamp? · o q e o pronamp

O Pronamp é o Programa Nacional de Apoio ao Médio Produtor Rural, uma faixa do crédito rural com condições intermediárias entre o Pronaf e os demais produtores. No Plano Safra 2025/2026, teve R$ 69,1 bilhões, juros de 10% ao ano no custeio, e o limite de renda bruta anual para enquadramento subiu de R$ 3 milhões para R$ 3,5 milhões.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2025-07-01 · *relevância Fenasoja:* alta
*Fontes:* [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda).

### MERC-PS-005 — Quanto tem o Plano Safra da Agricultura Familiar 2025/2026?

**Variantes:** Qual o valor do Plano Safra da agricultura familiar? · plano safra familiar 2025 2026 · qto tem o pronaf esse ano · Quantos bilhões são para o Pronaf no Plano Safra 25/26?

O Plano Safra da Agricultura Familiar 2025/2026 foi lançado em 30/06/2025 com R$ 89 bilhões, valor recorde, dos quais R$ 78,2 bilhões para o crédito do Pronaf. Em 2024 haviam sido destinados R$ 76 bilhões. O plano também inclui seguro agrícola, compras públicas, assistência técnica e garantia de preço mínimo.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025-06-30 · *relevância Fenasoja:* alta
*Fontes:* [Agência Brasil – Plano Safra 25/26 prevê R$ 89 bilhões para agricultura familiar (30/06/2025)](https://agenciabrasil.ebc.com.br/economia/noticia/2025-06/plano-safra-25-26-preve-rs-89-bilhoes-para-agricultura-familiar) (acesso 2026-10-17); [FAESP/Senar – Informe técnico 28/25: Plano Safra 2025/26](https://faespsenar.com.br/painel-de-dados/wp-content/uploads/2025/08/Informe-tecnico-no-28-25-Plano-Safra-2025-26.pdf) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda).

### MERC-PS-006 — Quais são os juros do Pronaf para produzir alimentos?

**Variantes:** Queria entender: quais são os juros do Pronaf para produzir alimentos? · juros pronaf produzir alimentos? · quais sao os juros do pronaf pra produzir alimenos

No Plano Safra da Agricultura Familiar 2025/2026, foi mantida a taxa de 3% ao ano para financiar a produção de alimentos como arroz, feijão, mandioca, frutas, verduras, ovos e leite. Quando o cultivo é orgânico ou agroecológico, a taxa cai para 2% ao ano.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025-06-30 · *relevância Fenasoja:* alta
*Fontes:* [Agência Brasil – Plano Safra 25/26 prevê R$ 89 bilhões para agricultura familiar (30/06/2025)](https://agenciabrasil.ebc.com.br/economia/noticia/2025-06/plano-safra-25-26-preve-rs-89-bilhoes-para-agricultura-familiar) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda). Outras linhas do Pronaf têm taxas diferentes; confirmar no banco/cooperativa de crédito.

### MERC-PS-007 — Quando o Pronaf foi criado?

**Variantes:** Tu sabe me dizer: quando o Pronaf foi criado? · pronaf foi criado?

O Programa Nacional de Fortalecimento da Agricultura Familiar (Pronaf) foi criado em 1995 e completou 30 anos em 2025. Ele é a principal linha de crédito rural voltada aos agricultores familiares no Brasil.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025-06-30 · *relevância Fenasoja:* alta
*Fontes:* [Agência Brasil – Plano Safra 25/26 prevê R$ 89 bilhões para agricultura familiar (30/06/2025)](https://agenciabrasil.ebc.com.br/economia/noticia/2025-06/plano-safra-25-26-preve-rs-89-bilhoes-para-agricultura-familiar) (acesso 2026-10-17)

### MERC-PS-008 — Quanto o Plano Safra 2025/2026 destinou ao seguro da agricultura familiar?

**Variantes:** Tu sabe me dizer: quanto o Plano Safra 2025/2026 destinou ao seguro da agricultura familiar? · plano safra 2025 2026 destinou seguro agricultura? · quanto o plano safra 2025/2026 destinou ao seguro da agricultura familar

No âmbito do seguro agrícola da agricultura familiar, o Plano Safra 2025/2026 destinou R$ 1,1 bilhão ao Garantia-Safra e R$ 5,7 bilhões ao Proagro Mais. Também foram previstos R$ 3,7 bilhões para compras públicas, R$ 240 milhões para assistência técnica e R$ 42,2 milhões para preço mínimo de produtos da sociobiodiversidade (babaçu, pirarucu e borracha).

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025-06-30 · *relevância Fenasoja:* média
*Fontes:* [Agência Brasil – Plano Safra 25/26 prevê R$ 89 bilhões para agricultura familiar (30/06/2025)](https://agenciabrasil.ebc.com.br/economia/noticia/2025-06/plano-safra-25-26-preve-rs-89-bilhoes-para-agricultura-familiar) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda).

### MERC-PS-009 — Como financiar um armazém ou silo pelo Plano Safra?

**Variantes:** Tchê, me ajuda: como financiar um armazém ou silo pelo Plano Safra? · financiar armazém silo plano safra? · como financar um armazem ou silo pelo plano safra

O programa PCA (Programa para Construção e Ampliação de Armazéns) financia construção, ampliação e modernização de armazéns, para produtores e cooperativas, com prazo de até 10 anos e dois anos de carência. No Plano Safra 2025/2026, o limite por projeto subiu de 6 mil para 12 mil toneladas, com juros de 8,5% ao ano para projetos de até 12 mil t e até 10% ao ano para os demais.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2025-07-01 · *relevância Fenasoja:* alta
*Fontes:* [MAPA – Plano Safra 2025/2026: + Infraestrutura](https://www.gov.br/agricultura/pt-br/assuntos/politica-agricola/plano-safra/2025-2026/infraestrutura) (acesso 2026-10-17); [FAESP/Senar – Informe técnico 28/25: Plano Safra 2025/26](https://faespsenar.com.br/painel-de-dados/wp-content/uploads/2025/08/Informe-tecnico-no-28-25-Plano-Safra-2025-26.pdf) (acesso 2026-10-17)
*Notas:* Dado do Plano Safra 2025/2026 (vigência jul/2025–jun/2026). Responder "segundo o anúncio do governo federal de 30/06 e 01/07/2025". O Plano Safra muda todo ano (anúncio em junho/julho): se o usuário perguntar do "atual" após jul/2026, buscar o plano vigente ao vivo (gov.br/agricultura e gov.br/mda). Encaminhar o produtor ao banco ou cooperativa de crédito para simulação.

### MERC-PS-010 — O que é crédito rural?

**Variantes:** Bah, uma dúvida: o que é crédito rural? · crédito rural? · o q e credito rural

Pela Lei nº 4.829/1965 (art. 2º), crédito rural é o suprimento de recursos financeiros por entidades públicas e estabelecimentos de crédito particulares a produtores rurais ou a suas cooperativas, para aplicação exclusiva em atividades que se enquadrem nos objetivos da legislação. Pela finalidade (art. 9º), os financiamentos são de custeio, investimento, comercialização ou industrialização. As regras operacionais ficam no Manual de Crédito Rural do Banco Central.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 4.829/1965 – Crédito Rural (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l4829.htm) (acesso 2026-10-17); [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17)

### MERC-PS-011 — Qual a diferença entre custeio e investimento no crédito rural?

**Variantes:** Queria entender: qual a diferença entre custeio e investimento no crédito rural? · diferença custeio investimento crédito rural? · qual a diferenca entre custeio e investimeto no credito rural

Pela Lei nº 4.829/1965 (art. 9º), custeio é o financiamento destinado a cobrir as despesas normais de um ou mais períodos de produção agrícola ou pecuária. Investimento é o destinado a inversões em bens e serviços cujos benefícios se realizam ao longo de vários períodos, como máquinas, armazéns e irrigação. No Plano Safra 2025/2026, R$ 414,7 bilhões foram para custeio e comercialização e R$ 101,5 bilhões para investimento na agricultura empresarial.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 4.829/1965 – Crédito Rural (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l4829.htm) (acesso 2026-10-17); [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17)

## Preços e cotações (dinâmico)

### MERC-DYN-001 — Qual o preço da soja hoje?

**Variantes:** Quanto tá a saca de soja? · preço soja hoje · qto ta a soja hj · Cotação da soja em Santa Rosa

O preço da soja muda todos os dias e não deve ser informado de memória. Uma referência pública no Brasil é o Indicador da Soja CEPEA/Esalq (Paranaguá), publicado diariamente em R$ e US$ por saca de 60 kg; o preço local pago ao produtor em Santa Rosa e região é informado por cooperativas, cerealistas e pela Emater/RS. Para o mercado internacional, a referência é a Bolsa de Chicago (CBOT/CME).

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-001, SOJ-001
*Fontes:* [CEPEA/Esalq-USP – Indicador da Soja](https://www.cepea.org.br/br/indicador/soja.aspx) (acesso 2026-10-17); [Emater/RS-Ascar – portal](https://www.emater.tche.br/site/) (acesso 2026-10-17)
*Notas:* Exemplo de formato ao vivo: "Indicador CEPEA/Esalq Paranaguá em DD/MM: R$ X/saca".
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Fontes: CEPEA (indicador soja Paranaguá/Paraná), Emater/RS (cotações agropecuárias semanais), cooperativas locais.

### MERC-DYN-002 — Qual o preço do milho hoje?

**Variantes:** Quanto tá a saca de milho? · preço milho hoje · qto ta o milho hj · cotação milho rs

O preço do milho varia diariamente. A referência pública mais usada é o Indicador do Milho CEPEA/Esalq (base Campinas-SP), em R$ por saca de 60 kg; no RS, a Emater/RS divulga cotações semanais por região. O bot deve consultar a fonte ao vivo e citar a data.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [CEPEA/Esalq-USP – Indicador do Milho](https://www.cepea.org.br/br/indicador/milho.aspx) (acesso 2026-10-17); [Emater/RS-Ascar – portal](https://www.emater.tche.br/site/) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar.

### MERC-DYN-003 — Qual o preço do trigo hoje?

**Variantes:** quanto ta o trigo · preço trigo rs hoje · cotação do trigo · qto paga o trigo hj

O preço do trigo é volátil. O CEPEA/Esalq publica indicadores de preço do trigo (inclusive para o Rio Grande do Sul e o Paraná), e a Emater/RS divulga cotações semanais. Consultar ao vivo e informar a data.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [CEPEA/Esalq-USP – Indicador do Trigo](https://www.cepea.org.br/br/indicador/trigo.aspx) (acesso 2026-10-17); [Emater/RS-Ascar – portal](https://www.emater.tche.br/site/) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar.

### MERC-DYN-004 — Qual o preço do boi gordo hoje?

**Variantes:** preço da arroba do boi · boi gordo hoje · qto ta a arroba · cotação do gado

A cotação do boi gordo muda diariamente. A referência nacional é o Indicador do Boi Gordo CEPEA/B3 (base São Paulo), em R$ por arroba; no RS há também cotações regionais divulgadas pela Emater/RS. Consultar ao vivo.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [CEPEA/Esalq-USP – Indicador do Boi Gordo](https://www.cepea.org.br/br/indicador/boi-gordo.aspx) (acesso 2026-10-17); [Emater/RS-Ascar – portal](https://www.emater.tche.br/site/) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar.

### MERC-DYN-005 — Quanto está o preço do leite pago ao produtor?

**Variantes:** preço do litro de leite pro produtor · leite preço hoje rs · qto ta pagando o leite · valor do leite no campo

O preço do leite ao produtor varia por mês e por região. O CEPEA/Esalq publica a média mensal do preço ao produtor (inclusive para o RS), e no estado o Conseleite/RS e a Emater/RS divulgam valores de referência. Consultar ao vivo e informar o mês de referência.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [CEPEA/Esalq-USP – Leite](https://www.cepea.org.br/br/indicador/leite.aspx) (acesso 2026-10-17); [Emater/RS-Ascar – portal](https://www.emater.tche.br/site/) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar.

### MERC-DYN-006 — Quanto está a soja na Bolsa de Chicago?

**Variantes:** soja chicago hoje · cotação cbot soja · qto ta chicago · preço soja bolsa de chicago

A cotação da soja na Bolsa de Chicago (CBOT, do grupo CME) muda a cada minuto durante o pregão e é expressa em centavos de dólar por bushel. O bot não deve informar valor fixo; deve consultar fonte ao vivo e citar data e horário. Para conceitos de bolsa, ver as entradas sobre mercado futuro e bushel.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [CEPEA/Esalq-USP – Indicador da Soja](https://www.cepea.org.br/br/indicador/soja.aspx) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Fonte primária: CME Group (CBOT); o portal de notícias do CEPEA também comenta Chicago.

### MERC-DYN-007 — Quanto está o dólar hoje?

**Variantes:** cotação do dólar · dolar hoje · qto ta o dolar hj · Qual a PTAX de hoje?

O câmbio muda continuamente. A referência oficial é a taxa PTAX do Banco Central, disponível nos dados abertos do BCB (série 1 do SGS para o dólar comercial de venda). O bot deve consultar ao vivo e citar a data; o dólar influencia diretamente o preço da soja em reais.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Banco Central – SGS série 1 (dólar comercial, venda) – API de dados abertos](https://api.bcb.gov.br/dados/serie/bcdata.sgs.1/dados/ultimos/1?formato=json) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Endpoint: https://api.bcb.gov.br/dados/serie/bcdata.sgs.1/dados/ultimos/1?formato=json

### MERC-DYN-008 — Qual é a taxa Selic atual?

**Variantes:** selic hoje · qual a selic · qto ta a selic · Taxa básica de juros atual

A meta da taxa Selic é definida pelo Comitê de Política Monetária (Copom) do Banco Central em reuniões periódicas e pode mudar. O valor vigente deve ser consultado ao vivo nos dados abertos do BCB (série 432 do SGS). A Selic influencia o custo do crédito, inclusive os juros do Plano Safra.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Banco Central – SGS série 432 (meta Selic) – API de dados abertos](https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json) (acesso 2026-10-17); [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Endpoint: https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json

### MERC-DYN-009 — Qual a estimativa da safra de grãos atual da Conab?

**Variantes:** previsão da safra conab · safra 2026/27 estimativa · qto vai dar a safra esse ano · Conab safra de soja atual

A Conab publica mensalmente o Levantamento da Safra de Grãos, com estimativas de área, produtividade e produção por cultura e estado, que são revisadas a cada mês. O bot deve consultar o boletim mais recente ao vivo e citar o número do levantamento e a data.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Conab – Safra de grãos (boletins)](https://www.gov.br/conab/pt-br/atuacao/informacoes-agropecuarias/safras/safra-de-graos) (acesso 2026-10-17); [Conab – portal](https://www.gov.br/conab/pt-br) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar.

### MERC-CON-001 — O que é o Indicador da Soja CEPEA/Esalq?

**Variantes:** Me tira uma dúvida: o que é o Indicador da Soja CEPEA/Esalq? · indicador soja cepea esalq? · o q e o indicaor da soja cepea/esalq

É um indicador de preço da soja calculado e publicado diariamente pelo CEPEA (Centro de Estudos Avançados em Economia Aplicada, da Esalq/USP), em reais e em dólares por saca de 60 kg. Há versões para Paranaguá (porto) e para o Paraná. Ele serve como referência pública de preço, mas o valor recebido pelo produtor varia conforme região, frete, qualidade e prazo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [CEPEA/Esalq-USP – Indicador da Soja](https://www.cepea.org.br/br/indicador/soja.aspx) (acesso 2026-10-17); [CEPEA/Esalq-USP – O Cepea](https://www.cepea.org.br/br/o-cepea.aspx) (acesso 2026-10-17)

### MERC-CON-002 — O que é o CEPEA?

**Variantes:** Queria entender: o que é o CEPEA? · cepea? · o q e o cepea

O CEPEA (Centro de Estudos Avançados em Economia Aplicada) é um centro de pesquisa ligado à Esalq/USP, em Piracicaba-SP, que calcula indicadores de preços agropecuários (soja, milho, trigo, boi, leite, entre outros), além de estudos sobre PIB do agronegócio, custos e mercado de trabalho no agro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [CEPEA/Esalq-USP – O Cepea](https://www.cepea.org.br/br/o-cepea.aspx) (acesso 2026-10-17); [CEPEA/Esalq-USP – Indicador da Soja](https://www.cepea.org.br/br/indicador/soja.aspx) (acesso 2026-10-17)

## Crédito e seguro

### MERC-WK-0034 — O que é Banco do Brasil?

**Variantes:** Banco do Brasil: o que significa? · Me explica o que é Banco do Brasil · oq é banco do brasil · Banco do Brasil? · Defina Banco do Brasil

Banco do Brasil (BB) é uma instituição financeira brasileira, sendo também o banco tradicional mais antigo do país, fundado em 1808. É um dos cinco bancos estatais do governo brasileiro, que conta com participação em 50% das ações. Atualmente, possui mais de 10,6 mil agências e postos de atendimento e 53 mil caixas eletrônicos (incluindo 24 Horas) em todas as regiões do país, além de contar com mais de 86 mil colaboradores e 85 milhões de clientes. Além do Brasil, está presente em mais de 13 países e possui correspondentes em outros 90 países.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Banco do Brasil](https://pt.wikipedia.org/wiki/Banco_do_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Banco do Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0035 — O que é Banco Nacional de Desenvolvimento Econômico e Social?

**Variantes:** Banco Nacional de Desenvolvimento Econômico e Social: o que significa? · Me explica o que é Banco Nacional de Desenvolvimento Econômico e Social · oq é banco nacional de desenvolvimento economico e social · Banco Nacional de Desenvolvimento Econômico e Social? · Defina Banco Nacional de Desenvolvimento Econômico e Social

O Banco Nacional de Desenvolvimento Econômico e Social (BNDES) é uma empresa pública federal com sede no Rio de Janeiro, cujo principal objetivo é o financiamento de longo prazo e investimento em todos os segmentos da economia brasileira. É um dos maiores bancos de desenvolvimento do mundo. Desde a sua fundação, em 1952, é um órgão de fomento no contexto do desenvolvimento econômico como esboçado no Plano SALTE.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Banco Nacional de Desenvolvimento Econômico e Social](https://pt.wikipedia.org/wiki/Banco_Nacional_de_Desenvolvimento_Econ%C3%B4mico_e_Social) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Banco Nacional de Desenvolvimento Econômico e Social" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0036 — O que é cooperativa de crédito?

**Variantes:** Cooperativa de crédito: o que significa? · Me explica o que é cooperativa de crédito · oq é cooperativa de credito · cooperativa de crédito? · Defina cooperativa de crédito

Cooperativa de Crédito é uma associação de pessoas, que buscam através da ajuda mútua, sem fins lucrativos, uma melhor administração de seus recursos financeiros. O objetivo da cooperativa de crédito é prestar assistência creditícia e a prestação de serviços de natureza bancária a seus associados com condições mais favoráveis.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Cooperativa de crédito](https://pt.wikipedia.org/wiki/Cooperativa_de_cr%C3%A9dito) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Cooperativa de crédito" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0037 — O que é Sicredi?

**Variantes:** Sicredi: o que significa? · Me explica o que é Sicredi · oq é sicredi · Sicredi? · Defina Sicredi

Sicredi (acrônimo para Sistema de Crédito Cooperativo) é um sistema de cooperativas de crédito brasileira, considerada a primeira instituição financeira cooperativa da América Latina. Com mais de 120 anos, é representada com mais de 2.800 agências, em todos os estados do Brasil e no Distrito Federal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Sicredi](https://pt.wikipedia.org/wiki/Sicredi) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Sicredi" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0038 — O que é Sicoob?

**Variantes:** Sicoob: o que significa? · Me explica o que é Sicoob · oq é sicoob · Sicoob? · Defina Sicoob

O Sistema de Cooperativas Financeiras do Brasil (Sicoob) é um dos maiores sistemas financeiros do país, com mais de 10 milhões de cooperados e 4,7 mil pontos de atendimento distribuídos em todo o território nacional. É composto por cooperativas financeiras e empresas de apoio, que em conjunto oferecem aos cooperados serviços de conta corrente, crédito, investimento, cartões, previdência, consórcio, seguros, cobrança bancária, adquirência de meios eletrônicos de pagamento, dentre outros. Presente em mais de 2,5 mil municípios e em 424 como a única instituição financeira, segundo o Banco Central.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Sistema de Cooperativas de Crédito do Brasil](https://pt.wikipedia.org/wiki/Sistema_de_Cooperativas_de_Cr%C3%A9dito_do_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Sistema de Cooperativas de Crédito do Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0039 — O que é Banrisul?

**Variantes:** Banrisul: o que significa? · Me explica o que é Banrisul · oq é banrisul · Banrisul? · Defina Banrisul

Banco do Estado do Rio Grande do Sul (Banrisul) é um banco estatal brasileiro, constituído na forma de sociedade de economia mista, com participação do Governo do Estado do Rio Grande do Sul como maior acionista individual, com foco de negócios na Região Sul do Brasil. Atualmente, conta com mais de 9 mil funcionários e mil pontos de atendimento – sendo 619 agências e postos de atendimento e 413 pontos de autoatendimento, presentes no Distrito Federal, Paraná, Rio de Janeiro, Santa Catarina e São Paulo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Banrisul](https://pt.wikipedia.org/wiki/Banrisul) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Banrisul" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0040 — O que é Garantia-Safra?

**Variantes:** Garantia-Safra: o que significa? · Me explica o que é Garantia-Safra · oq é garantia-safra · Garantia-Safra? · Defina Garantia-Safra

Garantia-Safra (GS) é uma ação do Ministério do Desenvolvimento Agrário (MDA) financiada pelo Programa Nacional de Fortalecimento da Agricultura Familiar (Pronaf) que garante ao agricultor familiar um benefício financeiro, por tempo indeterminado, caso perca sua safra devido ao fenômeno da estiagem ou do excesso hídrico. Foi criada em 2002, a partir da lei nº 10.420, está vinculada ao Ministério do Desenvolvimento Agrário (MDA), e é administrada pela Caixa Econômica Federal desde outubro de 2003.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Garantia-Safra](https://pt.wikipedia.org/wiki/Garantia-Safra) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Garantia-Safra" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0041 — O que é microcrédito?

**Variantes:** Microcrédito: o que significa? · Me explica o que é microcrédito · oq é microcredito · microcrédito? · Defina microcrédito

Microcrédito é o termo usado hoje para designar uma variedade de empréstimos cujas características comuns são: Serem de pequeno valor; Serem direcionados a um público restrito, definido por sua baixa renda ou pelo seu ramo de negócios, que usualmente não têm acesso às formas convencionais de crédito; Voltar-se para microempreendedores informais O microcrédito se encontra necessariamente num contexto de microfinanças, sendo esta entendida como sendo o fornecimento de empréstimos, poupanças e outros serviços financeiros especializados para pessoas carentes que vivam por meio de uma atividade económica informal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Microcrédito](https://pt.wikipedia.org/wiki/Microcr%C3%A9dito) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Microcrédito" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### MERC-WK-0042 — O que é Desenrola Brasil?

**Variantes:** Desenrola Brasil: o que significa? · Me explica o que é Desenrola Brasil · oq é desenrola brasil · Desenrola Brasil? · Defina Desenrola Brasil

O Programa Emergencial de Renegociação de Dívidas de Pessoas Físicas Inadimplentes - Desenrola Brasil é um programa implementado pelo Ministério da Fazenda do Brasil durante o governo Lula 3 que visa a renegociação de dívidas de natureza privada de pessoas físicas inscritas em cadastro de inadimplentes, bem como a redução do endividamento e facilitação de acesso ao mercado de crédito pelas mesmas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Desenrola Brasil](https://pt.wikipedia.org/wiki/Desenrola_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Desenrola Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Exportações e China

### MERC-EXP-001 — Quanto o agronegócio brasileiro exportou em 2025?

**Variantes:** Qual foi o valor das exportações do agro em 2025? · exportações agronegócio 2025 · qto o agro exportou ano passado · O agro bateu recorde de exportação em 2025?

Segundo dados do Ministério da Agricultura (MAPA), as exportações do agronegócio brasileiro somaram US$ 169,2 bilhões em 2025, valor recorde e 3% acima de 2024. O setor respondeu por 48,5% de tudo o que o Brasil exportou no ano. As importações agropecuárias foram de US$ 20,2 bilhões, gerando superávit de US$ 149,07 bilhões na balança do agronegócio.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025 · *relevância Fenasoja:* alta
*Fontes:* [ANBA – Agro brasileiro fecha 2025 com exportação recorde (dados do MAPA)](https://anba.com.br/agro-brasileiro-fecha-2025-com-exportacao-recorde/) (acesso 2026-10-17); [MAPA – Estatísticas de Comércio Exterior do Agronegócio](https://www.gov.br/agricultura/pt-br/assuntos/relacoes-internacionais/estatisticas-de-comercio-exterior) (acesso 2026-10-17)
*Notas:* Dado de comércio exterior de 2025 divulgado pelo MAPA em jan/2026. Responder "segundo o MAPA, em 2025". Para meses de 2026, consultar ao vivo a balança do agronegócio (MAPA/AgroStat).

### MERC-EXP-002 — Qual é o principal destino das exportações do agro brasileiro?

**Variantes:** Quem mais compra produtos agrícolas do Brasil? · principal comprador agro brasil · a china compra qto do agro brasileiro · Quanto a China importou do agro do Brasil em 2025?

A China. Segundo o MAPA, em 2025 a China comprou US$ 55,3 bilhões do agronegócio brasileiro, 32,7% do total exportado pelo setor, com alta de 11%. Em seguida vieram a União Europeia e os Estados Unidos.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025 · *relevância Fenasoja:* alta
*Fontes:* [ANBA – Agro brasileiro fecha 2025 com exportação recorde (dados do MAPA)](https://anba.com.br/agro-brasileiro-fecha-2025-com-exportacao-recorde/) (acesso 2026-10-17)
*Notas:* Dado de comércio exterior de 2025 divulgado pelo MAPA em jan/2026. Responder "segundo o MAPA, em 2025". Para meses de 2026, consultar ao vivo a balança do agronegócio (MAPA/AgroStat).

### MERC-EXP-003 — Quanto o Brasil exportou de soja em 2025?

**Variantes:** Quantas toneladas de soja o Brasil exportou em 2025? · exportação de soja 2025 · qto o brasil vendeu de soja pra fora · A exportação de soja bateu recorde em 2025?

Segundo o MAPA, a soja em grão foi o principal produto da pauta do agronegócio em 2025, com US$ 43,5 bilhões em receita (alta de 1,4%) e volume recorde de 108,2 milhões de toneladas embarcadas, 9,5% a mais que em 2024.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025 · *relevância Fenasoja:* alta
*Fontes:* [ANBA – Agro brasileiro fecha 2025 com exportação recorde (dados do MAPA)](https://anba.com.br/agro-brasileiro-fecha-2025-com-exportacao-recorde/) (acesso 2026-10-17)
*Notas:* Dado de comércio exterior de 2025 divulgado pelo MAPA em jan/2026. Responder "segundo o MAPA, em 2025". Para meses de 2026, consultar ao vivo a balança do agronegócio (MAPA/AgroStat).

### MERC-EXP-004 — Quantos novos mercados o agro brasileiro abriu desde 2023?

**Variantes:** Uma pergunta: quantos novos mercados o agro brasileiro abriu desde 2023? · novos mercados agro brasileiro abriu desde 2023? · quantos novos mercaos o agro brasileiro abriu desde 2023

Segundo o MAPA, o agronegócio brasileiro abriu 525 novos mercados de 2023 até o fim de 2025, o que trouxe cerca de US$ 4 bilhões em receitas adicionais, de acordo com a Secretaria de Comércio e Relações Internacionais.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025 · *relevância Fenasoja:* média
*Fontes:* [ANBA – Agro brasileiro fecha 2025 com exportação recorde (dados do MAPA)](https://anba.com.br/agro-brasileiro-fecha-2025-com-exportacao-recorde/) (acesso 2026-10-17)
*Notas:* Dado de comércio exterior de 2025 divulgado pelo MAPA em jan/2026. Responder "segundo o MAPA, em 2025". Para meses de 2026, consultar ao vivo a balança do agronegócio (MAPA/AgroStat).

### MERC-EXP-005 — Qual foi a safra de grãos 2024/25 do Brasil?

**Variantes:** Queria entender: qual foi a safra de grãos 2024/25 do Brasil? · foi safra grãos 2024 25 brasil? · qual foi a safra de graos 2024/25 do brasil

Segundo o MAPA (citando a Conab), a safra brasileira de grãos 2024/2025 chegou a 352,2 milhões de toneladas, um recorde, 17% maior que a do ciclo anterior. Esse volume ajudou a explicar o recorde nas exportações do agronegócio em 2025.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025 · *relevância Fenasoja:* alta
*Fontes:* [ANBA – Agro brasileiro fecha 2025 com exportação recorde (dados do MAPA)](https://anba.com.br/agro-brasileiro-fecha-2025-com-exportacao-recorde/) (acesso 2026-10-17); [Conab – Safra de grãos (boletins)](https://www.gov.br/conab/pt-br/atuacao/informacoes-agropecuarias/safras/safra-de-graos) (acesso 2026-10-17)
*Notas:* Número de safra 2024/25 citado pelo MAPA. Para a safra em curso (2025/26 ou 2026/27), consultar ao vivo o boletim mensal de grãos da Conab.

## Títulos do agronegócio

### MERC-CPR-001 — O que é a CPR (Cédula de Produto Rural)?

**Variantes:** Uma pergunta: o que é a CPR (Cédula de Produto Rural)? · cpr cédula produto rural? · o q e a cpr (cedula de produto rural)

A Cédula de Produto Rural (CPR), criada pela Lei nº 8.929/1994, é um título representativo de promessa de entrega de produtos rurais, emitido pelo produtor rural, suas associações ou cooperativas, com ou sem garantia. Ela permite que o produtor obtenha recursos antecipados ou insumos comprometendo parte da produção futura. Existe também a CPR com liquidação financeira, paga em dinheiro em vez da entrega física.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 8.929/1994 – Cédula de Produto Rural (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l8929.htm) (acesso 2026-10-17); [Lei nº 13.986/2020 – Lei do Agro (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2020/lei/L13986.htm) (acesso 2026-10-17)

### MERC-CPR-002 — O que é o Fiagro?

**Variantes:** Me explica uma coisa: o que é o Fiagro? · fiagro? · o q e o fiagro

O Fiagro (Fundos de Investimento nas Cadeias Produtivas Agroindustriais) foi criado pela Lei nº 14.130/2021, que alterou a lei dos fundos imobiliários para permitir fundos que investem em imóveis rurais, participações em empresas do agro, ativos financeiros e títulos de crédito do agronegócio (como CRA e CPR). Assim, investidores podem aplicar no setor agropecuário por meio de cotas negociadas no mercado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 14.130/2021 – Fiagro (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/L14130.htm) (acesso 2026-10-17)

### MERC-CPR-003 — O que mudou com a Lei do Agro (Lei 13.986/2020)?

**Variantes:** Uma pergunta: o que mudou com a Lei do Agro (Lei 13.986/2020)? · mudou lei agro lei 13 986 2020? · o q mudou com a lei do agro (lei 13.986/2020)

A Lei nº 13.986/2020, conhecida como Lei do Agro, criou o Fundo Garantidor Solidário (FGS), instituiu o patrimônio rural em afetação (permite oferecer parte do imóvel como garantia) e criou a Cédula Imobiliária Rural (CIR). Ela também tratou da escrituração (registro eletrônico) de títulos de crédito e alterou a lei da CPR (Lei nº 8.929/1994), entre outras normas. O objetivo foi ampliar e baratear o financiamento privado do agronegócio.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 13.986/2020 – Lei do Agro (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2020/lei/L13986.htm) (acesso 2026-10-17)

## Seguro rural

### MERC-SEG-001 — O que é a subvenção ao prêmio do seguro rural (PSR)?

**Variantes:** Tchê, me ajuda: o que é a subvenção ao prêmio do seguro rural (PSR)? · subvenção prêmio seguro rural psr? · o q e a subvenao ao premio do seguro rural (psr)

A Lei nº 10.823/2003 autoriza o governo federal a pagar parte do prêmio (preço) do seguro rural contratado pelo produtor, reduzindo o custo de se proteger contra perdas de safra. O seguro deve ser contratado com seguradoras autorizadas pela Susep, e os percentuais são definidos em ato do governo. Segundo a Embrapa, as avaliações de risco do Zoneamento Agrícola de Risco Climático (Zarc) orientam o PSR.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 10.823/2003 – Subvenção ao Prêmio do Seguro Rural (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/2003/l10.823.htm) (acesso 2026-10-17); [Embrapa – Rede Zarc Embrapa](https://www.embrapa.br/rede-zarc-embrapa) (acesso 2026-10-17)

### MERC-SEG-002 — Qual a relação entre o Zarc e o seguro rural ou Proagro?

**Variantes:** Alguém me explica: qual a relação entre o Zarc e o seguro rural ou Proagro? · relação zarc seguro rural proagro? · qual a relacao entre o zarc e o seguro rural ou proagro

Segundo a Embrapa, as avaliações de risco do Zarc orientam programas como o Proagro e o Programa de Subvenção ao Prêmio do Seguro Rural (PSR). Por isso, a recomendação é consultar a janela de plantio do Zarc para o município, o tipo de solo e o ciclo da cultivar antes de semear. As condições exatas de cada seguro ou do Proagro devem ser confirmadas com o agente financeiro ou a seguradora.

*kind:* `orientação` · *status:* `parcial` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Rede Zarc Embrapa](https://www.embrapa.br/rede-zarc-embrapa) (acesso 2026-10-17); [MAPA – Zoneamento Agrícola de Risco Climático](https://www.gov.br/agricultura/pt-br/assuntos/riscos-seguro/programa-nacional-de-zoneamento-agricola-de-risco-climatico/zoneamento-agricola) (acesso 2026-10-17)
*Notas:* A fonte não detalha as regras de obrigatoriedade; tratar como parcial.

## Cooperativismo

### MERC-POL-002 — Quantas pessoas são necessárias para criar uma cooperativa?

**Variantes:** Me explica uma coisa: quantas pessoas são necessárias para criar uma cooperativa? · pessoas necessárias criar cooperativa? · quantas pessoas sao necessaras pra criar uma cooperativa

Pela Lei nº 5.764/1971, a cooperativa singular deve ser constituída pelo número mínimo de 20 pessoas físicas, sendo excepcionalmente permitida a admissão de pessoas jurídicas com atividades correlatas. A lei define a Política Nacional de Cooperativismo e o regime jurídico das cooperativas.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 1971 · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 5.764/1971 – Política Nacional de Cooperativismo (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l5764.htm) (acesso 2026-10-17)
*Notas:* Regra geral da Lei 5.764/71. Leis específicas (ex.: cooperativas de trabalho, Lei 12.690/2012) podem ter mínimos diferentes; para casos específicos, orientar a procurar a OCB/Ocergs ou um contador.

### MERC-POL-003 — O que é uma cooperativa segundo a lei?

**Variantes:** Bah, uma dúvida: o que é uma cooperativa segundo a lei? · cooperativa segundo lei? · o q e uma cooperatva segundo a lei

Pela Lei nº 5.764/1971, cooperativas são sociedades de pessoas, com forma e natureza jurídica próprias, de natureza civil, não sujeitas a falência, constituídas para prestar serviços aos associados. Celebram contrato de sociedade cooperativa as pessoas que se obrigam a contribuir com bens ou serviços para uma atividade econômica de proveito comum, sem objetivo de lucro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 5.764/1971 – Política Nacional de Cooperativismo (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l5764.htm) (acesso 2026-10-17)

## Política agrícola

### MERC-POL-001 — O que é a Lei de Política Agrícola?

**Variantes:** Uma pergunta: o que é a Lei de Política Agrícola? · lei política agrícola? · o q e a lei de politca agricola

A Lei nº 8.171/1991 fixa os fundamentos, objetivos e instrumentos da política agrícola brasileira para as atividades agropecuárias, agroindustriais e de planejamento das atividades pesqueira e florestal. O art. 4º lista as ações e instrumentos, entre eles planejamento agrícola, pesquisa, assistência técnica e extensão rural, defesa da agropecuária, armazenagem, cooperativismo, crédito rural, seguro rural, irrigação e crédito fundiário.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 8.171/1991 – Política Agrícola (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l8171.htm) (acesso 2026-10-17)

## Agricultura familiar

### MERC-POL-004 — Quem é considerado agricultor familiar pela lei?

**Variantes:** Bah, uma dúvida: quem é considerado agricultor familiar pela lei? · quem considerado agricultor familiar lei? · quem e considerdo agricultor familiar pela lei

Pela Lei nº 11.326/2006, é agricultor familiar quem pratica atividades no meio rural e atende, ao mesmo tempo, a requisitos como: não ter área maior que 4 módulos fiscais; usar predominantemente mão de obra da própria família; ter percentual mínimo da renda familiar vindo do próprio estabelecimento; e dirigir o estabelecimento com a família. Silvicultores, aquicultores, extrativistas, pescadores, indígenas e quilombolas também podem ser enquadrados, conforme a lei.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 11.326/2006 – Política Nacional da Agricultura Familiar (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11326.htm) (acesso 2026-10-17)
