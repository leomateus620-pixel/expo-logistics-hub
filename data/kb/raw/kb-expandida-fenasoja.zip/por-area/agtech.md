# KB expandida — Inovação e agtech (AGTECH)

Gerado em 2026-10-17. Índice geral: [../kb-expandida.md](../kb-expandida.md). JSON da área: [agtech.json](agtech.json).

**247 perguntas canônicas · 1103 perguntas no total (canônicas + variantes).**

| confirmado | parcial | sem_fonte | conflito | dinâmico |
|---|---|---|---|---|
| 247 | 0 | 0 | 0 | 0 |

| conceito | dado | orientação |
|---|---|---|
| 241 | 0 | 6 |

**Por tipo de fonte:** Embrapa – Coleção 500 Perguntas 500 Respostas: 190; Wikipédia (pt) – verbete: 57

## Subcategorias

| Subcategoria | Entradas |
|---|---|
| Geotecnologias e agricultura de precisão | 130 |
| Recursos genéticos e biotecnologia | 60 |
| Biotecnologia | 14 |
| Conectividade e startups | 14 |
| Bioinsumos | 11 |
| Agricultura de precisão | 9 |
| Pesquisa | 6 |
| Drones | 3 |

## Entradas

## Geotecnologias e agricultura de precisão

### AGTECH-GEO-0014 — Quais satélites o Brasil tem em órbita?

**Variantes:** Queria entender: quais satélites o Brasil tem em órbita? · satélites brasil órbita? · quais satelies o brasil tem em orbita

O primeiro satélite brasileiro foi o SCD-1, lançado no nosso espaço aéreo em 9 de fevereiro de 1993, com 1 m de diâmetro e 1,45 m de altura. Ele pesa 115 kg e percorre uma órbita circular de 750 km de altitude. É equipado com baterias de níquel-cádmio recarregadas por painéis solares, formados por células de silício. O SCD-1 capta sinais de estações automáticas de coleta de dados ambientais distribuídas pelo Brasil, estimadas em mais de 750, e retransmite para a central de processamento. Os dados são usados na meteorologia, para prever o tempo ou para planejamento agrícola.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 14](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 14 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0015 — Quais as principais aplicações dos satélites, atualmente?

**Variantes:** Alguém me explica: quais as principais aplicações dos satélites, atualmente? · principais aplicações satélites atualmente? · quais as principais aplicaces dos satelites, atualmente

No nosso cotidiano, os satélites são utilizados em diversas aplicações. Muitos são responsáveis pela retransmissão da programação dos sinais dos canais de televisão e outros na transmissão dos sinais dos telefones celulares. Atualmente, um uso comum é o Sistema de Posicionamento Global (GNSS), conhecido popularmente como GPS, que permite nossa localização. Muitos desses sistemas têm função cien-tífica, voltados para investigações do clima e do meio ambiente da Terra, da agricultura e pecuária, e muitos têm aplicações militares. Existem, também, satélites cuja função é estudar, observar e monitorar distantes áreas do universo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 15](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 15 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0020 — Quanto custam as informações produzidas por satélites?

**Variantes:** Bah, uma dúvida: quanto custam as informações produzidas por satélites? · custam informações produzidas satélites? · quanto custam as informacoes produzias por satelites

Esta é uma pergunta é complexa, pois depende de diversas variáveis. Quando as empresas já possuem a imagem que o usuário deseja (produtos de catálogo), elas podem ter um custo menor. Caso seja necessário redirecionar o satélite para uma área, em uma data específica, há um aumento significativo no preço. A resolução espacial e a resolução espectral também afetam significativamente o preço da imagem. Geralmente, determina-se uma medida de área no momento em que é feito o orçamento, por exemplo, o quilômetro quadrado, mas as empresas normalmente comercializam uma área mínima, independentemente da área desejada pelo cliente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 20](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 20 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0033 — O que é sensoriamento remoto?

**Variantes:** Bah, uma dúvida: o que é sensoriamento remoto? · sensoriamento remoto? · o q e sensoriameto remoto

É a ciência e a arte de coletar dados ou informações de um objeto a partir da energia refletida por esse objeto. Os satélites artificiais são exemplos de sensores remotos porque são capazes de captar a energia eletromagnética refletida ou emitida por objetos ou alvos presentes na Terra, por meio de seus sensores (passivos ou ativos). Após interagir com a radiação eletromagnética incidente (radiância), alvos ou objetos (vegetação, recursos hídricos, edificações, áreas agrícolas, etc.) refletem essa radiação (irradiância) de forma diferente, e isso representa sua assinatura espectral.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 33](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 33 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0035 — O que são geotecnologias?

**Variantes:** Bah, uma dúvida: o que são geotecnologias? · geotecnologias? · o q sao geotecnologas

São conjuntos de técnicas e métodos científicos aplicados à análise, à exploração, ao estudo e à conservação dos recursos naturais, considerando diferentes escalas e a informação espacial (localização geográfica). As geotecnologias também são usadas para estudar a paisagem (topografia, hidrografia, geologia e geomorfologia) e variáveis ambientais (temperatura, pluviosidade e radiação solar), analisar e auxiliar na prevenção de desastres naturais (enchentes, terremotos e erupções vulcânicas), além de gerenciar e de monitorar a atividade humana (infraestrutura, agropecuária e dados socioeconômicos).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 35](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 35 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0036 — Quais as tecnologias incluídas nas geotecnologias?

**Variantes:** Bah, uma dúvida: quais as tecnologias incluídas nas geotecnologias? · tecnologias incluídas geotecnologias? · quais as tecnologas incluidas nas geotecnologias

As geotecnologias incluem tecnologias de processamento e armazenamento de dados geoespaciais por meio dos seguintes sistemas: • Sistemas de informações geográficas (SIG). • Sistema de navegação global por satélite (GNSS). • Sistemas de processamento de imagens (SPI).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 36](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 36 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0041 — Como se obtém informações sobre os principais satélites de mapeamento da agricultura e dos recursos naturais?

**Variantes:** Bah, uma dúvida: como se obtém informações sobre os principais satélites de mapeamento da agricultura e dos recursos naturais? · obtém informações principais satélites mapeamento agricultura recursos? · como se obtem informacoes sobre os principais satelites de mapeamento da agricultra e dos recursos naturais

Para contribuir na disseminação de informações geoespaciais atualizadas, a Embrapa Monitoramento por Satélite organizou o website Satélites de Monitoramento, com os principais satélites e sistemas de sensores remotos usados em agricultura e em recursos naturais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 41](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 41 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0049 — Geotecnologias: quais as metodologias que a Embrapa utiliza para mapear pastagens?

**Variantes:** Bah, uma dúvida: quais as metodologias que a Embrapa utiliza para mapear pastagens (geotecnologias)? · metodologias embrapa utiliza mapear pastagens (geotecnologias)? · quais as metodologas q a embrapa utiliza pra mapear pastagens (geotecnologias)

Na Embrapa, o mapeamento das áreas de pastagens plantadas é feito a partir de métodos de processamento digital de imagens e classificação. Métodos para qualificar processo de degradação dessas pastagens. Diferentes combinações de métodos e satélites/ sensores estão sendo testados, incluindo-se: • Tratamento de séries temporais. • Modelos de mistura espectral. • Classificação por objetos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 49](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 49 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0050 — Geotecnologias: como é feito o mapeamento de sistemas de produção como o Integração Lavoura-Pecuária-Floresta (iLPF)?

**Variantes:** Uma pergunta: como é feito o mapeamento de sistemas de produção como o Integração Lavoura-Pecuária-Floresta (iLPF) (geotecnologias)? · feito mapeamento sistemas produção integração lavoura-pecuária-floresta ilpf (geotecnologias)? · como e feito o mapeamento de sistemas de produao como o integracao lavoura-pecuaria-floresta (ilpf) (geotecnologias)

O mapeamento de sistemas diversificados como iLPF e suas variações: integração lavoura-pecuária (agropastoril), lavourapecuária-floresta (agrossilvipastoril), pecuária-floresta (silvipastoril) e lavoura-floresta (silviagrícola ou agroflorestal) está em franco desenvolvimento metodológico. Nesse caso, o diferencial é o entendimento de sua dinâmica espacial e temporal. As geotecnologias têm potencial para caracterizar diferentes componentes vegetais das culturas agrícolas, pastagens e florestas consorciadas por meio de sensores remotos com distintas resoluções espectrais, temporais e espaciais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 50](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 50 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0051 — Como as geotecnologias podem ser aplicadas no estudo e no monitoramento de animais?

**Variantes:** Bah, uma dúvida: como as geotecnologias podem ser aplicadas no estudo e no monitoramento de animais? · geotecnologias aplicadas estudo monitoramento animais? · como as geotecnologas podem ser aplicadas no estudo e no monitoramento de animais

O uso de geotecnologias vem sendo cada vez mais usado como ferramenta para estudar e monitorar animais, tanto em ambientes naturais como em ambientes antropizados. Exemplos incluem: • Uso de imagens de sensoriamento remoto para a seleção de locais de amostragem da fauna em campo. • Análise da distribuição espacial de espécies em seu habitat ou o apoio ao rastreamento de bovinos em tempo real.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 51](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 51 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0065 — Geotecnologias: qual a importância desses serviços na interoperabilidade dos sistemas WebGIS?

**Variantes:** Tchê, me ajuda: qual a importância desses serviços na interoperabilidade dos sistemas WebGIS (geotecnologias)? · importância desses serviços interoperabilidade sistemas webgis (geotecnologias)? · qual a importancia desses servios na interoperabilidade dos sistemas webgis (geotecnologias)

O uso de tecno-logias e ferramentas – baseado em geoserviços padronizados mun- dialmente – é um fator importantíssimo para garantir comunicação, compartilhamento e reuso de dados e funções entre um sistema que está sendo desenvolvido e outros sistemas e programas de informação geográfica disponíveis no mercado. Os padrões de geoserviços são especificados pelo Open Geospatial Consortium (OGC), organização não governamental responsável por definir padrões de interoperabilidade entre sistemas de informação geográfica. Referências BRASIL. Lei nº 12.651, de 25 de maio de 2012.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 65](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 65 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0075 — Geotecnologias: o que são VANTs?

**Variantes:** Me tira uma dúvida: o que são VANTs (geotecnologias)? · vants (geotecnologias)? · o q sao vants (geotecnologias)

A sigla VANT significa veículo aéreo não tripulado, que possua algum tipo de aplicação científica, militar ou outras, e deve ser consi-derado como uma aeronave, mesmo sendo pilotado remotamente, conforme o Código Brasileiro da Aeronáutica (Lei 7.565/1986). Em inglês, são denominados de drones ou UAV (unmanned aerial vehicle).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 75](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 75 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0078 — Como as geotecnologias podem ajudar no planejamento racional de ocupação de espaço para moradias urbanas?

**Variantes:** Tchê, me ajuda: como as geotecnologias podem ajudar no planejamento racional de ocupação de espaço para moradias urbanas? · geotecnologias ajudar planejamento racional ocupação espaço moradias? · como as geotecnologias podem ajudar no planejamento racional de ocupacao de espaco pra moradas urbanas

As geotecnologias contribuem fornecendo informações técnicas, como relevo, tipo e estrutura do solo local, hidrografia, drenagem, entre outras, que em conjunto com imagens de satélite e visitas de campo, permitem identificar áreas de risco (altas declividades, deslizamentos de terra, áreas de inundação, etc.). Assim, os responsáveis pela formulação da política de uso do solo urbano podem tomar decisões mais adequadas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 78](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 78 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0079 — O que é Gerenciamento Global da Informação Geoespacial (GGIM)?

**Variantes:** Tchê, me ajuda: o que é Gerenciamento Global da Informação Geoespacial (GGIM)? · gerenciamento global informação geoespacial ggim? · o q e gerenciamento global da informacao geoespacal (ggim)

É uma iniciativa da Organização das Nações Unidas (ONU) que visa salientar a importância da disponibilização da informação continental para promover o desenvolvimento do transporte, energia e comunicações, de forma sustentável e equitativa nos países, motivando o desenvolvimento de estratégias e padrões de forma coordenada, contribuindo para seu compartilhamento e integração do setor.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 79](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 79 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0080 — O que é Cloud Computing e como está relacionada à geoinformação?

**Variantes:** Tchê, me ajuda: o que é Cloud Computing e como está relacionada à geoinformação? · cloud computing está relacionada geoinformação? · o q e cloud computng e como esta relacionada a geoinformacao

Cloud Computing significa computação em nuvem e refere-se à utilização da memória, capacidade de armazenamento, cálculo de computadores e servidores compartilhados e interligados por meio da Internet, seguindo o princípio da computação em grade. O armazenamento de dados – que podem ou não ser georreferenciados – é feito em serviços que poderão ser acessados de qualquer lugar do mundo, a qualquer hora, não havendo necessidade de instalação de programas ou de armazenar dados. O acesso a programas, serviços e arquivos é remoto, através da Internet, daí a alusão à nuvem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 80](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 80 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0102 — O que é imagem georreferenciada?

**Variantes:** Alguém me explica: o que é imagem georreferenciada? · imagem georreferenciada? · o q e imagem georreferencida

Diz-se que a imagem é georreferenciada quando seus pixels estão geograficamente identificados, ou seja, quando possuem coordenadas geográficas ou coordenadas de um sistema de projeção conhecido que permita identificar a que ponto da superfície terrestre eles correspondem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 102](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 102 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0112 — Geotecnologias: o que é NDVI e qual sua utilidade?

**Variantes:** Me explica uma coisa: o que é NDVI e qual sua utilidade (geotecnologias)? · ndvi utilidade (geotecnologias)? · o q e ndvi e qual sua utilidde (geotecnologias)

O Índice Vegetativo da Diferença Normalizada (NDVI) é um índice espectral calculado a partir dos valores de reflectância das bandas do infravermelho próximo (NIR) e do vermelho (RED) pela fórmula: NDVI = (NIR - RED)/(NIR + RED). Os valores de NDVI variam de -1 a 1; valores próximos de 1 indicam áreas de vegetação densa. A fórmula do NDVI – aplicada aos valores dos pixels de imagens de reflectância do NIR e do RED – geram uma imagem de NDVI que realça as variações de densidade da cobertura vegetal. As imagens de NDVI são empregadas em estudos de medida de índice de área foliar, para determinar a porcentagem de cobertura do solo e estimar a radiação fotossinteticamente ativa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 112](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 112 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0120 — Quais as principais aplicações de sensoriamento remoto na agricultura?

**Variantes:** Bah, uma dúvida: quais as principais aplicações de sensoriamento remoto na agricultura? · principais aplicações sensoriamento remoto agricultura? · quais as principais aplicacoes de sensoriameto remoto na agricultura

O sensoriamento remoto é usado na estimativa de áreas plantadas, na identificação das culturas plantadas e no monitoramento da expansão e da alteração de uso das áreas agrícolas. A associação de informações sobre áreas plantadas e dados de chuva e temperatura como os fornecidos pelos sensores TRMM e MODIS pode auxiliar na previsão de safras em nível nacional, visto que a deficiência hídrica é um fator fundamental para determinação da determinar a produtividade agrícola.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 120](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 120 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0138 — O que são dados e informações geoespaciais?

**Variantes:** Me tira uma dúvida: o que são dados e informações geoespaciais? · dados informações geoespaciais? · o q sao dados e informacoes geoespaciis

São aqueles dados que associam a cada entidade ou fenômeno a uma localização, em dado instante ou período de tempo. As informações geoespaciais podem ou não ser imagens.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 138](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 138 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0139 — Geotecnologias: o que é a Inde?

**Variantes:** Queria entender: o que é a Inde (geotecnologias)? · inde (geotecnologias)? · o q e a inde (geotecnologias)

É um conjunto integrado de tecnologias, políticas, mecanismos e procedimentos de coordenação e monitoramento, padrões e acordos, necessário para facilitar e ordenar a geração, o armazenamento, o acesso, o compartilhamento, a disseminação e o uso dos dados geoespaciais de origem federal, estadual, distrital e municipal. A Infraestrutura Nacional de Dados Espaciais (Inde) foi instituída pelo Decreto nº 6.666 de 27/11/2008 (BRASIL, 2008b).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 139](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 139 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0140 — Geotecnologias: quais as categorias de dados da Inde?

**Variantes:** Tu sabe me dizer: quais as categorias de dados da Inde (geotecnologias)? · categorias dados inde (geotecnologias)? · quais as categoras de dados da inde (geotecnologias)

Os dados geoespaciais fornecidos pela Inde são divididos em três categorias: • Dados de referência. • Dados temáticos. • Dados de valor agregado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 140](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 140 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0141 — Geotecnologias: o que são dados de referência?

**Variantes:** Bah, uma dúvida: o que são dados de referência (geotecnologias)? · dados referência (geotecnologias)? · o q sao dados de referenia (geotecnologias)

São aqueles que apresentam informações genéricas de uso não particularizado, imprescindíveis ao georreferenciamento e à contextualização geográfica de todas as temáticas territoriais especificas. Entende-se por dados de referência, dados sobre os quais se constrói ou se referencia qualquer outro dado de referência ou temático.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 141](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 141 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0142 — Geotecnologias: o que são dados temáticos?

**Variantes:** Alguém me explica: o que são dados temáticos (geotecnologias)? · dados temáticos (geotecnologias)? · o q sao dados tematios (geotecnologias)

São aqueles que tratam de determinado fenômeno ou temática (e.g. mapas de elevação, tipos de solo, geologia, vegetação, clima, etc.) em determinada região ou em todo o País. Incluem valores qualitativos e quantitativos e, normalmente, estão ligados aos objetivos centrais da gestão dos seus respectivos produtores.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 142](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 142 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0143 — Geotecnologias: o que são dados de valor agregado?

**Variantes:** Bah, uma dúvida: o que são dados de valor agregado (geotecnologias)? · dados valor agregado (geotecnologias)? · o q sao dados de valor agregdo (geotecnologias)

São aqueles adicionados por usuários ou produtores (públicos ou privados) aos dados de referência ou temáticos, por exigência de determinado interesse e utilização especifica, e que podem pertencer aos âmbitos setoriais, regionais, estaduais, municipais, urbanos e outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 143](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 143 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0144 — O que é um registro de metadados geoespaciais?

**Variantes:** Queria entender: o que é um registro de metadados geoespaciais? · registro metadados geoespaciais? · o q e um regisro de metadados geoespaciais

É um arquivo de informações, normalmente um documento XML, que contém as informações relevantes de um dado. Um registro de metadados geoespaciais é a dados com extensão geográfica implícita ou explícita e usados para documentar recursos geográficos digitais, como: • Dados de imageamento terrestre. • Base de dados geoespaciais, etc.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 144](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 144 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0146 — Geotecnologias: qual a importância do uso de padrões de metadados?

**Variantes:** Me tira uma dúvida: qual a importância do uso de padrões de metadados (geotecnologias)? · importância uso padrões metadados (geotecnologias)? · qual a importancia do uso de padroes de metadaos (geotecnologias)

O uso de um padrão comum de metadados provê um conjunto de informações descritivas sobre os dados, incluindo as características do seu levantamento, produção, qualidade e estrutura de armazenamento, essenciais para promover sua documentação, integração e disponibilização, bem como possibilitar sua busca e exploração. Entre os padrões mais conhecidos de metadados para dados geoespaciais estão o FGDC e o ISO 19115.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 146](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 146 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0147 — O que é uma base de dados geoespaciais?

**Variantes:** Tchê, me ajuda: o que é uma base de dados geoespaciais? · base dados geoespaciais? · o q e uma base de dados geoespaciis

É uma base otimizada de dados para armazenar, indexar e buscar dados que representam o espaço geográfico. Distingue-se pela componente espacial e pode ser derivado, entre outras fontes, de mapeamento ou de sensoriamento remoto.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 147](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 147 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0148 — Geotecnologias: o que é Catálogo de Metadados Espaciais ou o Diretório de Metadados?

**Variantes:** Uma pergunta: o que é Catálogo de Metadados Espaciais ou o Diretório de Metadados (geotecnologias)? · catálogo metadados espaciais diretório metadados (geotecnologias)? · o q e catalogo de metadaos espaciais ou o diretorio de metadados (geotecnologias)

É um sistema de servidores para armazenar, preservar e acessar Metadados Serviços e Dados Geoespaciais, essencial para se indexar busca de dados geoespaciais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 148](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 148 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0149 — Geotecnologias: o que é Perfil MGB?

**Variantes:** Tchê, me ajuda: o que é Perfil MGB (geotecnologias)? · perfil mgb (geotecnologias)? · o q e perfil mgb (geotecnologias)

O Perfil de Metadados Geoespaciais Brasileiros (MGB) é um subconjunto da norma ISO 19115, definido pela Comissão Nacional de Cartografia (Concar), para documentar informações geoespaciais com o propósito de catalogar, integrar e harmonizar dados geoespaciais existentes nas instituições do governo brasileiro, produtoras e mantenedoras desse tipo de dado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 149](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 149 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0150 — O que é o Diretório Brasileiro de Dados Geoespaciais?

**Variantes:** Me explica uma coisa: o que é o Diretório Brasileiro de Dados Geoespaciais? · diretório brasileiro dados geoespaciais? · o q e o diretoio brasileiro de dados geoespaciais

De conformidade com o Decreto 6.666/2008, Diretório Brasileiro de Dados Geoespaciais (DBDG) é «[...] um sistema de servidores de dados, distribuídos na rede mundial de computadores, capaz de reunir eletronicamente produtores, gestores e usuários de dados geoespaciais, com vistas ao armazenamento, compartilhamento e acesso a esses dados e aos serviços relacionados» (BRASIL, 2008b, art. 2°, inciso IV).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 150](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 150 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0151 — O que é o Geonetwork?

**Variantes:** Me explica uma coisa: o que é o Geonetwork? · geonetwork? · o q e o geonetwrk

É um catálogo de metadados livre, de código aberto, aderente aos padrões adotados na Infraestrutura Nacional de Dados Espaciais (Inde), como parte do ferramental provido pela Open Source Geoespatial Foundation (Osgeo). Essa ferramenta é recomendada no plano de ação, para implantar a Inde para carga e gestão de metadados geoespaciais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 151](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 151 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0152 — Geotecnologias: o que é a Concar?

**Variantes:** Queria entender: o que é a Concar (geotecnologias)? · concar (geotecnologias)? · o q e a concar (geotecnologias)

É a Comissão Nacional de Cartografia (Concar), um órgão colegiado do Ministério do Planejamento, Orçamento e Gestão, atualizada conforme Decreto s/n° de 1° de agosto de 2008 (BRASIL, 2008a), remanescente do antigo Cocar, instituído pelo Decreto-Lei 243 de 28, de fevereiro de 1967 (BRASIL, 1967), que fixa as diretrizes e bases da cartografia brasileira e dá outras providências. A Concar responde pelo Conselho Superior da Inde e exerce a atribuição de cumprir os papéis normativo e diretivo dessa instituição.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 152](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 152 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0154 — O que são geoserviços?

**Variantes:** Tchê, me ajuda: o que são geoserviços? · geoserviços? · o q sao geoservios

São funcionalidades que permitem que o usuário acesse os dados e os metadados geoespaciais por meio de protocolos de comunicação pela internet. Um exemplo é o Web Map Service (WMS), que define um mapa como representação de informação geográfica em forma de arquivo digital de imagens adequadas para serem exibidas em tela de um computador. Normalmente, os mapas produzidos pelos serviços WMS são uma imagem no formato PNG, GIF ou JPEG.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 154](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 154 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0156 — O que é geoprocessamento?

**Variantes:** Bah, uma dúvida: o que é geoprocessamento? · geoprocessamento? · o q e geoprocessameto

Consiste no uso de ferramentas computacionais para tratamento e análise de dados geográficos. O conjunto dessas ferramentas, integrado em Sistemas de Informação Geográfica (SIGs ou GIS na sigla em inglês), permite analisar e cruzar dados oriundos de diversas fontes, facilitando a extração de informação e a tomada de decisão.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 156](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 156 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0158 — Quais dados podem ser representados num Sistema de Informação Geográfica (SIG)?

**Variantes:** Me tira uma dúvida: quais dados podem ser representados num Sistema de Informação Geográfica (SIG)? · dados representados num sistema informação geográfica sig? · quais dados podem ser representados num sistema de informaao geografica (sig)

Um SIG pode representar grande variedade de dados espaciais, como localização e delimitação de áreas de interesse, redes de distribuição, topografia, juntamente com outros atributos. Assim, é possível representar: • Localização de poços. • Estações meteorológicas e dados relacionados (qualidade de água, temperatura, precipitação). • Redes de drenagem. • Estradas. • Mapas de solo. • Delimitações de municípios. • Mapas de uso e cobertura da terra. • Curvas de nível, etc.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 158](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 158 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0161 — O que são SIGs On-line ou WebGIS?

**Variantes:** Alguém me explica: o que são SIGs On-line ou WebGIS? · sigs on-line webgis? · o q sao sigs on-line ou webgis

São sistemas computacionais em rede que disponibilizam informações geográficas para visualização e consultas. Tais sistemas devem ainda prover acesso a um banco de dados espaciais que permita a usuários consultar, visualizar e modificar mapas disponíveis.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 161](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 161 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0162 — Quais tipos de análise podem ser feitos em num SIG?

**Variantes:** Uma pergunta: quais tipos de análise podem ser feitos em num SIG? · tipos análise feitos num sig? · quais tipos de analise podem ser feitos em num sig

Uma das principais análises feitas num SIG é a análise espacial. Esse tipo de análise trabalha com dados em que uma das variáveis é a localização geográfica dos objetos, ou análises baseadas nas relações espaciais entre objetos avaliados. A análise espacial permite que o usuário estude a localização de um determinado evento, como por exemplo, queimadas no Bioma Amazônia, e o relacionamento espacial entre as feições estudadas, como: • A distância entre focos de incêndio e estradas. • A relação entre ocorrência de doenças. • Indicadores de saneamento básico etc. Trabalhando-se com dados de diferentes épocas, também é possível fazer uma análise multitemporal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 162](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 162 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0164 — Onde obter dados para análises em SIG?

**Variantes:** Uma pergunta: onde obter dados para análises em SIG? · obter dados análises sig? · onde obter dados pra analies em sig

Os dados para análises espaciais podem vir de diferentes fontes. Podem ser obtidos em levantamentos de campo ou adquiridos de terceiros. Muitos dos órgãos oficiais de estatística e geografia ou órgãos do governo disponibilizam mapas base que podem ser integrados nas análises espaciais. Existem também grupos de pesquisa que disponibilizam as informações com que trabalham. Grande parte desses dados pode ser acessada pela internet, tomando-se os devidos cuidados para dar crédito às fontes de forma correta e de se verificar a qualidade das informações.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 164](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 164 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0165 — Geotecnologias: o que são dados vetoriais e matriciais?

**Variantes:** Me tira uma dúvida: o que são dados vetoriais e matriciais (geotecnologias)? · dados vetoriais matriciais (geotecnologias)? · o q sao dados vetoriais e matriciis (geotecnologias)

Os Sistemas de Informação Geográfica (SIGs) usam duas formas básicas para representar os dados espaciais: Representação de dados vetoriais – Usa um ou mais pares de coordenadas para representar pontos, linhas e polígonos e a relação dessas feições com seus diferentes atributos. Representação de dados matriciais – Usa uma grade composta por linhas e colunas para representar alguma informação de interesse no espaço, ou seja, uma matriz de valores (também conhecidos como dados raster). Uma característica importante desses dados é a resolução espacial, ou seja, a área no terreno que é representada pela menor unidade presente na imagem (pixel).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 165](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 165 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0166 — Geotecnologias: quais dados podem ser representados no formato vetorial e matricial e quais as diferenças entre eles?

**Variantes:** Alguém me explica: quais dados podem ser representados no formato vetorial e matricial e quais as diferenças entre eles (geotecnologias)? · dados representados formato vetorial matricial diferenças eles (geotecnologias)? · quais dados podem ser representaos no formato vetorial e matricial e quais as diferencas entre eles (geotecnologias)

Dados com variáveis discretas pontuais ou que representem feições lineares são mais facilmente representados utilizando vetores (ex.: estações meteorológicas, localização de endereços numa cidade, rios, estradas): Dados com variáveis contínuas – Distribuídas numa área determinada são mais bem representados por meio de matrizes (ex.: precipitação, temperatura, imagens de sensores remotos etc.). Dados temáticos – Descrevem classes de alguma variável numa região, podem utilizar tanto a representação matricial quanto vetorial. Alguns exemplos de dados temáticos incluem: mapas de solo, de uso e cobertura da terra, divisão de estados, regiões, distribuição do produto interno bruto (PIB) e outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 166](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 166 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0169 — Geotecnologias: o que é um shapefile ou arquivo shape?

**Variantes:** Me explica uma coisa: o que é um shapefile ou arquivo shape (geotecnologias)? · shapefile arquivo shape (geotecnologias)? · o q e um shapefle ou arquivo shape (geotecnologias)

É um formato de arquivo muito usado para armazenar dados vetoriais. Esse formato foi desenvolvido pela empresa ESRI no início da década de 1990. Com o tempo, o shapefile se tornou muito difundido entre os usuários, sendo que a maioria dos SIGs é capaz de ler e escrever nesse formato. Um shapefile é composto por mais de um arquivo, todos com o mesmo nome, mas com extensões diferentes, incluindo: • shp. • shx. • dbf. • pr.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 169](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 169 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0170 — Geotecnologias: o que é um buffer?

**Variantes:** Uma pergunta: o que é um buffer (geotecnologias)? · buffer (geotecnologias)? · o q e um buffer (geotecnologias)

É um modelo matemático que estabelece a distância euclidiana de um determinado objeto: ponto, linha, polígono (em caso de dados vetoriais) ou pixel (em caso de dados matriciais), delimitando uma área ao redor do objeto estudado. Como exemplo, pode-se citar a determinação do entorno de uma unidade de conservação ou de um curso d’água, onde até certa distância algumas restrições devem ser respeitadas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 170](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 170 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0171 — Qual a precisão de um SIG? E em qual escala ele trabalha?

**Variantes:** Bah, uma dúvida: qual a precisão de um SIG? E em qual escala ele trabalha? · precisão sig escala ele trabalha? · qual a preciao de um sig e em qual escala ele trabalha

A precisão e a escala de um SIG dependem dos dados de entrada usados nos processamentos e análises. Ressalta-se a importância dos metadados, pois o usuário deve conhecer a informação usada, tal como escala, ano de obtenção, etc.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 171](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 171 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0177 — Geotecnologias: como converter um sistema de projeção cartográfica em outro?

**Variantes:** Me tira uma dúvida: como converter um sistema de projeção cartográfica em outro (geotecnologias)? · converter sistema projeção cartográfica outro (geotecnologias)? · como converer um sistema de projecao cartografica em outro (geotecnologias)

A conversão dos mapas de um sistema de projeção para outro deve ser feita dentro do SIG. A forma de se fazer essa conversão depende do programa adotado. Recomenda-se que o usuário consulte o Manual do SIG que está usando para verificar a maneira mais adequada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 177](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 177 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0182 — Geotecnologias: quais os tipos de aparelhos receptores existentes?

**Variantes:** Me tira uma dúvida: quais os tipos de aparelhos receptores existentes (geotecnologias)? · tipos aparelhos receptores existentes (geotecnologias)? · quais os tipos de aparelos receptores existentes (geotecnologias)

De acordo com a aplicação, podem-se classificar os receptores em: • Receptor de navegação. • Receptor geodésico. • Receptor para SIG (Sistema de Informação Geográfica).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 182](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 182 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0189 — Geotecnologias: como converter as coordenadas UTM para latitude/longitude? E vice-versa?

**Variantes:** Queria entender: como converter as coordenadas UTM para latitude/longitude? E vice-versa (geotecnologias)? · converter coordenadas utm latitude longitude vice-versa (geotecnologias)? · como converter as coordenaas utm pra latitude/longitude e vice-versa (geotecnologias)

Os cálculos envolvidos na transformação de coordenadas são bem complexos, mas existem vários programas, disponíveis na internet, que realizam as transformações entre coordenadas. Além disso, muitos dos SIGs dispõem de ferramentas para a conversão dos dados entre diferentes sistemas de coordenadas e projeções. Para converter as coordenadas UTM em latitude/longitude, é preciso saber: • O hemisfério (norte ou sul). • O meridiano central ou a zona UTM. • O sistema de coordenadas – SAD69, WGS 84, SIRGAS 2000.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 189](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 189 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0195 — Qual a importância do Sistema de Informação Geográfica (SIG) em agrometeorologia?

**Variantes:** Me tira uma dúvida: qual a importância do Sistema de Informação Geográfica (SIG) em agrometeorologia? · importância sistema informação geográfica sig agrometeorologia? · qual a importancia do sistema de informacao geografica (sig) em agrometeoroloia

Geralmente, o SIG é uma ferramenta de geoprocessamento que permite o armazenamento, a recuperação, a manipulação e a análise espacial de dados agrometeorológicos com aplicação em estudos de diferentes escalas de produção agropecuária.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 195](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 195 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0196 — Geotecnologias: como é utilizada a informação obtida?

**Variantes:** Bah, uma dúvida: como é utilizada a informação obtida (geotecnologias)? · utilizada informação obtida (geotecnologias)? · como e utilizda a informacao obtida (geotecnologias)

Dispondo-se de computadores, de programas específicos e de imagens de satélite, é possível por em prática uma série de procedimentos para processar essas informações e assim obter dados georreferenciados, que permitem localizar as áreas de estudo de maneira fidedigna.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 196](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 196 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0198 — Geotecnologias: como funcionam os radares meteorológicos?

**Variantes:** Bah, uma dúvida: como funcionam os radares meteorológicos (geotecnologias)? · funcionam radares meteorológicos (geotecnologias)? · como funcioam os radares meteorologicos (geotecnologias)

Auxiliam na previsão de tempo de curto prazo, precavendo contra inundações, pois permitem a emissão de alerta meteorológico da presença de nuvens com grande potencial de precipitação intensa, assim como decisão de irrigação e incidência de granizo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 198](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 198 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0208 — Geotecnologias: quais as diferenças entre os conceitos de evapotranspiração?

**Variantes:** Me explica uma coisa: quais as diferenças entre os conceitos de evapotranspiração (geotecnologias)? · diferenças conceitos evapotranspiração (geotecnologias)? · quais as diferenas entre os conceitos de evapotranspiracao (geotecnologias)

Evapotranspiração de referência (ETo) – É a taxa de transferência do vapor d’água para a atmosfera, de uma superfície de referência hipotética, podendo ser grama ou alfafa, sem limitações hídricas, cobrindo totalmente o solo. Evapotranspiração potencial – É a taxa de transferência do vapor d’água de uma superfície vegetada, sem limitação hídrica, em boas condições fitossanitárias, representando o potencial de produção para uma dada condição climática. Evapotranspiração atual ou real – É a taxa de transferência do vapor d’água de uma superfície vegetada em qualquer circunstância. Pode-se utilizar Sistemas de Informação Geográfica (SIGs)

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 208](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 208 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0219 — Geotecnologias: o que é produtividade da água?

**Variantes:** Alguém me explica: o que é produtividade da água (geotecnologias)? · produtividade água (geotecnologias)? · o q e produtividde da agua (geotecnologias)

É a razão do rendimento líquido de culturas, florestas e pesca, e a quantidade de água requerida para a produção desses benefícios. Em culturas agrícolas, é possível determinar a produtividade da água por sensoriamento remoto, com dados de radiação solar e NDVI.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 219](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 219 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0226 — Geotecnologias: quais os fenômenos terrestres do ciclo hidrológico?

**Variantes:** Me explica uma coisa: quais os fenômenos terrestres do ciclo hidrológico (geotecnologias)? · fenômenos terrestres ciclo hidrológico (geotecnologias)? · quais os fenomeos terrestres do ciclo hidrologico (geotecnologias)

Os movimentos permanentes da água na fase terrestre compreendem, principalmente, os seguintes fenômenos: • Evaporação. • Transpiração. • Precipitação. • Interceptação vegetal. • Escoamento superficial. • Infiltração no solo. • Escoamento subsuperficial e subterrâneo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 226](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 226 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0227 — Qual a importância da geotecnologia para estudos hidrológicos?

**Variantes:** Uma pergunta: qual a importância da geotecnologia para estudos hidrológicos? · importância geotecnologia estudos hidrológicos? · qual a importancia da geotecnoloia pra estudos hidrologicos

A geotecnologia facilita e aprimora estudos hidrológicos ao considerar a variação espacial e/ou temporal das variáveis hidrológicas. O crescente potencial do sensoriamento remoto e de SIGs para representar a informação espacial e temporal de bacias hidrográficas de maneira rápida, por meio de mapas de uso do solo, juntamente com dados topográficos, possibilitam o desenvolvimento de modelos hidrológicos mais acurados, que subsidiam tomadas de decisões. Um exemplo é o estudo da estimativa do valor do escoamento superficial da água sobre o solo, que produz informações importantes a respeito da infiltração da água no solo e da recarga de aquíferos subterrâneos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 227](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 227 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0228 — Geotecnologias: o que é rede hidrológica?

**Variantes:** Alguém me explica: o que é rede hidrológica (geotecnologias)? · rede hidrológica (geotecnologias)? · o q e rede hidrologca (geotecnologias)

É um conjunto de estações ou postos distribuídos sobre a superfície terrestre e equipados com um ou mais instrumentos de coleta de dados hidrométricos básicos. No Brasil, os instrumentos mais comuns são pluviômetros e réguas linimétricas, que possibilitam medir respectivamente, o volume das chuvas e os níveis dos rios (cota).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 228](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 228 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0229 — Geotecnologias: como são gerados dados de vazão de um rio?

**Variantes:** Uma pergunta: como são gerados dados de vazão de um rio (geotecnologias)? · gerados dados vazão rio (geotecnologias)? · como sao gerados dados de vazao de um rio (geotecnologias)

As vazões de um rio são estimadas a partir da relação (equação) entre as leituras das réguas linimétricas/linígrafo e valores de vazão obtidos por meio de medições feitas no local, com equipamentos específicos para essa finalidade, como molinetes fluviométricos. Assim, após uma série de medições de vazão, é ajustada uma equação denominada pelos hidrólogos de “curva chave”, que possibilita gerar dados de descarga líquida a partir das leituras linimétricas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 229](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 229 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0230 — Geotecnologias: como se pode saber se em determinada região existem dados hidrometeorológicos e como se pode obtê-los?

**Variantes:** Tu sabe me dizer: como se pode saber se em determinada região existem dados hidrometeorológicos e como se pode obtê-los (geotecnologias)? · saber determinada região dados hidrometeorológicos obtê-los (geotecnologias)? · como se pode saber se em determinada regiao existem dados hidrometeorologios e como se pode obte-los (geotecnologias)

A melhor forma de se conhecer esses dados é consultando o sistema de informações hidrológicas da Agência Nacional de O nível de um curso d’água também pode ser obtido, automaticamente, por meio de equipamento denominado linígrafo. Águas (ANA), por meio do portal HidroWeb ou do portal do Sistema Nacional de Informações sobre Recursos Hídricos. A rede hidrometeorológica da ANA reúne: • Dados de milhares de estações de medições de volume de chuvas. • Evaporação da água. • Nível e vazão de rios. • Quantidade de sedimento. • Qualidade da água. Esses dados podem ser obtidos, gratuitamente, via download diretamente do portal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 230](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 230 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0234 — Como obter mapas de drenagens?

**Variantes:** Me explica uma coisa: como obter mapas de drenagens? · obter mapas drenagens? · como obter mapas de drenagns

Mapas de drenagem podem ser obtidos de cartas topográficas ou a partir da identificação dos cursos de drenagem em pares estereoscópicos de fotos aéreas. Também é possível identificar os cursos d’água usando-se imagens de sensores remotos orbitais, principalmente quando os produtos são considerados mais recentes, com elevada resolução espacial. Outra maneira de identificar as drenagens é por meio de métodos de geoprocessamento que simulam o escoamento da água na superfície do terreno, a partir de um modelo digital de elevação (MDE).

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 234](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 234 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### AGTECH-GEO-0238 — Geotecnologias: como se delimita uma bacia hidrográfica usando-se um MDE?

**Variantes:** Queria entender: como se delimita uma bacia hidrográfica usando-se um MDE (geotecnologias)? · delimita bacia hidrográfica usando-se mde (geotecnologias)? · como se delimita uma bacia hidrografca usando-se um mde (geotecnologias)

O procedimento é semelhante ao usado para delimitar a rede de drenagem. Primeiramente, é preciso gerar os mapas de direção e acúmulo de fluxo. Em seguida, existem, basicamente, dois procedimentos. Um delimita todas as bacias hidrográficas do MDE, de acordo com uma área mínima ou a partir da confluência de todos os canais de drenagem identificados no mapa de acúmulo de fluxo. O segundo procedimento consiste em identificar as bacias a partir de seções de controle definidos pelo usuário do programa de geoprocessamento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 238](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 238 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0242 — Geotecnologias: o que são ottobacias e qual sua importância na gestão de recursos hídricos?

**Variantes:** Uma pergunta: o que são ottobacias e qual sua importância na gestão de recursos hídricos (geotecnologias)? · ottobacias importância gestão recursos hídricos (geotecnologias)? · o q sao ottobacias e qual sua importancia na gestao de recuros hidricos (geotecnologias)

Ottobacias são uma forma de codificar bacias hidrográficas, proposta pelo hidrólogo Otto Pfafstatter em 1989, que utiliza um método hierárquico para identificar as regiões hidrográficas e as bacias hidrográficas no Brasil. A identificação e a delimitação das bacias hidrográficas têm importância na gestão dos recursos hídricos, pois delimita as áreas de influência de um determinado corpo d’água.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 242](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 242 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0243 — O que são isoietas e como pode-se gerá-las usando o sistema de informação geográfica (SIG)?

**Variantes:** Me explica uma coisa: o que são isoietas e como pode-se gerá-las usando o sistema de informação geográfica (SIG)? · isoietas pode-se gerá-las usando sistema informação geográfica? · o q sao isoieas e como pode-se gera-las usando o sistema de informacao geografica (sig)

São linhas que identificam locais com precipitação igual, um conceito semelhante às linhas de cota num mapa topo-gráfico. Elas podem ser geradas a partir da interpolação de dados de estações pluviométricas ou a partir de dados de precipitação obtidos por sensores remotos, como os produtos do satélite Tropical Rainfall Measuring Mission (TRMM).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 243](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 243 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0244 — Geotecnologias: quais os principais modelos de predição das perdas de solo em bacia hidrográfica?

**Variantes:** Me explica uma coisa: quais os principais modelos de predição das perdas de solo em bacia hidrográfica (geotecnologias)? · principais modelos predição perdas solo bacia hidrográfica (geotecnologias)? · quais os principais modelos de prediao das perdas de solo em bacia hidrografica (geotecnologias)

O modelo mais conhecido e largamente usado em todo o mundo, para estimativa da erosão hídrica, é a Equação Universal de Perda de Solo (Universal Soil Loss Equation - USLE). O desenvolvimento da USLE teve início a partir de 1950, nos Estados Unidos. Para atender as condições brasileiras, estimativas de parâmetros da USLE sofreram alterações, dando origem a Eups. Novas pesquisas e experiências continuaram sendo conduzidas nos Estados Unidos, com o propósito de melhorar as estimativas das perdas de solo pela utilização da USLE, originando um novo modelo de predição da erosão denominado Equação Universal de Perda de Solo Revisada (Revised Universal Soil Loss Equation – RUSLE).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 244](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 244 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0245 — Geotecnologias: como se pode mapear a perda de solo numa bacia hidrográfica, usando-se a USLE/RUSLE?

**Variantes:** Tu sabe me dizer: como se pode mapear a perda de solo numa bacia hidrográfica, usando-se a USLE/RUSLE (geotecnologias)? · mapear perda solo numa bacia hidrográfica usando-se (geotecnologias)? · como se pode mapear a perda de solo numa bacia hidrografica, usando-se a usle/rusle (geotecnologias)

Num sistema de informação geográfica (SIG) multiplicando-se os seguintes Planos de Informação (arquivos raster): • Fator erosividade da chuva (Fator R). • Fator erodibilidade do solo (Fator K). • Fator comprimento da vertente (Fator L). • Fator declividade da vertente (Fator S). • Fator uso e manejo do solo (Fator C). • Fator prática conservacionistas do solo (Fator P).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 245](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 245 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0246 — Como se pode gerar o mapa de erosividade das chuvas de uma bacia hidrográfica?

**Variantes:** Tchê, me ajuda: como se pode gerar o mapa de erosividade das chuvas de uma bacia hidrográfica? · gerar mapa erosividade chuvas bacia hidrográfica? · como se pode gerar o mapa de erosividade das chuvas de uma bacia hidrografca

Inicialmente são gerados valores de erosividade da chuva, a partir de dados de chuva de postos pluviométricos e/ou de pluviográficos georrefenciados, localizados no interior da bacia e no seu entorno. Usando-se o SIG, interpolam-se esses dados para gerar o mapa de erosividade das chuvas. A krigagem é um dos métodos de interpolação espacial mais usado, entretanto para sua aplicação deve-se proceder a alguns testes preliminares. Outro interpolador recomendado é o Inverso do Quadrado da Distância (IQD).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 246](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 246 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0250 — Geotecnologias: como se estima a produção de sedimento de uma bacia hidrográfica?

**Variantes:** Uma pergunta: como se estima a produção de sedimento de uma bacia hidrográfica (geotecnologias)? · estima produção sedimento bacia hidrográfica (geotecnologias)? · como se estima a produao de sedimento de uma bacia hidrografica (geotecnologias)

Por meio de ferramentas que unem os sistemas de informação geográfica (SIG) aos modelos hidrossedimentológicos, possibilitando a espacialização da produção de sedimento de uma bacia hidrográfica. Um exemplo é a Equação Universal de Perda de Solos Modificada (Modified Universal Soil Loss Equation – MUSLE), que integra o modelo hidrológico Soil and Water Assessment Tool (SWAT). O SWAT simula diferentes processos físicos em bacia hidrográfica agrícola (evapotranspiração, infiltração, escoamento superficial, subsuperficial e subterrâneo). Para o ambiente SIG foi desenvolvida uma ferramenta específica para o modelo SWAT, denominada de ArcSWAT.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 250](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 250 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0251 — Como se elaboram mapas de área de risco de inundação a partir de imagens de satélite?

**Variantes:** Uma pergunta: como se elaboram mapas de área de risco de inundação a partir de imagens de satélite? · elaboram mapas área risco inundação partir imagens? · como se elaboram mapas de area de risco de inundacao a partir de imagens de satelte

Na faixa do infravermelho próximo, a água e as áreas de solo úmido são representadas por tons de cinza. Normalmente, essa faixa corresponde à Banda 4 dos satélites Landsat e CBERS. Essa informação integrada com outras fontes, como por exemplo, uso da terra, relevo (MDE), dados de chuva e de vazão de cursos d’água, integradas por meio de um SIG, podem possibilitar a elaboração de um mapa de áreas de risco de inundação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 251](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 251 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0252 — Geotecnologias: o que é regionalização de vazão e qual sua importância em estudos hidrológicos?

**Variantes:** Me explica uma coisa: o que é regionalização de vazão e qual sua importância em estudos hidrológicos (geotecnologias)? · regionalização vazão importância estudos hidrológicos (geotecnologias)? · o q e regionalizaao de vazao e qual sua importancia em estudos hidrologicos (geotecnologias)

É um método estatístico da hidrologia que possibilita estimar a vazão média de longo prazo na rede de drenagem de uma bacia hidrográfica, em locais com ausência ou insuficiência de dados. Ferramentas de geoprocessamento podem auxiliar nos cálculos da regionalização e nas estimativas das vazões, facilitando a organização e análise dos dados. A regionalização tem grande importância na previsão probabilística de riscos de enchentes e na disponibilidade hídrica de longo termo, para usos como a geração hidráulica de energia ou irrigação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 252](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 252 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0264 — Geotecnologias: qual o procedimento que deve ser feito para diminuir esse tipo de ruído e/ou interferência?

**Variantes:** Queria entender: qual o procedimento que deve ser feito para diminuir esse tipo de ruído e/ou interferência (geotecnologias)? · procedimento feito diminuir tipo ruído interferência (geotecnologias)? · qual o procedimento q deve ser feito pra diminuir esse tipo de ruido e/ou interferenia (geotecnologias)

Quanto à interferência das nuvens, não existe um procedimento automático para remover nuvens de grandes regiões, a não ser que seja feito uma mistura de imagens de diferentes datas, onde as áreas com a presença de nuvens seja substituída por dados de outra imagem. Já os efeitos causados por aerossol ou névoa podem ser atenuados ou corrigidos usando-se métodos de correção atmosférica. Esses métodos podem ser mais simples, se baseados em formulações empíricas, ou mais complexos, quando baseados em modelos de transferência radioativa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 264](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 264 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0272 — Como funciona a agricultura de precisão?

**Variantes:** Queria entender: como funciona a agricultura de precisão? · agricultura precisão? · como funciona a agricultra de precisao

É um sistema de gerenciamento agrícola baseado na variação espacial de propriedades do solo e das plantas na lavoura. Utiliza o conjunto de técnicas e metodologias para otimizar o uso dos insumos agropecuários e o manejo das culturas. A adoção da agricultura de precisão permite ao produtor rural utilizar-se de manejo diferenciado no espaço e no tempo, como exemplo, o uso racional de insumos na lavoura, garantindo a otimização do lucro, sustentabilidade e proteção do ambiente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*KB Fenasoja:* EVT-006
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 272](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 272 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0273 — Quando e onde surgiu a agricultura de precisão?

**Variantes:** Queria entender: quando e onde surgiu a agricultura de precisão? · surgiu agricultura precisão? · quando e onde surgiu a agricultura de preciao

Os primeiros registros da agricultura de precisão ocorreram no início do século 20. Na prática, remonta á década de 1980, quando na Europa foi gerado o primeiro mapa de produtividade e nos Estados Unidos fez-se a primeira adubação em doses variadas. No Brasil, as primeiras atividades datam de 1995, com a importação de equipamentos, especialmente colhedoras equipadas com monitores de colheita e uso de ferramentas de sensoriamento remoto e geoprocessamento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 273](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 273 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0274 — Qual a diferença entre agricultura de precisão e agricultura convencional?

**Variantes:** Me tira uma dúvida: qual a diferença entre agricultura de precisão e agricultura convencional? · diferença agricultura precisão agricultura convencional? · qual a diferenca entre agricultura de precisao e agricultura convencioal

Essas diferenças são imperceptíveis e desprezadas: Agricultura de precisão – Tornam possíveis as observações de uma área agrícola com olhar atento às diferenças no espaço e no tempo das principais características ambientais e agronômicas com uso de geotecnologias para elaboração de mapas. Agricultura convencional – O manejo das lavouras é realizado pela média. Como exemplo, a aplicação de adubo na lavoura, baseado pela média de resultados da análise de fertilidade do solo da área plantada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 274](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 274 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0275 — Qual a relação entre a agricultura de precisão e a geoestatística?

**Variantes:** Queria entender: qual a relação entre a agricultura de precisão e a geoestatística? · relação agricultura precisão geoestatística? · qual a relacao entre a agricultura de preciao e a geoestatistica

Agricultura de precisão – Utiliza ferramentas que consideram a variação no espaço das propriedades do solo e das plantas. Geoestatística – É uma dessas ferramentas essenciais que permite uma visão espacial útil ao planejamento e ao controle das informações de produção que variam de um local para outro, com algum grau de continuidade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 275](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 275 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0276 — Qual o número ideal de pontos de amostragem para análise geoestatística?

**Variantes:** Alguém me explica: qual o número ideal de pontos de amostragem para análise geoestatística? · número ideal pontos amostragem análise geoestatística? · qual o numero ideal de pontos de amostraem pra analise geoestatistica

O número adequado de pontos de amostragem irá depender de uma série de fatores, como: • Tamanho da área. • Tipo de informação a ser amostrada. As amostras devem ser suficientemente próximas, para conseguir caracterizar as possíveis manchas de variabilidade. Entretanto, deve-se analisar e planejar o número de coletas de dados, principalmente por meio do custo-benefício, pois um grande número de pontos amostrais aumenta o custo da operação e pode inviabilizar a implantação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 276](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 276 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0277 — Como planejar a amostragem em geoestatística?

**Variantes:** Alguém me explica: como planejar a amostragem em geoestatística? · planejar amostragem geoestatística? · como planear a amostragem em geoestatistica

A melhor forma de planejar a amostragem é levar em consideração dados auxiliares, como: • Informações históricas da área. • Mapas de solos, relevo, vegetação. • Imagens de satélite ou fotografias aéreas, com as quais se possam identificar regiões com diferentes características, sendo possível direcionar as amostragens, concentrando-se nas regiões onde existir maior variação e diminuindo-se nos locais mais uniformes.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 277](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 277 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### AGTECH-GEO-0278 — Quais os métodos de amostragem de dados para análise geoestatística?

**Variantes:** Tu sabe me dizer: quais os métodos de amostragem de dados para análise geoestatística? · métodos amostragem dados análise geoestatística? · quais os metodos de amostragem de dados pra analise geoestatistca

Desde que obtidos com coordenadas geográficas, esses dados podem ser oriundos de coleta in loco no campo, via método manual ou medido por: • Sensores. • Imagens de satélite. • Fotografias aéreas. • Levantamentos topográficos e censitários.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 278](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 278 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0279 — Qual o número adequado de amostras de solo na agricultura de precisão?

**Variantes:** Me explica uma coisa: qual o número adequado de amostras de solo na agricultura de precisão? · número adequado amostras solo agricultura precisão? · qual o numero adequdo de amostras de solo na agricultura de precisao

Esse número depende do tamanho da área e do tipo de cultura: • Em áreas mais homogêneas, os produtores brasileiros coletam em torno de uma amostra de solo a cada 5 ha. • Em áreas mais heterogêneas, eles coletam uma amostra a cada 3 ha para áreas mais heterogêneas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 279](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 279 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0280 — Quais os tipos de dados amostrados em agricultura de precisão e como georreferenciar esses dados obtidos?

**Variantes:** Tchê, me ajuda: quais os tipos de dados amostrados em agricultura de precisão e como georreferenciar esses dados obtidos? · tipos dados amostrados agricultura precisão georreferenciar esses? · quais os tipos de dados amostrados em agricultra de precisao e como georreferenciar esses dados obtidos

Qualquer informação que auxilie no gerenciamento do sistema de produção e que sejam passíveis de se obter espacialmente, tais como: • Dados de solo (fertilidade, compactação, textura). • Planta (índice da área foliar, biomassa). • Água (qualidade), ar. Os dados georreferenciados são os que possuem uma referência no espaço e podem ser obtidos arbitrariamente, apenas com a medição manual da distância entre pontos, ou via sistema de posicionamento global (GPS).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 280](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 280 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0281 — O que são sensores, na agricultura de precisão?

**Variantes:** Alguém me explica: o que são sensores, na agricultura de precisão? · sensores agricultura precisão? · o q sao sensores, na agricultra de precisao

São equipamentos eletroeletrônicos capazes de transformar uma grandeza física medida em campo, em informações em tempo real (sinal elétrico entendível). Em agricultura de precisão servem, por exemplo, para automação da aplicação de insumos nas lavouras com taxas variadas, focada na dose certa de insumo proveniente da leitura do sensor.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 281](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 281 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0282 — Quais os tipos de sensores utilizados em agricultura de precisão?

**Variantes:** Uma pergunta: quais os tipos de sensores utilizados em agricultura de precisão? · tipos sensores utilizados agricultura precisão? · quais os tipos de sensores utilizados em agricultra de precisao

Os sensores podem ser remotos, orbitais e suborbitais. Novos sensores proximais estão sendo usados para gerar grande quantidade de observações em alta resolução espacial.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 282](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 282 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0283 — Como a imagem de satélite pode auxiliar na adoção da agricultura de precisão?

**Variantes:** Tu sabe me dizer: como a imagem de satélite pode auxiliar na adoção da agricultura de precisão? · imagem satélite auxiliar adoção agricultura precisão? · como a imagem de satelite pode auxilar na adocao da agricultura de precisao

Além de auxiliar no direcionamento da amostragem, a ima-gem de satélite fornece suporte no gerenciamento da produção, principalmente no monitoramento de safras, possibilitando a aquisição de dados da área das lavouras, desde a fase do plantio até a fase da colheita. Tais informações são úteis para o manejo e o monitoramento de safras, bem como na gestão e na logística da produção que acarretam: • Aumento na produtividade. • Diminuição de investimentos. • Aumento dos lucros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 283](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 283 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0285 — Geotecnologias: o que são semivariogramas e para que servem?

**Variantes:** Me explica uma coisa: o que são semivariogramas e para que servem (geotecnologias)? · semivariogramas servem (geotecnologias)? · o q sao semivariograas e pra q servem (geotecnologias)

São representações gráficas da variação de um conjunto de dados em relação à distância e indicam ou não a existência da variabilidade espacial, a partir da menor distância até certo alcance de dependência espacial entre pontos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 285](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 285 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0286 — O que é interpolação de dados e por que utilizar a geoestatística para essa interpolação?

**Variantes:** Tchê, me ajuda: o que é interpolação de dados e por que utilizar a geoestatística para essa interpolação? · interpolação dados utilizar geoestatística interpolação? · o q e interpolacao de dados e pq utiliar a geoestatistica pra essa interpolacao

É a obtenção de maior quantidade de dados nos locais não amostrados a partir dos amostrados. A geoestatística utiliza o interpolador que garante a interpolação de dados sem tendência e com a variância mínima, ou seja, garante maior precisão nos valores interpolados. O interpolador mais usado em geoestatística é a krigagem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 286](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 286 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0287 — Quais os passos para se proceder à análise geoestatística dos dados?

**Variantes:** Alguém me explica: quais os passos para se proceder à análise geoestatística dos dados? · passos proceder análise geoestatística dados? · quais os passos pra se proceer a analise geoestatistica dos dados

Para se proceder à análise geoestatística, devem-se seguir os seguintes passos: • Obter dados georreferenciados. • Proceder à análise exploratória dos dados. • Construir e ajustar o semivariograma. • Identificar a dependência espacial. • Interpolar os dados a partir dos parâmetros de ajuste do semivariograma. • Construir os mapas de variabilidade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 287](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 287 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0288 — Como são elaborados os mapas de produtividade e qual o objetivo?

**Variantes:** Uma pergunta: como são elaborados os mapas de produtividade e qual o objetivo? · elaborados mapas produtividade objetivo? · como sao elaborados os mapas de produtividade e qual o objetvo

São elaborados mediante dados de produção da cultura no campo, coletados in loco ou por sensores. Esses dados são submetidos à análise de variabilidade espacial, ou seja, a geoestatística, em que são interpolados valores nos locais não amostrados e construídos mapas de produtividade para a área amostrada em ambiente de Sistema de Informação Geográfica (SIG). Esses mapas auxiliam no gerenciamento da propriedade agrícola no que se refere ao monitoramento da safra, auxiliando na gestão e na logística da produção.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 288](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 288 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0290 — Como é feita a aplicação localizada de insumos em agricultura de precisão?

**Variantes:** Tchê, me ajuda: como é feita a aplicação localizada de insumos em agricultura de precisão? · feita aplicação localizada insumos agricultura precisão? · como e feita a aplicacao localizda de insumos em agricultura de precisao

Pode ser feita manualmente ou por equipamentos e máquinas como semeadoras, pulverizadores e adubadoras equipadas com sensores, e controladores da dosagem do insumo a ser aplicado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 290](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 290 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0293 — Como a agricultura de precisão pode aumentar a produtividade das culturas?

**Variantes:** Tu sabe me dizer: como a agricultura de precisão pode aumentar a produtividade das culturas? · agricultura precisão aumentar produtividade culturas? · como a agricultura de precisao pode aumentar a produtividade das cultuas

A agricultura de precisão permite amparar, tecnicamente, decisões estratégicas e complexas em relação à produtividade das diferentes culturas, contribuindo para o desenvolvimento de uma produção agrícola sustentável em longo prazo. Por considerar a variabilidade espacial dos fatores de produção, são identificadas as zonas de manejo onde se pode realizar manejo, intervenção e a aplicação localizada de insumos, tornando a área menos heterogênea.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 293](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 293 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0294 — Quais os benefícios que a agricultura de precisão traz para o produtor e seus custos?

**Variantes:** Uma pergunta: quais os benefícios que a agricultura de precisão traz para o produtor e seus custos? · benefícios agricultura precisão traz produtor custos? · quais os beneficios q a agricultura de preciao traz pra o produtor e seus custos

Diante de um mercado cada vez mais exigente em qualidade dos produtos agropecuários e a sustentabilidade ambiental, ao adotar a agricultura de precisão o produtor se beneficia pelo adequado gerenciamento da sua propriedade agropecuária Maior controle das informações de produção, maior eficiência na utilização de insumos, dos serviços e, principalmente, dos recursos naturais solo e a água.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*KB Fenasoja:* EVT-006
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 294](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 294 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0295 — Qual o custo para se implantar a agricultura de precisão?

**Variantes:** Me explica uma coisa: qual o custo para se implantar a agricultura de precisão? · custo implantar agricultura precisão? · qual o custo pra se implantar a agricultura de preciao

Depende, principalmente, do tipo de cultura e do tamanho da área. No geral, os custos envolvidos na adoção da agricultura de precisão são principalmente os custos operacionais, relativos à amostragem e à análise do solo, à geração de mapas, aplicação à taxa variável, bem como os custos dos insumos usados para melhoria da fertilidade da área e de máquinas e equipamentos. Esses custos devem ser considerados como investimento, uma vez que a agricultura de precisão, quando bem adotada, visa melhorar a relação custo-benefício da atividade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 295](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 295 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0297 — Quais as principais aplicações das geotecnologias na pecuária?

**Variantes:** Me explica uma coisa: quais as principais aplicações das geotecnologias na pecuária? · principais aplicações geotecnologias pecuária? · quais as principis aplicacoes das geotecnologias na pecuaria

A aplicabilidade das geotecnologias é promissora no âmbito das ações de pesquisa, desenvolvimento e transferência de tecnologia para o setor pecuário. As imagens orbitais provenientes de sensores, com diferentes resoluções espectrais, temporais e espaciais, fontes de informações com possibilidades de aplicações: • Na caracterização das áreas de sistemas integrados. • No monitoramento espaço temporal das alterações. • No uso e na cobertura das terras. • Na correlação de parâmetros biofísicos, como índices de área foliar, biomassa e carbono.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 297](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 297 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0298 — Geotecnologias: quais as vantagens dessas aplicações na pecuária e que informações são geradas?

**Variantes:** Tchê, me ajuda: quais as vantagens dessas aplicações na pecuária e que informações são geradas (geotecnologias)? · vantagens dessas aplicações pecuária informações geradas (geotecnologias)? · quais as vantagens dessas aplicaces na pecuaria e q informacoes sao geradas (geotecnologias)

Essas ferramentas destacam-se pela capacidade operacional e o baixo custo de coleta, processamento, integração e análise de dados espaciais, que possibilitam a obtenção de dados e conhecimento a cerca dos recursos naturais existentes numa área geográfica, a geração de zoneamentos específicos baseados: • Na capacidade de análise de banco de dados geoespacial. • No desenvolvimento de modelos dinâmicos de cenários futuros para apoio ao planejamento de implantação de sistemas integrados de produção com o componente da pecuária, entre outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 298](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 298 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0299 — Quais os principais desafios das geotecnologias para a pecuária?

**Variantes:** Alguém me explica: quais os principais desafios das geotecnologias para a pecuária? · principais desafios geotecnologias pecuária? · quais os principis desafios das geotecnologias pra a pecuaria

Apesar dos significativos avanços tecnológicos, como disponibilidade de sensores com altíssima resolução espacial, temporal e espectral, bem como de inúmeras ferramentas de geoprocessamento tanto gratuitas quanto comercias, ressalta-se que as geotecnologias podem contribuir para tomadas de decisões sobre a produção para aliar produção com sustentabilidade econômica e ambiental.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*KB Fenasoja:* EVT-006
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 299](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 299 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0301 — Geotecnologias: o que é assinatura espectral de uma determinada pastagem?

**Variantes:** Me tira uma dúvida: o que é assinatura espectral de uma determinada pastagem (geotecnologias)? · assinatura espectral determinada pastagem (geotecnologias)? · o q e assinatura espectral de uma determinada pastaem (geotecnologias)

É o comportamento que determinada vegetação da pastagem possui ao longo do seu ciclo vegetativo e de como essas etapas do ciclo podem ser identificadas por meio de diferentes comprimentos de onda do espectro eletromagnético. Além das faixas do visível, os sensores também podem operar em outras faixas do espectro eletromagnético e detectar informações das pastagens (nativas ou plantadas) úteis na determinação de suas características vegetacionais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 301](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 301 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0302 — Qual a vantagem de utilização de imagens de satélite no mapeamento de pastagens?

**Variantes:** Me explica uma coisa: qual a vantagem de utilização de imagens de satélite no mapeamento de pastagens? · vantagem utilização imagens satélite mapeamento pastagens? · qual a vantagem de utilizacao de imagens de satelite no mapeameto de pastagens

A utilização de diferentes imagens de satélite é uma alternativa de identificação, diagnóstico e qualificação do comportamento da vegetação e do potencial produtivo de determinada área com pastagem natural ou implantada, uma vez que as informações derivadas provem respostas rápidas e seguras, com custo baixo e em curto prazo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 302](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 302 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0309 — Geotecnologias: como é feito o mapeamento de iLPF?

**Variantes:** Me explica uma coisa: como é feito o mapeamento de iLPF (geotecnologias)? · feito mapeamento ilpf (geotecnologias)? · como e feito o mapeameto de ilpf (geotecnologias)

O mapeamento com o iLPF está em franco desenvolvimento metodológico. Nesse caso, o diferencial em relação a uma pastagem convencional é o entendimento da dinâmica espacial e temporal dessas áreas. As geotecnologias têm potencial para caracterizar diferentes componentes vegetais das culturas agrícolas, pastagens e florestas consorciadas por meio da utilização de sensores remotos com diversas resoluções espectrais, temporais e espaciais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 309](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 309 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0310 — Geotecnologias: qual é a vantagem das técnicas de avaliação hiperespectral para conhecimento dos sistemas iLPF?

**Variantes:** Queria entender: qual é a vantagem das técnicas de avaliação hiperespectral para conhecimento dos sistemas iLPF (geotecnologias)? · vantagem técnicas avaliação hiperespectral conhecimento sistemas ilpf (geotecnologias)? · qual e a vantagem das tecnicas de avaliacao hiperespectral pra conhecimento dos sisteas ilpf (geotecnologias)

É a possibilidade de se distinguir, com mais detalhamento, as culturas e os diferentes manejos da pastagem de maneira a mapear os sistemas diversificados de integração lavoura-pecuária-floresta.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 310](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 310 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0311 — Como as geotecnologias podem contribuir para a qualificação da carne bovina nos mercados internos e externos?

**Variantes:** Uma pergunta: como as geotecnologias podem contribuir para a qualificação da carne bovina nos mercados internos e externos? · geotecnologias contribuir qualificação carne bovina mercados internos? · como as geotecnologias podem contribuir pra a qualificaao da carne bovina nos mercados internos e externos

Podem contribuir no monitoramento das áreas de pastagens, bem como em análises espaçotemporais do rebanho bovino tanto na escala local quanto regional. Essas análises podem auxiliar em questões de logísticas sendo útil para o planejamento pecuário e industrial, assim como pode influenciar a formação de preços dos produtos e a criação de políticas e implantação de programas de desenvolvimento regional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 311](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 311 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0312 — Geotecnologias: qual a melhor resolução espacial, temporal e espectral para identificar e qualificar pastagens?

**Variantes:** Tchê, me ajuda: qual a melhor resolução espacial, temporal e espectral para identificar e qualificar pastagens (geotecnologias)? · melhor resolução espacial temporal espectral identificar qualificar (geotecnologias)? · qual a melhor resolucao espacial, temporal e espectral pra identifiar e qualificar pastagens (geotecnologias)

Para identificar e qualificar pastagens não há um padrão preestabelecido de qual seria a melhor definição em termos de resolução espacial, temporal e espectral. Todos esses fatores são essenciais tanto em pesquisas destinadas à identificação quanto à qualificação de pastagens. A melhor combinação desses fatores vai depender de questões como: • Dimensão da área. • Aspectos relacionados à estrutura do dossel da vegetação. • Tipo de solo. • Relevo. • Clima. • Sistema de manejo das pastagens, entre outros.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 312](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 312 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico. Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0313 — Geotecnologias: como os VANTs podem contribuir no mapeamento e na qualificação de pastagens?

**Variantes:** Uma pergunta: como os VANTs podem contribuir no mapeamento e na qualificação de pastagens (geotecnologias)? · vants contribuir mapeamento qualificação pastagens (geotecnologias)? · como os vants podem contribuir no mapeamento e na qualificaao de pastagens (geotecnologias)

Com os VANTs é possível identificar e mapear áreas específicas de pastagens com grande rapidez em relação a outras tecnologias de sensoriamento remoto orbital. A partir dessas imagens, é possível identificar as divisões internas de propriedades e apoiar o manejo dos animais e das pastagens.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 313](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 313 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0314 — Qual a definição da pecuária de precisão?

**Variantes:** Me explica uma coisa: qual a definição da pecuária de precisão? · definição pecuária precisão? · qual a definicao da pecuaria de preciao

É um sistema de gerenciamento do sistema de produção animal confinado ou a pasto, baseado no manejo preciso, proveniente do desenvolvimento de projetos e produtos eletrônicos voltados à otimização da produção animal sem desperdícios, com saúde animal e bem-estar. É feita por meio do conhecimento do comportamento animal, do monitoramento e do controle de animais e rebanhos, adequação das instalações, da quantidade e da distribuição de água e alimentação (concentrados e/ou volumosos). As pastagens são bem manejadas por meio de técnicas e metodologias da agricultura de precisão.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 314](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 314 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0315 — Como a pecuária de precisão pode beneficiar o produtor rural?

**Variantes:** Tu sabe me dizer: como a pecuária de precisão pode beneficiar o produtor rural? · pecuária precisão beneficiar produtor rural? · como a pecuaria de preciao pode beneficiar o produtor rural

A pecuária de precisão pode facilitar o negócio da produção animal e trazer soluções de problemas como obter informações por meio do uso de ferramentas adequadas para atender as demandas de produtividade e qualidade do mercado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 315](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 315 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0320 — Quais as premissas básicas para se implementar um sistema de georrastreabilidade bovina?

**Variantes:** Bah, uma dúvida: quais as premissas básicas para se implementar um sistema de georrastreabilidade bovina? · premissas básicas implementar sistema georrastreabilidade bovina? · quais as premissas basicas pra se implementar um sistema de georrastreabilidde bovina

Para implementar um sistema de georrastreabilidade bovina, são necessárias as seguintes premissas: • Identificação animal. • Processamento, gerenciamento e armazenamento de dados. • Auditoria dos dados a campo. • Esse processo é estabelecido por meio do Regulamento Técnico sobre as Condições Higiênico-sanitárias e de Boas Práticas de Elaboração para Estabelecimentos Elaboradores/ Industrializadores de Alimentos, aprovado pela Portaria 368 de 1997, do Ministério da Agricultura, Pecuária e Abastecimento (Mapa).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 320](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 320 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0321 — Geotecnologias: o que é Sistema de Identificação e Certificação de Bovinos e Bubalinos (SISBOV)?

**Variantes:** Bah, uma dúvida: o que é Sistema de Identificação e Certificação de Bovinos e Bubalinos (SISBOV) (geotecnologias)? · sistema identificação certificação bovinos bubalinos sisbov (geotecnologias)? · o q e sistema de identificacao e certificacao de bovinos e bubalios (sisbov) (geotecnologias)

É um sistema de rastreabilidade implantado no País, em 2002. esse sistema é regulamentado pelas novas normas e procedimentos operacionais de rastreabilidade e identificação animal. As alterações foram determinadas pela Instrução Normativa SDA n. 21, de 02 de abril de 2004, para: • Padronizar o selo de identificação. • Auxiliar no combate e na eliminação de doenças. • Aumentar a participação dos estados. • Acompanhar a movimentação dos animais dos 40 dias de idade em diante. O texto definitivo da Instrução Normativa nº 17, publicada em 14 de julho de 2006, estabeleceu nova estrutura. Esse sistema foi implementado visando atender às exigências fitossanitárias da União Europeia.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 321](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 321 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0323 — Geotecnologias: quais as funções das agências certificadoras?

**Variantes:** Queria entender: quais as funções das agências certificadoras (geotecnologias)? · funções agências certificadoras (geotecnologias)? · quais as funcoes das agencias certificadoas (geotecnologias)

As funções das agências certificadoras são: • Controle e registro da circulação e manejo de questões relacionadas à reprodução, à nutrição e à sanidade (vacinas, exames e tratamentos) dos animais de criação. • Registro do fluxo de entrada e saída e do uso de insumos nos estabelecimentos. • Identificação do animal pelo documento de identificação animal (DIA). É obrigatório que todos os bovinos e bubalinos nascidos em rebanhos identificados sejam incluídos no programa. Caso a iden-tificação seja perdida, a entidade certificadora pode dar andamento à solicitação de reidentificação, registrando a sequência de eventos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 323](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 323 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0325 — Qual a importância da identificação animal no processo de georrastreabilidade bovina?

**Variantes:** Me tira uma dúvida: qual a importância da identificação animal no processo de georrastreabilidade bovina? · importância identificação animal processo georrastreabilidade bovina? · qual a importancia da identificacao animal no processo de georrastreabilidde bovina

A identificação segura dos animais é a base para a maior parte das funções do sistema de manejo que resultam em progressos zootécnicos, controle e economia da produção. Qualquer método de identificação deve atender a um conjunto mínimo de requisito: • Ser única, ou seja, o número deve ser encontrado apenas uma vez no rebanho • Permanente, sem correr riscos de perda. • Insubstituível, do nascimento ou aquisição do animal ao abate. • Positiva, sem gerar dúvidas. • Nesse aspecto, a identificação eletrônica dos animais se torna uma poderosa ferramenta ao interligar os elos da cadeia produtiva: • Produção. • Industrialização. • Comercialização da carne.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 325](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 325 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0326 — Geotecnologias: quais as técnicas de identificação mais usadas na bovinocultura?

**Variantes:** Uma pergunta: quais as técnicas de identificação mais usadas na bovinocultura (geotecnologias)? · técnicas identificação usadas bovinocultura (geotecnologias)? · quais as tecnicas de identificaao mais usadas na bovinocultura (geotecnologias)

Na bovinocultura, as técnicas de identificação mais usadas são: • Brincos plásticos. • Marcação a ferro quente no couro, entre outras. • Etiquetas com código de barras. • Colar. Entretanto, esses sistemas apresentam falhas na visualização à longa distância e erro de leitura. Uma alternativa seria a aplicação de brincos eletrônicos, que podem ser incorporados a um transponder, com leitura feita por meio de um display, ou de um código de barras. O código de barras permite identificar o animal a partir de leitura a laser. A identificação também pode ser feita por: • Microchip eletrônico. • Fotografia digital da retina. • Bolus ruminal. • Análise do DNA.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 326](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 326 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0333 — Quais produtos oriundos da pecuária podem ser georrastreados, os grãos e outros produtos vegetais também podem ser georrastreados?

**Variantes:** Tchê, me ajuda: quais produtos oriundos da pecuária podem ser georrastreados, os grãos e outros produtos vegetais também podem ser georrastreados? · produtos oriundos pecuária georrastreados grãos outros produtos? · quais produtos oriundos da pecuaria podem ser georrastreados, os graos e outros produtos vegetais tb podem ser georrastreaos

Podem ser georrastreados: • Bovinos. • Bubalinos. • Suínos. • Ovinos. • Caprinos. • Aves • Pescados. • Também podem ser rastreados produtos vegetais como: • Soja. • Milho. • Trigo. • Arroz, além de outros grãos, visando assegurar a origem, a qualidade e a segurança dos produtos obtidos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 333](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 333 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0334 — Geotecnologias: como a segurança alimentar é vista pela União Europeia?

**Variantes:** Queria entender: como a segurança alimentar é vista pela União Europeia (geotecnologias)? · segurança alimentar vista união europeia (geotecnologias)? · como a seguranca alimentar e vista pela uniao europia (geotecnologias)

A Comissão Europeia identificou a segurança alimentar como uma de suas principais prioridades. Assim, foram impostas regras A rastreabilidade desses e de outros produtos agropecuários faz uso de aplicativos apropriados e específicos. de regulamentação de mercado, fixando claramente as medidas e os métodos que definem as novas diretrizes a serem adotadas e são evidentes as referências que concernem à abertura dos mercados globais à carne bovina brasileira.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 334](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 334 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0335 — Geotecnologias: quais os objetivos da Legislação Alimentar da União Europeia?

**Variantes:** Me tira uma dúvida: quais os objetivos da Legislação Alimentar da União Europeia (geotecnologias)? · objetivos legislação alimentar união europeia (geotecnologias)? · quais os objetivos da legislacao alimentar da uniao europia (geotecnologias)

Tem o objetivo de harmonizar as exigências nacionais existentes para garantir a livre circulação de alimentos e alimentação na União Europeia (UE). A legislação alimentar reconhece o compromisso da UE com suas obrigações internacionais e será desenvolvida e adaptada levando em consideração padrões internacionais, exceto em situações nas quais esses padrões possam prejudicar o elevado nível de proteção ao consumidor almejado por essa organização.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 335](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 335 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0340 — Como a georrastreabilidade contribui para a segurança dos alimentos?

**Variantes:** Bah, uma dúvida: como a georrastreabilidade contribui para a segurança dos alimentos? · georrastreabilidade contribui segurança alimentos? · como a georrastreabilidade contribui pra a seguraca dos alimentos

A georrastreabilidade vem agregar valor e segurança aos alimentos a partir do conhecimento da procedência, do histórico (base de dados com informações da cadeia produtiva desde a propriedade ao mercado) e da localização precisa obtida via apresentação das coordenadas geográficas e certificação de origem. A rastreabilidade faz parte de um sistema de gestão completo e eficiente, mas não necessariamente impede que ocorra algum incidente ligado à segurança dos alimentos, como uma contaminação química na armazenagem, por exemplo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 340](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 340 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0341 — Geotecnologias: o que são sistemas de RFID (Radio Frequency Identification?

**Variantes:** Tu sabe me dizer: o que são sistemas de RFID (Radio Frequency Identification (geotecnologias)? · sistemas rfid radio frequency identification (geotecnologias)? · o q sao sisteas de rfid (radio frequency identification (geotecnologias)

São sistemas que utilizam a rádiofrequência e não o código de barras para identificar animais, e que permitem: • A captura de informação por meio de leitores eletrônicos. • A transmissão de arquivos de dados pela internet. Esses sistemas funcionam a partir de uma antena que transmite a informação para um transceptor (dispositivo leitor do sinal e conversor de ondas de RFID para informações digitais) e uma etiqueta de rádiofrequência presa ao animal ou chips de inserção subcutânea nos animais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 341](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 341 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0342 — Geotecnologias: quais as vantagens e desvantagens do RFID?

**Variantes:** Tu sabe me dizer: quais as vantagens e desvantagens do RFID (geotecnologias)? · vantagens desvantagens rfid (geotecnologias)? · quais as vantagens e desvantagns do rfid (geotecnologias)

Vantagens: a capacidade de armazenamento, leitura e envio dos dados para as etiquetas ativas, sendo possível a detecção sem a necessidade de visada direta, assim como durabilidade com possível reutilização. Desvantagem: o custo elevado da tecnologia em relação aos sistemas de código de barras. Além disso, existe a restrição de uso em materiais metálicos e condutivos em relação ao alcance de transmissão das antenas. Como a operação é baseada em campos magnéticos, o metal pode interferir, negativamente, no desempenho.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 342](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 342 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0343 — Como funciona o brinco de georrastreamento bovino?

**Variantes:** Uma pergunta: como funciona o brinco de georrastreamento bovino? · brinco georrastreamento bovino? · como funcina o brinco de georrastreamento bovino

O brinco é composto de um chip eletrônico, aproximadamente do tamanho de uma cabeça de alfinete e é ligado a uma antena de captação de ondas eletromagnéticas com um fio de cobre. O número do chip é captado por uma antena, que pode ser instalada nos locais onde o boi transita. Esses dados são enviados a um software, realizando o gerenciamento do rebanho. Os dados podem ser obtidos via leitora manual, como scanners de código de barras, possibilitando coletar informações e descarregá-las na sede da fazenda.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 343](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 343 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0349 — Quais os principais equívocos na identificação e na classificação de florestas plantadas com o uso de imagens?

**Variantes:** Me tira uma dúvida: quais os principais equívocos na identificação e na classificação de florestas plantadas com o uso de imagens? · principais equívocos identificação classificação florestas plantadas uso? · quais os principais equivocos na identificacao e na classificacao de florestas plantaas com o uso de imagens

Por se tratar de culturas temporárias, a cada ciclo há colheita e plantio ou rebrota de novos indivíduos. Portanto, principalmente na durante a primeira fase de crescimento destes reflorestamentos, ou seja, na fase jovem, elas podem ser confundidas com estádios iniciais e intermediários de sucessão florestal nativa ou com culturas agrícolas anuais, como milho e cana-de-açúcar.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 349](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 349 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0353 — O que é silvicultura de precisão?

**Variantes:** Tu sabe me dizer: o que é silvicultura de precisão? · silvicultura precisão? · o q e silvicultura de preciao

É a adoção de técnicas florestais baseada nas peculiaridades de cada local de plantio, a partir da espacialização georreferenciada e da temporalidade dos sistemas florestais. Em especial, a qualidade do solo é avaliada por meio da geoestatística.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 353](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 353 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0360 — Geotecnologias: como protocolos de MDL podem contribuir para a silvicultura?

**Variantes:** Queria entender: como protocolos de MDL podem contribuir para a silvicultura (geotecnologias)? · protocolos mdl contribuir silvicultura (geotecnologias)? · como protocolos de mdl podem contribuir pra a silvicultra (geotecnologias)

A fixação de carbono nas árvores pode ser calculada em termos econômicos e ser uma forma de mecanismo de compensação desse elemento, com comercialização na forma de créditos no mercado internacional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 360](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 360 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0374 — Geotecnologias: quais as vantagens de se usar sensor multiespectral?

**Variantes:** Queria entender: quais as vantagens de se usar sensor multiespectral (geotecnologias)? · vantagens usar sensor multiespectral (geotecnologias)? · quais as vantagens de se usar sensor multiespectal (geotecnologias)

O sensoriamento remoto multiespectral vem assumindo uma série de funções anteriormente atendidas pela aerofotogrametria com as seguintes vantagens associadas: • Ao baixo custo por área específica. • Aos aspectos diacrônicos (alta frequência de repetitividade da tomada de imagens) e sincrônicos da captação das imagens. • Ao aspecto multiespectral das imagens. • Ao caráter digital dos dados adquiridos. • À facilidade de integração com bases de dados geocodificados, cartográficos ou numéricos, através de sistemas de informações geográficas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 374](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 374 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0380 — Quais os satélites/sensores usados para mapear desmatamento?

**Variantes:** Me explica uma coisa: quais os satélites/sensores usados para mapear desmatamento? · satélites sensores usados mapear desmatamento? · quais os satelites/sensores usados pra mapear desmatameto

Vários satélites são usados com essa finalidade. No Brasil, desde 1988, o projeto Monitoramento da Floresta Amazônica Brasileira por Satélite (PRODES), coordenado pelo Instituto Nacional de Pesquisas Espaciais (Inpe), gera informações anuais sobre as taxas de desmatamento na Amazônia Legal, com base em imagens dos satélites LANDSAT e CBERS. O Sistema de Detecção de Desmatamento em Tempo Real (DETER), desenvolvido pelo Inpe, também usa dados do sensor MODIS.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 380](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 380 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0383 — Geotecnologias: qual é a técnica mais simples para se fazer um inventário florestal?

**Variantes:** Queria entender: qual é a técnica mais simples para se fazer um inventário florestal (geotecnologias)? · técnica simples fazer inventário florestal (geotecnologias)? · qual e a tecnica mais simples pra se fazer um inventario floresal (geotecnologias)

É a técnica da estratificação, baseada em segmentar e classificar uma imagem por meio da interpretação visual. Essa técnica pode: • Agilizar o inventário, ao diminuir o número de parcelas a serem conferidas em campo. • Minimizar erros de localização ou de classificação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 383](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 383 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0385 — Geotecnologias: quais as potencialidades de utilização de LiDAR na silvicultura?

**Variantes:** Alguém me explica: quais as potencialidades de utilização de LiDAR na silvicultura (geotecnologias)? · potencialidades utilização lidar silvicultura (geotecnologias)? · quais as potencialidaes de utilizacao de lidar na silvicultura (geotecnologias)

No caso do LiDAR aerotransportado, um sistema é instalado em uma plataforma móvel (normalmente avião), que sobrevoa superfície do terreno com a cultura de interesse (silvicultura, por exemplo), e assim gera imagens tridimensionais da superfície por meio de pulsos de laser disparados em direção aos alvos de interesse. Os dados gerados permitem, por exemplo, observar falhas de plantio e estimar biomassa/produção a partir de validações de campo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 385](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 385 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0387 — Como as geotecnologias poderão auxiliar as áreas de silvicultura a se adequarem às exigências ambientais?

**Variantes:** Tu sabe me dizer: como as geotecnologias poderão auxiliar as áreas de silvicultura a se adequarem às exigências ambientais? · geotecnologias poderão auxiliar áreas silvicultura adequarem exigências? · como as geotecnologias poderao auxilar as areas de silvicultura a se adequarem as exigencias ambientais

Entre as várias possibilidades, destaca-se o uso das geotecnologias para cumprir exigências do novo Código Florestal Brasileiro, como: • Georreferenciamento do imóvel rural. • Mapeamento, quantificação e qualificação de Áreas de Preservação Permanente e Reserva Legal. • Cadastro Ambiental Rural. • Programa de Regularização Ambiental.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 387](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 387 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0389 — Qual a diferença de se utilizar as geotecnologias na silvicultura urbana na silvicultura rural?

**Variantes:** Me explica uma coisa: qual a diferença de se utilizar as geotecnologias na silvicultura urbana na silvicultura rural? · diferença utilizar geotecnologias silvicultura urbana silvicultura rural? · qual a diferenca de se utilizar as geotecnologias na silvicultura urbana na silvicultra rural

A diferença básica é que no meio urbano existem outros fatores que são considerados além da questão espacial e das características da vegetação. Nas áreas urbanas o elemento arquitetônico e a morfologia urbana são acrescentados às interpretações dos dados levantados pelas geotecnologias.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 389](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 389 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0390 — Como a silvicultura urbana e rural podem se integrar utilizando-se de técnicas de geoprocessamento?

**Variantes:** Tu sabe me dizer: como a silvicultura urbana e rural podem se integrar utilizando-se de técnicas de geoprocessamento? · silvicultura urbana rural integrar utilizando-se técnicas geoprocessamento? · como a silvicultura urbana e rural podem se integar utilizando-se de tecnicas de geoprocessamento

A integração pode ser realizada por meio dos corredores ecológicos traçados pelas análises espaciais. O desenho ambiental a ser realizado unirá as cidades e o meio rural de uma maneira gradual. Há a possibilidade de harmonia entre o serviço ambiental fornecidos pelo meio rural e a utilização desses pelas cidades de maneira a minimizar os impactos da antropização.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 390](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 390 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0393 — Geotecnologias: o que é a adequação agrícola de uma propriedade rural?

**Variantes:** Me explica uma coisa: o que é a adequação agrícola de uma propriedade rural (geotecnologias)? · adequação agrícola propriedade rural (geotecnologias)? · o q e a adequacao agricla de uma propriedade rural (geotecnologias)

É a implementação do uso das terras em relação à sua aptidão, avaliada com o uso de geotecnologias. Assim, a avaliação da aptidão agrícola das terras deve orientar o planejamento agrícola para uma diversidade de usos com diferentes manejos, considerando as condições edáficas e agrícolas dos solos (atributos físicos e químicos), fatores geomorfológicos, ecológicos e socioeconômicos da propriedade rural.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 393](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 393 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0395 — Geotecnologias: por que promover a adequação ambiental de propriedades rurais?

**Variantes:** Tu sabe me dizer: por que promover a adequação ambiental de propriedades rurais (geotecnologias)? · promover adequação ambiental propriedades rurais (geotecnologias)? · pq promover a adequaao ambiental de propriedades rurais (geotecnologias)

A adequação ambiental ou regularização ambiental rural é lei, desde o Código Florestal de 1965, e foi mantida com a revisão do novo Código Florestal Brasileiro (BRASIL, 2012b) de 2012, apesar de ter sofrido alterações significativas. Ações direcionadas à preservação, à conservação e ao uso sustentável dos recursos naturais, como os solos, os recursos hídricos (rios, córregos e nascentes), o ar, a flora nativa e a fauna silvestre: • Evitam a degradação ambiental. • Melhoram a qualidade de vida das pessoas. • São importantes para o sistema produtivo agrícola como um todo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 395](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 395 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0396 — Geotecnologias: o que é Cadastro Ambiental Rural (CAR)?

**Variantes:** Uma pergunta: o que é Cadastro Ambiental Rural (CAR) (geotecnologias)? · cadastro ambiental rural car (geotecnologias)? · o q e cadasro ambiental rural (car) (geotecnologias)

É o cadastramento da propriedade rural via internet, na página do Ministério do Meio Ambiente, sendo um dos desdobramentos do novo Código Florestal Brasileiro e promove a regularização ambiental de imóveis rurais. Foi institucionalizado em âmbito nacional, determinando sua obrigatoriedade conforme dispõe a Lei nº 12.651, de 25 de maio de 2012 (BRASIL, 2012b), artigo 29, e regulamentado pelo Decreto nº 7.830, de 17 de outubro de 2012 (BRASIL, 2012a). O governo federal repassou para os estados e municípios a responsabilidade de executar o Cadastro dos Imóveis Rurais, todos georreferenciados. Algumas Unidades da Federação já possuíam sistemas próprios de cadastros de imóveis rurais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 396](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 396 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0397 — Geotecnologias: o que é Sistema de Cadastro Ambiental Rural (SiCAR)?

**Variantes:** Alguém me explica: o que é Sistema de Cadastro Ambiental Rural (SiCAR) (geotecnologias)? · sistema cadastro ambiental rural sicar (geotecnologias)? · o q e sistema de cadasro ambiental rural (sicar) (geotecnologias)

É o sistema informatizado ou ferramenta eletrônica que recebe, gerencia e integra os dados do CAR de todas as Unidades da Federação, desenvolvido pelo Ministério do Meio Ambiente (MMA) e criado pelo Decreto nº 7.830, de 17 de outubro de 2012 (BRASIL, 2012a), para armazenar as informações georreferenciadas e características das propriedades rurais (localização, perímetro, áreas de vegetação nativa, áreas de preservação permanente (APP), área de reserva legal (RL) e de uso restrito inscritas ou cadastradas no CAR.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 397](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 397 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0400 — Geotecnologias: quais os benefícios obtidos pelos produtores rurais com o CAR?

**Variantes:** Me tira uma dúvida: quais os benefícios obtidos pelos produtores rurais com o CAR (geotecnologias)? · benefícios obtidos produtores rurais car (geotecnologias)? · quais os beneficios obtidos pelos produtoes rurais com o car (geotecnologias)

Em conformidade com o Ministério do Meio Ambiente (MMA), os benefícios são: • A comprovação da regularidade ambiental. • A segurança jurídica para produtores rurais. • O acesso a linhas oficiais de crédito. • Acesso aos programas de regularização ambiental. • Instrumento ou ferramenta para planejamento ambiental do imóvel rural.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 400](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 400 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0425 — O que é e o que representa o Sistema de Gestão Fundiária (SIGEF)?

**Variantes:** Tchê, me ajuda: o que é e o que representa o Sistema de Gestão Fundiária (SIGEF)? · representa sistema gestão fundiária sigef? · o q e e o q representa o sistema de gestao fundiaia (sigef)

O SIGEF é um sistema desenvolvido pelo Incra e pelo Ministério de Desenvolvimento Agrário (MDA) para a gestão de informações fundiárias do meio rural brasileiro, no qual serão efetuadas a recepção, a regularização e a disponibilização das informações georreferenciadas de limites dos imóveis rurais, públicos e privados, para certificação de dados e consequente subsídio à governança fundiária do território nacional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 425](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 425 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0428 — Como as geotecnologias auxiliam a fauna silvestre?

**Variantes:** Tu sabe me dizer: como as geotecnologias auxiliam a fauna silvestre? · geotecnologias auxiliam fauna silvestre? · como as geotecnologias auxiliam a fauna silvesre

As geotecnologias auxiliam não apenas a fauna silvestre, mas também a flora, de forma direta e indireta, por meio dos Sistemas de Informação Geográfica (SIGs), que facilitam o monitoramento animal que ajuda a identificar os principais habitats de cada espécie e analisar quais recursos mais utilizam na paisagem: De forma direta – Normalmente, esse monitoramento é feito por sensores que emitem sinais numa frequência específica que permite acompanhar seu deslocamento na paisagem. De forma indireta – Apoiando a implantação de corredores ecológicos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 428](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 428 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

### AGTECH-GEO-0452 — Geotecnologias: o que é zoneamento agrícola de risco climático (ZARC)?

**Variantes:** Bah, uma dúvida: o que é zoneamento agrícola de risco climático (ZARC) (geotecnologias)? · zoneamento agrícola risco climático zarc (geotecnologias)? · o q e zoneameto agricola de risco climatico (zarc) (geotecnologias)

É um instrumento técnico-científico de política agrícola e de gestão de riscos na agricultura, publicado na forma de portarias no Diário Oficial da União e no site do Ministério da Agricultura, Pecuária e Abastecimento. Para as principais culturas agrícolas do país, essas portarias relacionam: • As cultivares indicadas para plantio em cada município abrangido pelo zoneamento (BRASIL, 2013). • A melhor época de plantio de cada cultivar em diferentes tipos de solo, também em cada munícipio abrangido pelo zoneamento (BRASIL, 2013).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 452](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 452 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014). Pergunta original do livro sem menção explícita ao tema; prefixo "Geotecnologias" adicionado para dar contexto.

### AGTECH-GEO-0476 — Como as geotecnologias podem auxiliar na agricultura de precisão?

**Variantes:** Alguém me explica: como as geotecnologias podem auxiliar na agricultura de precisão? · geotecnologias auxiliar agricultura precisão? · como as geotecnologas podem auxiliar na agricultura de precisao

Para a agricultura de precisão, a geotecnologia e a geoinformação auxilia na identificação exata de locais de interesse na plantação, onde poderá haver ou não uma intervenção direta do agricultor. Nesses locais pode ser monitorado um determinado fenômeno ou característica da plantação, também podem ser determinados locais para aplicação de técnicas diferenciadas de manejo, a fim de se obter melhores resultados e maior produtividade. Também é possível conectar dispositivos móveis, operados a distância ou não em implementos agrícolas, da mesma forma programá-los para executar atividades diferenciadas ao longo da plantação, de acordo com as necessidades específicas de cada área cultivada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 476](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 476 do livro da Embrapa "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde" (2014).

## Recursos genéticos e biotecnologia

### AGTECH-RGEN-0004 — O que é agrobiodiversidade?

**Variantes:** Tchê, me ajuda: o que é agrobiodiversidade? · agrobiodiversidade? · o q e agrobiodiversidde

A agrobiodiversidade ou biodiversidade agrícola é a diversidade de animais, plantas e microrganismos e a variabilidade intraespecífica necessárias à sustentação das principais funções do agroecossistema e que são utilizadas, direta ou indiretamente, para alimentação, agricultura, pecuária, silvicultura e pesca. Compreendem, ainda, espécies que fornecem matéria-prima e serviços, como forragem, fibra, combustível e produtos farmacêuticos, e espécies que dão suporte à produção, como organismos biocontroladores, microrganismos do solo, predadores, polinizadores.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 4](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 4 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0009 — O que é germoplasma?

**Variantes:** Tchê, me ajuda: o que é germoplasma? · germoplasma? · o q e germoplama

Tradicionalmente, designa qualquer forma, porção, parte ou estrutura de origem animal, vegetal ou microbiana que contenha a informação genética que será herdada. É o material genético que constitui a base física da hereditariedade, o genótipo, e que é transmitida de uma geração a outra por meio de células germinais. Germoplasma também pode ser definido como o material genético de um organismo (cromossomas e genes) contido em semente, estaca, bulbo, pólen, embrião, tecidos, células, esperma, óvulo, esporos ou cepa e que pode ser herdado por seus descendentes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 9](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 9 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0017 — Recursos genéticos: o que é espécie naturalizada?

**Variantes:** Uma pergunta: o que é espécie naturalizada (recursos genéticos)? · espécie naturalizada (recursos genéticos)? · o q e especie naturalizda (recursos genéticos)

A espécie naturalizada é aquela que foi introduzida intencionalmente ou não em um novo ambiente e que se adaptou e reproduziu com sucesso nesse local. Ao longo do tempo, a espécie estabeleceu-se e aclimatou-se às novas condições ambientais, passando a fazer parte integrante da flora ou fauna de uma região.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 17](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 17 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0025 — O que é erosão genética?

**Variantes:** Bah, uma dúvida: o que é erosão genética? · erosão genética? · o q e erosao genetca

Erosão genética é a perda de um gene ou de um grupo de genes de uma espécie ou população, no transcorrer do tempo, em decorrência de processos naturais, da ação antrópica (degradação do meio ambiente, urbanização e desmatamento) ou pela substituição das variedades tradicionais por cultivares geneticamente uniformes. Como resultado dessa perda de variabilidade genética, tem-se a redução do potencial de adaptação das culturas às mudanças no ambiente e, consequentemente, a ameaça à segurança alimentar da população mundial e a extinção das espécies.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 25](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 25 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0031 — O que é uma cultivar?

**Variantes:** Tu sabe me dizer: o que é uma cultivar? · cultivar? · o q e uma cultiar

Planta que se distingue das demais por meio de caracteres agronômicos. Planta cultivada ou melhorada pelo ser humano por apresentar alguma característica que é atrativa do ponto de vista da produção agrícola, como a resistência às baixas temperaturas. Geralmente, enquanto está em uso, a cultivar é denominada cultivar elite ou moderna. Quando já não atende mais aos quesitos de produção para os quais foi desenvolvida, a cultivar passa a denominar-se cultivar obsoleta ou em desuso.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 31](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 31 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0036 — Recursos genéticos: o que é coleção biológica?

**Variantes:** Uma pergunta: o que é coleção biológica (recursos genéticos)? · coleção biológica (recursos genéticos)? · o q e colecao biologca (recursos genéticos)

É o conjunto de animais, plantas ou microrganismos associado a dados biológicos e geográficos em estudos taxonômicos, morfológicos, evolutivos, desenvolvimento científico e inovação tecnológica.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 36](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 36 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0041 — Recursos genéticos: o que é coleção elite ou coleção do melhorista?

**Variantes:** Bah, uma dúvida: o que é coleção elite ou coleção do melhorista (recursos genéticos)? · coleção elite coleção melhorista (recursos genéticos)? · o q e colecao elite ou colecao do melhorita (recursos genéticos)

É o conjunto de genótipos mais próximos ao padrão comercial que são obtidos por meio de cruzamentos e seleções no âmbito das atividades de melhoramento. Muitas vezes esses genótipos são muito próximos geneticamente entre si, pois geralmente têm genitores em comum. De maneira geral, os genótipos da coleção elite têm alta produtividade, características desejáveis para cultivares comerciais que foram obtidas por meio de ações de melhoramento. Entretanto, essas coleções têm, em geral, menor diversidade genética quando comparadas ao banco de germoplasma.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 41](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 41 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0046 — Recursos genéticos: o que é bioprospecção?

**Variantes:** Uma pergunta: o que é bioprospecção (recursos genéticos)? · bioprospecção (recursos genéticos)? · o q e bioprospecao (recursos genéticos)

É uma atividade exploratória que visa identificar componentes do patrimônio genético e informação sobre conhecimento tradicional associado, com potencial de uso científico e comercial.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 46](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 46 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0052 — Recursos genéticos: qual é a diferença entre estresse biótico e estresse abiótico?

**Variantes:** Tchê, me ajuda: qual é a diferença entre estresse biótico e estresse abiótico (recursos genéticos)? · diferença estresse biótico estresse abiótico (recursos genéticos)? · qual e a diferenca entre estrese biotico e estresse abiotico (recursos genéticos)

Estresse biótico é aquele provocado por pragas e patógenos que resultam em condições adversas ao crescimento dos indivíduos. Estresse abiótico, por outro lado, é aquele provocado por fatores ambientais como flutuações extremas de temperatura, ausência ou excesso de água, salinidade do solo, presença de metais pesados no solo e outras alterações ambientais que comprometem o desenvolvimento dos indivíduos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 52](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 52 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0057 — Quais são as razões para se coletar germoplasma? Por que é importante coletar?

**Variantes:** Bah, uma dúvida: quais são as razões para se coletar germoplasma? Por que é importante coletar? · razões coletar germoplasma importante coletar? · quais sao as razoes pra se coletar germoplama pq e importante coletar

A coleta de germoplasma pode objetivar o uso imediato do germoplasma, ou visa garantir material genético para uso futuro (Lleras, 1988; Walter et al., 2005). Para plantas, o uso imediato do germoplasma é a razão mais tradicional para se coletar. A coleta pode ser realizada por agricultores visando à troca de materiais (por exemplo: diferentes variedades de milho, arroz, algodão ou plantas ornamentais), por pessoas que colhem sementes de árvores para plantios em arborização ou jardinagem, ou ainda por fazendeiros que buscam sementes para abastecer projetos agrícolas ou silviculturais de maior vulto.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 57](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 57 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0064 — Como identificar o material coletado de espécies animais até o envio ao banco genético?

**Variantes:** Me tira uma dúvida: como identificar o material coletado de espécies animais até o envio ao banco genético? · identificar material coletado espécies animais até envio? · como identificar o materal coletado de especies animais ate o envio ao banco genetico

No caso do germoplasma animal, a identificação deverá ser feita diretamente na palheta em que o sêmen ou o embrião será criopreservado, ou seja, as palhetas devem ser identificadas previamente ao envase com o nome ou número do animal, data e local da coleta, espécie e/ou raça. No caso de tecidos, a identificação também deverá ser realizada diretamente nos tubos/envelopes, dependendo do material a ser acondicionado. Deve conter as mesmas informações descritas para o germoplasma, acrescidas da informação do sexo do animal.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 64](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 64 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### AGTECH-RGEN-0068 — Recursos genéticos: como identificar centros de origem ou centros de diversidade das espécies-alvo para coleta?

**Variantes:** Tchê, me ajuda: como identificar centros de origem ou centros de diversidade das espécies-alvo para coleta (recursos genéticos)? · identificar centros origem centros diversidade espécies-alvo coleta (recursos genéticos)? · como identificar centros de origem ou centros de diversidde das especies-alvo pra coleta (recursos genéticos)

A identificação tradicional de centros de origem e, principalmente, dos centros de diversidade é feita com base na detecção de regiões em que se verifique uma concentração significativa de espécies do gênero. Portanto, na prática, o que se faz é localizar áreas onde se encontra maior número de espécies no gênero.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 68](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 68 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico. Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0082 — Qual é o melhor transporte para realizar coletas de germoplasma?

**Variantes:** Bah, uma dúvida: qual é o melhor transporte para realizar coletas de germoplasma? · melhor transporte realizar coletas germoplasma? · qual e o melhor transporte pra realizar coletas de germoplama

O meio de transporte padrão em missões de coleta são caminhonetes “fora de estrada” (off-road) de cabine dupla, que transportem até seis passageiros, e que possuam carroceria ampla, de preferência fechada. Preferencialmente, devem ter tração nas quatro rodas, guincho, um bagageiro suplementar ou reboque. Sempre se deve considerar levar caixas de ferramentas para eventuais reparos no veículo, assim como a inclusão de galão de combustível extra, dependendo da região. No Norte do Brasil, é mais comum a utilização de barcos nas atividades de coleta, que percorrem os trechos dos rios onde não há acesso por terra.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 82](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 82 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0092 — Qual a importância que a Embrapa tem dado à conservação ex situ de recursos genéticos?

**Variantes:** Me explica uma coisa: qual a importância que a Embrapa tem dado à conservação ex situ de recursos genéticos? · importância embrapa dado conservação ex situ recursos? · qual a importania q a embrapa tem dado a conservacao ex situ de recursos geneticos

A Embrapa tem dado grande importância à conservação dos recursos genéticos, o que pode ser visto pela sucessão de programas de pesquisa já criados, bem como pela grande quantidade de bancos de germoplasma estabelecidos. Atualmente, a Embrapa conta com 148 bancos de germoplasma vegetal em 28 Unidades Descentralizadas, 1 banco de germoplasma animal e 25 coleções de microrganismos distribuídos em 17 Unidades Descentralizadas. Outra iniciativa importante da Embrapa na conservação ex situ foi a criação do banco genético (BGen), que reúne, em uma única estrutura, coleções de base de germoplasma animal e vegetal ou coleções back-up de microrganismos da Embrapa e de instituições parceiras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 92](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 92 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0099 — O que é necessário para depositar acessos em uma coleção de germoplasma vegetal?

**Variantes:** Tu sabe me dizer: o que é necessário para depositar acessos em uma coleção de germoplasma vegetal? · necessário depositar acessos coleção germoplasma vegetal? · o q e necessario pra depositar acessos em uma colecao de germoplama vegetal

Em primeiro lugar, é necessário verificar a adequação desse material biológico ao escopo do acervo e sua capacidade operacional. Dependendo do germoplasma, as amostras devem ser homogêneas, aparentemente sadias e representativas da diversidade da espécie, estirpe ou linhagem a ser depositada, e estar bem documentada para ingressar no sistema de conservação. Essa qualidade e pureza são verificadas em uma análise prévia, que vai confirmar ou não a solicitação de depósito podendo, em certos casos, ser rejeitada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 99](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 99 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0101 — Quais embalagens são utilizadas para acondicionar o germoplasma?

**Variantes:** Queria entender: quais embalagens são utilizadas para acondicionar o germoplasma? · embalagens utilizadas acondicionar germoplasma? · quais embalagens sao utilizadas pra acondicionar o germoplama

Diferentes tipos de embalagens são utilizados para acondicionar o germoplasma. Para a conservação de microrganismos, podem-se citar tubos de ensaio para estoques sob óleo, criotubos para congelamento e ultracongelamento, ampolas de vidro para liofilização, placas para repique contínuo. Tubos de ensaio de vidro são os mais comuns para a conservação in vitro. Para a criopreservação, são utilizados criotubos de material resistente à temperatura do nitrogênio líquido para embriões, meristemas, gemas apicais e laterais e sementes pequenas; e, para estruturas ou sementes maiores, utilizam-se os envelopes aluminizados trifoliados, selados a quente (Santos; Salomão, 2010).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 101](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 101 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0102 — Quais exemplos de germoplasma vegetal, animal e de microrganismo são utilizados na conservação ex situ?

**Variantes:** Queria entender: quais exemplos de germoplasma vegetal, animal e de microrganismo são utilizados na conservação ex situ? · exemplos germoplasma vegetal animal microrganismo utilizados conservação? · quais exemplos de germoplama vegetal, animal e de microrganismo sao utilizados na conservacao ex situ

• Vegetal: plantas, sementes, estacas, bulbos, pólen, óvulos, embriões, tecidos e células. • Animal: embrião, sêmen (espermatodozoide), ovócito, folículo pré-antral, célula somática e espermatogônia. • Microrganismo: bactérias, vírus, fungos, leveduras, algas unicelulares e protozoários.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 102](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 102 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0119 — Recursos genéticos: quais espécies podem ser conservadas usando a criopreservação?

**Variantes:** Alguém me explica: quais espécies podem ser conservadas usando a criopreservação (recursos genéticos)? · espécies conservadas usando criopreservação (recursos genéticos)? · quais especes podem ser conservadas usando a criopreservacao (recursos genéticos)

A criopreservação é indicada para a conservação em longo prazo de espécies de plantas de interesse atual ou potencial que produzem sementes recalcitrantes ou intermediárias, são propagadas vegetativamente, apresentam alta taxa de heterozigosidade ou longo período juvenil. Em animais, podem ser criopreservados gametas das principais espécies de mamíferos, peixes e aves, respeitando-se as peculiaridades de cada espécie. Para microrganismos, a criopreservação é bastante adequada para a preservação desde procariotos (bactérias de forma geral) quanto eucariotos, como os fungos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 119](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 119 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0124 — Recursos genéticos: o que é criorresistência de sêmen? Existem diferenças entre espécies?

**Variantes:** Me explica uma coisa: o que é criorresistência de sêmen? Existem diferenças entre espécies (recursos genéticos)? · criorresistência sêmen diferenças espécies (recursos genéticos)? · o q e criorresistencia de semen existem diferencas entre especes (recursos genéticos)

O sêmen de cada espécie tem um nível de sensibilidade à criopreservação, mais conhecido como criorresistência. A criorresistência do sêmen está muito relacionada à capacidade da membrana plasmática dos espermatozoides em reagir e se adaptar às alterações provocadas pelo processo de congelação, como mudanças de pH, osmolaridade e, em especial, de temperatura. Em consequência do processo de criopreservação, muitos desses espermatozoides sofrem uma capacitação precoce, chamada de criocapacitação. A capacitação é um processo natural ao qual o espermatozoide da maioria das espécies de mamíferos deve passar durante sua trajetória no sistema genital feminino e que o torna apto à fertilização.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 124](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 124 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0126 — Recursos genéticos: quais são os critérios adotados para a escolha do método de conservação ex situ de sementes?

**Variantes:** Me explica uma coisa: quais são os critérios adotados para a escolha do método de conservação ex situ de sementes (recursos genéticos)? · critérios adotados escolha método conservação ex situ (recursos genéticos)? · quais sao os criteros adotados pra a escolha do metodo de conservacao ex situ de sementes (recursos genéticos)

Os critérios adotados para a escolha do método de conservação são as características intrínsecas (fisiológicas, físicas, químicas, reprodutivas e ecológicas) das sementes. Considera-se, igualmente, a finalidade da conservação em curto, médio ou longo prazo, assim como a disponibilidade de infraestrutura, recursos financeiros e mão de obra. Semente ortodoxa é tolerante à desidratação a teores de água muito baixos e ao congelamento em temperaturas ultrabaixas como -18 °C e -196 °C. Semente com esse comportamento fisiológico é conservada por longo prazo em banco convencional de germoplasma semente e em banco criogênico. Semente intermediária tolera parcialmente a desidratação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 126](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 126 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0129 — Recursos genéticos: como fazer para conservar as sementes se as condições de refrigeração não forem adequadas?

**Variantes:** Tchê, me ajuda: como fazer para conservar as sementes se as condições de refrigeração não forem adequadas (recursos genéticos)? · conservar sementes condições refrigeração não forem adequadas (recursos genéticos)? · como fazer pra conservar as sementes se as condicoes de refrigeraao n forem adequadas (recursos genéticos)

Se as condições de refrigeração não forem adequadas, pode-se reduzir o conteúdo de água das sementes, dependendo do seu comportamento fisiológico. O efeito da umidade durante o armazenamento não pode ser analisado independentemente da temperatura, mas, se houver opção, é preferível armazenar sob baixa umidade. Existe uma regra prática, segundo a qual o período para o armazenamento seguro duplica para cada redução de 1% no teor de água das sementes ou decréscimo de 5,5 °C na temperatura ambiente (Marcos Filho, 2015). Essa regra deve ser utilizada para estimar o comportamento de sementes com graus de umidade entre 5% e 14% e temperatura entre 0 °C e 50 °C.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 129](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 129 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico. Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0133 — Recursos genéticos: qual é a diferença entre semente botânica e semente agronômica?

**Variantes:** Tu sabe me dizer: qual é a diferença entre semente botânica e semente agronômica (recursos genéticos)? · diferença semente botânica semente agronômica (recursos genéticos)? · qual e a diferenca entre semente botanca e semente agronomica (recursos genéticos)

O termo semente é usado para designar partes da planta com a capacidade de originar um novo indivíduo. Sob o ponto de vista da botânica, as sementes são formadas pela fecundação, ou seja, pela união de dois gametas, e, por essa razão, essa semente é denominada semente botânica. Muitas espécies são multiplicadas por meio de sementes botânicas, tais como milho, trigo, arroz, feijão, soja, algodão, e uma série de hortaliças, como tomate, pimentão, cenoura. Entretanto, algumas espécies, apesar de produzirem sementes botânicas, são usualmente reproduzidas por propágulos derivados de outras partes da planta e não pela semente botânica. Essa forma de multiplicação é denominada multiplicação ou propagação vegetativa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 133](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 133 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0147 — Recursos genéticos: o que são serviços ecossistêmicos da fauna e qual é sua importância na conservação in situ?

**Variantes:** Me tira uma dúvida: o que são serviços ecossistêmicos da fauna e qual é sua importância na conservação in situ (recursos genéticos)? · serviços ecossistêmicos fauna importância conservação in situ (recursos genéticos)? · o q sao servicos ecossistemicos da fauna e qual e sua importancia na conservaao in situ (recursos genéticos)

Os animais são muito importantes e, em alguns casos, essenciais para processos que ocorrem no ambiente. Entre esses processos, também chamados de serviços ecossistêmicos, podemos citar a polinização, a dispersão de sementes, o controle biológico e a decomposição.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 147](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 147 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0148 — Recursos genéticos: qual a importância da polinização realizada por animais na conservação in situ?

**Variantes:** Tu sabe me dizer: qual a importância da polinização realizada por animais na conservação in situ (recursos genéticos)? · importância polinização realizada animais conservação in situ (recursos genéticos)? · qual a importancia da polinizaao realizada por animais na conservacao in situ (recursos genéticos)

A polinização garante que as plantas gerem suas sementes e, em alguns grupos vegetais, também os frutos. Muitos desses frutos e sementes são utilizados na alimentação humana, assim como são essenciais para a manutenção da integridade dos ecossistemas. Como animais polinizadores, destacamos as abelhas, as moscas, os besouros, os pássaros (especialmente os beija-flores) e os morcegos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 148](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 148 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0149 — Recursos genéticos: qual é a importância da dispersão de sementes realizada por animais na conservação in situ?

**Variantes:** Uma pergunta: qual é a importância da dispersão de sementes realizada por animais na conservação in situ (recursos genéticos)? · importância dispersão sementes realizada animais conservação in (recursos genéticos)? · qual e a importancia da disperao de sementes realizada por animais na conservacao in situ (recursos genéticos)

Muitas plantas precisam de animais para dispersar suas sementes. Se as sementes ficassem sempre próximas à planta-mãe, suas populações seriam confinadas a pequenas áreas, e o adensamento poderia criar um sistema de competição por recursos diversos (nutrientes ou luz), o que prejudicaria o crescimento dos indivíduos mais jovens, além de limitar a possibilidade de cruzamentos que ampliam a diversidade genética da população. Outro aspecto é o de que muitas plantas necessitam da fauna para germinar suas sementes. Um exemplo é a relação de roedores (cotia e paca) com a castanheira.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 149](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 149 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0161 — Recursos genéticos: o que é restauração ecológica e qual é a sua importância na conservação in situ?

**Variantes:** Queria entender: o que é restauração ecológica e qual é a sua importância na conservação in situ (recursos genéticos)? · restauração ecológica importância conservação in situ (recursos genéticos)? · o q e restauracao ecologica e qual e a sua importancia na conservaao in situ (recursos genéticos)

É a intervenção feita em ecossistemas degradados ou alterados com o propósito de desencadear, facilitar ou acelerar o processo natural de sucessão ecológica. Com isso, a restauração ecológica se faz importante à conservação in situ por proporcionar a restauração da funcionalidade dos ecossistemas, dos seus serviços ambientais e da manutenção dos processos evolutivos necessários à manutenção de espécies.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 161](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 161 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0162 — Recursos genéticos: quais são os métodos utilizados na restauração ecológica com vistas a promover a conservação in situ?

**Variantes:** Me tira uma dúvida: quais são os métodos utilizados na restauração ecológica com vistas a promover a conservação in situ (recursos genéticos)? · métodos utilizados restauração ecológica vistas promover conservação (recursos genéticos)? · quais sao os metodos utilizados na restauraao ecologica com vistas a promover a conservacao in situ (recursos genéticos)

Os métodos consistem de atividades relacionadas à coleta de sementes de espécies nativas para o plantio via semeadura direta ou ainda do plantio de mudas. A restauração ecológica pode também se valer da transposição de solos de um local para o outro para se aproveitar do banco de sementes dos solos transpostos, ou ainda, da instalação de poleiros artificiais com vistas a facilitar o pousio de aves e a dispersão de sementes via deposição de fezes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 162](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 162 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0166 — Recursos genéticos: como estimular a conservação on farm?

**Variantes:** Me tira uma dúvida: como estimular a conservação on farm (recursos genéticos)? · estimular conservação on farm (recursos genéticos)? · como estimular a conservaao on farm (recursos genéticos)

É necessário fortalecer os diálogos e as interações entre os guardiões da agrobiodiversidade e os curadores dos bancos de germoplasma institucionais. Para isso é necessário: treinamento de multiplicadores em estratégias participativas para o manejo comunitário da agrobiodiversidade; desenvolvimento de protocolos comunitários relacionados à agrobiodiversidade; planejamento para o estabelecimento de bancos comunitários de sementes e o incentivo à formação e ao fortalecimento dos guardiões da agrobiodiversidade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 166](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 166 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0168 — O que é banco local da agrobiodiversidade ou banco de variedades crioulas?

**Variantes:** Me tira uma dúvida: o que é banco local da agrobiodiversidade ou banco de variedades crioulas? · banco local agrobiodiversidade banco variedades crioulas? · o q e banco local da agrobiodiversidde ou banco de variedades crioulas

É o espaço em que são conservadas, por agricultores familiares e povos ou comunidades tradicionais, as variedades crioulas, tradicionais ou locais. Os bancos são também denominados como casa ou banco de sementes, casa ou banco de agrobiodiversidade, casa ou banco comunitário de sementes, entre outros nomes. Esses bancos podem existir nos níveis familiar, comunitário ou regional. Considerado como uma tecnologia social, um banco local da agrobiodiversidade é importante para garantir a segurança alimentar e a conservação das sementes, contribuindo para a redução da fome e desnutrição da comunidade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 168](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 168 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0169 — O que é um guardião da agrobiodiversidade?

**Variantes:** Me tira uma dúvida: o que é um guardião da agrobiodiversidade? · guardião agrobiodiversidade? · o q e um guardiao da agrobiodiversidde

Guardião da agrobiodiversidade, também chamado de guardião de sementes, é a pessoa cujo envolvimento com a conservação da diversidade de variedades locais ajuda a criar mais segurança alimentar. Normalmente são agricultores que se diferenciam por manterem em seus cultivos uma rica variedade de produtos da agrobiodiversidade, sendo reconhecidos em sua comunidade como conservadores de sementes crioulas ou tradicionais. É muito importante que sejam reconhecidos como tal e incentivados à continuação de seu trabalho de conservação de recursos genéticos e do estímulo ao repasse intergeracional do conhecimento tradicional associado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 169](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 169 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0170 — O que é feira de sementes ou feira da agrobiodiversidade?

**Variantes:** Uma pergunta: o que é feira de sementes ou feira da agrobiodiversidade? · feira sementes feira agrobiodiversidade? · o q e feira de semenes ou feira da agrobiodiversidade

São espaços comunitários para troca de sementes e conhecimentos entre os agricultores. Essas feiras contribuem para fomentar o manejo comunitário da agrobiodiversidade, possibilitar o acesso a espécies e variedades agrícolas desaparecidas localmente, introduzir novas culturas nos sistemas locais e promover o intercâmbio de experiências entre os agricultores. São também espaços de comercialização de produtos da agricultura familiar.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 170](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 170 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0172 — Recursos genéticos: quais são os principais métodos participativos que promovem a conservação on farm?

**Variantes:** Me explica uma coisa: quais são os principais métodos participativos que promovem a conservação on farm (recursos genéticos)? · principais métodos participativos promovem conservação on farm (recursos genéticos)? · quais sao os principis metodos participativos q promovem a conservacao on farm (recursos genéticos)

Os principais métodos participativos utilizados na conservação on farm são os canteiros de diversidade, kits de diversidade, registro da biodiversidade comunitária, feiras da agrobiodiversidade e melhoramento participativo, entre outros. Os canteiros de diversidade correspondem ao cultivo, lado a lado, de variedades crioulas e/ou outras externas à comunidade, com a finalidade principal de compará-las, mas também de identificar o conhecimento local acerca da variedade crioula, entre outros. Os kits de diversidade consistem na disponibilização de um conjunto de amostras de sementes de variedades crioulas, atuais ou antigas, e de interesse dos agricultores e que podem estar sob risco de desaparecer.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 172](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 172 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0173 — Como o melhoramento participativo pode fortalecer a conservação de recursos genéticos?

**Variantes:** Bah, uma dúvida: como o melhoramento participativo pode fortalecer a conservação de recursos genéticos? · melhoramento participativo fortalecer conservação recursos genéticos? · como o melhorameto participativo pode fortalecer a conservacao de recursos geneticos

Os programas de melhoramento participativo integram os conhecimentos científicos e tradicionais, promovem a geração de novos conhecimentos, processos e produtos que fortalecem essas estratégias de conservação (ex situ e on farm) e a interação entre elas. Por exemplo, a seleção participativa de variedades crioulas nos ambientes com estresses biótico e abiótico (solos de baixa fertilidade, aridez, doenças, entre outros) pode identificar fontes de resistência para o desenvolvimento de novas cultivares, bem como prover importantes informações para conservação de recursos genéticos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 173](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 173 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0175 — O que é o processo de caracterização de um recurso genético?

**Variantes:** Alguém me explica: o que é o processo de caracterização de um recurso genético? · processo caracterização recurso genético? · o q e o proceso de caracterizacao de um recurso genetico

É o conjunto de atividades que usa ferramentas para aumentar o conhecimento sobre animais, plantas e microrganismos. A caracterização gera informações básicas (p. ex. taxonomia, morfologia, ecologia) ou aplicadas (p. ex. dados produtivos, nutricionais, inserção em programas de melhoramento, etc.).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 175](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 175 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0179 — Recursos genéticos: qual é a utilidade dos dados de caracterização?

**Variantes:** Tu sabe me dizer: qual é a utilidade dos dados de caracterização (recursos genéticos)? · utilidade dados caracterização (recursos genéticos)? · qual e a utilidade dos dados de caracterizaao (recursos genéticos)

O objetivo principal dos dados de caracterização é agregar valor aos recursos genéticos conservados in situ e ex situ, de forma que se aumente sua utilização. As informações geradas podem ser aplicadas na identificação de novos materiais para enriquecer bancos de germoplasma e programas de melhoramento genético; na definição de germoplasma para intercâmbio ou repatriamento; na identificação de material duplicado; na estimativa da diversidade genética das coleções e na identificação de genes de interesse econômico.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 179](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 179 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0184 — Recursos genéticos: como aferir a importância de um descritor?

**Variantes:** Me tira uma dúvida: como aferir a importância de um descritor (recursos genéticos)? · aferir importância descritor (recursos genéticos)? · como aferir a importancia de um descrior (recursos genéticos)

A validação de um descritor para caracterizar ou avaliar um acesso é conferida quando, por meio da sua aplicação, o curador consegue diferenciar e quantificar a variabilidade presente na coleção de germoplasma. A validação é normalmente realizada por meio de análise estatística, uni ou multivariada, em que a importância desse descritor é quantitativamente estimada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 184](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 184 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0194 — Recursos genéticos: qual é a diferença entre caracterização morfológica e agronômica?

**Variantes:** Bah, uma dúvida: qual é a diferença entre caracterização morfológica e agronômica (recursos genéticos)? · diferença caracterização morfológica agronômica (recursos genéticos)? · qual e a diferenca entre caracterizacao morfologca e agronomica (recursos genéticos)

Na caracterização morfológica, são medidos e avaliados os caracteres morfológicos do material, como largura e comprimento da folha, comprimento do entrenó superior, altura natural, comprimento da inflorescência, volume e número de sementes (caracteres mensuráveis), forma e coloração da folha, intensidade de pilosidade da folha, hábito de crescimento, tipo de cálice (caracteres visuais), dentre muitos outros. Na caracterização agronômica, são medidos e avaliados os caracteres ligados a aspectos produtivos do material, resistência a pragas e doenças, tolerância a estresses, produtividade e outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 194](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 194 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0201 — O que é necessário para se fazer a caracterização morfológica e agronômica/zootécnica de um recurso genético?

**Variantes:** Me tira uma dúvida: o que é necessário para se fazer a caracterização morfológica e agronômica/zootécnica de um recurso genético? · necessário fazer caracterização morfológica agronômica zootécnica recurso? · o q e necessario pra se fazer a caracterizacao morfologica e agronomica/zootecnica de um recurso genetco

A sequência de atividades necessária para esse tipo de caracterização é: delineamento experimental, disponibilidade de acessos ou indivíduos devidamente identificados, definição dos descritores a serem aplicados, execução do experimento, coleta dos dados, análise estatística dos dados e interpretação dos resultados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 201](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 201 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0202 — Qual é a principal aplicação da caracterização morfológica e agronômica/zootécnica de um recurso genético?

**Variantes:** Bah, uma dúvida: qual é a principal aplicação da caracterização morfológica e agronômica/zootécnica de um recurso genético? · principal aplicação caracterização morfológica agronômica zootécnica recurso? · qual e a princial aplicacao da caracterizacao morfologica e agronomica/zootecnica de um recurso genetico

Agregar valor a um banco de germoplasma ou núcleo de conservação com informações acerca do desempenho de seus acessos/indivíduos. Essa caracterização possibilita a formação de uma importante base de dados que pode subsidiar programas de melhoramento genético.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 202](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 202 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0204 — Como é feita a avaliação de acessos em um banco de germoplasma vegetal?

**Variantes:** Tchê, me ajuda: como é feita a avaliação de acessos em um banco de germoplasma vegetal? · feita avaliação acessos banco germoplasma vegetal? · como e feita a avaliacao de acessos em um banco de germoplama vegetal

A avaliação é o registro daquelas características cuja expressão é frequentemente influenciada por fatores ambientais, e muitas dessas características resultam de fortes interações entre genótipos por ambiente e, portanto, são específicas do local. Envolve a coleta metódica de dados sobre características agronômicas e de qualidade por meio de ensaios experimentais adequadamente planejados. É recomendado que os ensaios sejam conduzidos em, pelo menos, três locais ambientalmente diversos e em três ciclos vegetativos, e os dados comparados estatisticamente ao longo dos anos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 204](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 204 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0207 — Quais são os principais marcadores moleculares utilizados na caracterização de germoplasma?

**Variantes:** Queria entender: quais são os principais marcadores moleculares utilizados na caracterização de germoplasma? · principais marcadores moleculares utilizados caracterização germoplasma? · quais sao os principais marcadores moleculares utilizados na caracterizacao de germoplama

Os principais marcadores moleculares usados na caracterização e avaliação de germoplasma são os marcadores codominantes como microssatélites (SSR) e polimorfismos de base única (SNP). Eles substituíram amplamente os marcadores dominantes mais antigos, como polimorfismo de DNA amplificado ao acaso (RAPD), em razão da sua relativa abundância genômica e da alta reprodutibilidade de dados. Por exemplo, hoje existem ferramentas que permitem genotipar 700 mil marcadores de uma só vez em um bovino ou uma planta cultivada, como arroz ou soja.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 207](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 207 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0317 — Recursos genéticos: qual é a diferença entre registro de um produto e certificação de um produto orgânico?

**Variantes:** Uma pergunta: qual é a diferença entre registro de um produto e certificação de um produto orgânico (recursos genéticos)? · diferença registro produto certificação produto orgânico (recursos genéticos)? · qual e a diferenca entre registro de um produto e certificaao de um produto organico (recursos genéticos)

O registro de um produto é a forma legal de sua comercialização no país, seja por intermédio de formulação/fabricação dos seus componentes e/ou de importação deles. O objetivo do registro, entre outras coisas, é garantir a segurança da população e do meio ambiente, além de garantir seus padrões de qualidade e sua eficiência. O primeiro passo é o correto enquadramento do produto de acordo com o uso, a finalidade a que se destina, podendo ser enquadrado na Lei de Agrotóxicos e Afins – Lei nº 7.802, de 11 de julho de 1989 (Brasil 1989), na Lei dos Fertilizantes/Inoculantes ou até mesmo na Lei dos Domissanitários/Saneantes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 317](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 317 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico. Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0319 — Recursos genéticos: quando um produto biológico é considerado um inoculante?

**Variantes:** Uma pergunta: quando um produto biológico é considerado um inoculante (recursos genéticos)? · produto biológico considerado inoculante (recursos genéticos)? · quando um produto biologco e considerado um inoculante (recursos genéticos)

Segundo a regulamentação, os inoculantes são definidos como produtos que contenham microrganismos com atuação favorável ao crescimento de plantas, como os Bradyrhizobium sp. e Rhizobium sp. É de competência do Mapa, por meio de suas superintendências estaduais, as avaliações sobre os pleitos de registro de produtos e estabelecimentos, bem como os procedimentos de fiscalização. Existem normas específicas para orientar cada uma das categorias de produtos que estão sob a égide da Lei nº 6.894, de 16 de dezembro de 1980 (Brasil, 1980).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 319](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 319 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0354 — Recursos genéticos: qual é a situação atual da raça Mocho Nacional?

**Variantes:** Me explica uma coisa: qual é a situação atual da raça Mocho Nacional (recursos genéticos)? · situação atual raça mocho nacional (recursos genéticos)? · qual e a situaao atual da raca mocho nacional (recursos genéticos)

Essa raça de bovinos era dada como exemplo de extinção ou falência por se conhecer apenas um rebanho extremamente reduzido. Felizmente, mais tarde foram descobertos alguns outros criadores da raça em São Paulo e Paraná. São animais de precocidade média, com boa propensão para engorda e temperamento dócil. Por sua grande semelhança com o Caracu, atualmente os animais da raça Mocho Nacional estão sendo registrados pela Associação Brasileira de Criadores de Caracu (ABCC) como uma variedade Mocha da raça Caracu. Esse fato, aliado ao bom desempenho produtivo apresentado pelos animais, despertou o interesse de criadores que passaram a utilizar o sêmen em seu plantel.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 354](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 354 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico. Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0362 — Recursos genéticos: qual é a importância da raça Crioula Lageana?

**Variantes:** Me explica uma coisa: qual é a importância da raça Crioula Lageana (recursos genéticos)? · importância raça crioula lageana (recursos genéticos)? · qual e a importania da raca crioula lageana (recursos genéticos)

São animais adaptados às condições de solos ácidos e pedregosos, suportam altitudes elevadas e invernos rigorosos, já que foram selecionados por mais de 3 séculos, desde que foram introduzidos por jesuítas espanhóis no Planalto Sul-Brasileiro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 362](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 362 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0366 — Recursos genéticos: qual é a origem e importância do cavalo Campeiro?

**Variantes:** Me explica uma coisa: qual é a origem e importância do cavalo Campeiro (recursos genéticos)? · origem importância cavalo campeiro (recursos genéticos)? · qual e a origem e importania do cavalo campeiro (recursos genéticos)

A história do cavalo Campeiro, também chamado Marchador das Araucárias, tem origem em 1546, com a entrada dos jesuítas no Rio Grande do Sul e em Santa Catarina. O cavalo Campeiro tem grande resistência e capacidade de trabalho. Somente a partir de 1900 essa raça foi selecionada para a marcha. Existe uma associação da raça com uma dezena de filiados e não mais que uma centena de animais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 366](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 366 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0398 — Qual é a importância da preservação dos recursos genéticos diante do crescimento da biotecnologia e do desenvolvimento de organismos geneticamente modificados?

**Variantes:** Me explica uma coisa: qual é a importância da preservação dos recursos genéticos diante do crescimento da biotecnologia e do desenvolvimento de organismos geneticamente modificados? · importância preservação recursos genéticos diante crescimento biotecnologia? · qual e a importancia da preservacao dos recursos geneticos diante do crescimento da biotecnologia e do desenvolvimeto de organismos geneticamente modificados

A busca por características interessantes e promissoras para o desenvolvimento de bioinsumos, aplicados aos setores farmacêutico, biomédico, alimentar e agropecuário, tende a se ampliar por meio da bioprospecção em coleções de culturas microbianas reconhecidas e com qualidade na gestão e preservação dos recursos genéticos oriundos dos mais diferentes biomas e ambientes. Plantas geneticamente resistentes a herbicidas à base de glifosato, e também tolerantes ao ataque de pragas, são bons exemplos da importância dos microrganismos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 398](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 398 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico.

### AGTECH-RGEN-0421 — Recursos genéticos: quais são as principais formas de multiplicação de bactérias visando à produção de inoculantes?

**Variantes:** Queria entender: quais são as principais formas de multiplicação de bactérias visando à produção de inoculantes (recursos genéticos)? · principais formas multiplicação bactérias visando produção inoculantes (recursos genéticos)? · quais sao as principais formas de multiplicacao de bacteras visando a producao de inoculantes (recursos genéticos)

A maioria das bactérias utilizada em inoculantes cresce adequadamente em meios de cultura líquidos, com controle de temperatura e uma agitação orbital simples. Esse sistema se aplica para pequenas escalas, podendo ser utilizados frascos Erlenmeyer ou vasos de vidro com capacidade para aproximadamente 10 L para o cultivo celular. A multiplicação dos microrganismos em maior escala é feita também de forma submersa, em grandes tanques chamados fermentadores ou biorreatores. Esses são recipientes hermeticamente fechados, que recebem o meio de cultivo adequado para cada microrganismo e passam por uma etapa de esterilização.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 421](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 421 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0428 — Recursos genéticos: qual é a importância das bactérias do gênero Bacillus no controle biológico de insetos?

**Variantes:** Bah, uma dúvida: qual é a importância das bactérias do gênero Bacillus no controle biológico de insetos (recursos genéticos)? · importância bactérias gênero bacillus controle biológico insetos (recursos genéticos)? · qual e a importancia das bacterias do genero bacillus no contrle biologico de insetos (recursos genéticos)

Há mais de 40 anos se conhece a eficiência de bactérias do gênero Bacillus no controle de insetos, em culturas como milho e algodão. Atualmente, são conhecidas pelo menos 30 subespécies de B. thuringiensis (Bt) capazes de produzir toxinas, que são proteínas com ação inseticida. Quando o inseto ingere os esporos contendo os cristais proteicos, ainda durante a fase larval, seu trato digestivo é paralisado pela ação tóxica, e o indivíduo morre em alguns dias não completando seu ciclo de vida. Durante muito tempo, esporos contendo toxinas foram aplicados em ambientes infestados para controle de mosquitos urbanos (subespécie israelensis) com pouco ou nenhum impacto sobre espécies não alvo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 428](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 428 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico. Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0435 — Recursos genéticos: qual o significado do termo valoração, empregado em relação às coleções de culturas?

**Variantes:** Me tira uma dúvida: qual o significado do termo valoração, empregado em relação às coleções de culturas (recursos genéticos)? · significado termo valoração empregado relação coleções culturas (recursos genéticos)? · qual o significado do termo valoracao, empregado em relacao as colecoes de cultuas (recursos genéticos)

Valoração significa determinar o potencial de uso dos isolados agregando valor aos isolados mantidos na coleção. A determinação do potencial de uso é feita com base nas características do isolado, exigindo o estabelecimento de um banco de caracteres, que é o resultado de todos os estudos realizados em termos taxonômicos e fisiológicos, moleculares, bioquímicos, etc. Referências BRASIL. Lei nº 6.894, de 16 de dezembro de 1980. Dispõe sobre a inspeção e a fiscalização da produção e do comércio de fertilizantes, corretivos, inoculantes, estimulantes ou biofertilizantes, remineralizadores e substratos para plantas, destinados à agricultura, e dá outras providências.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 435](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 435 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0439 — Qual é a importância dos recursos genéticos regionais para a saúde?

**Variantes:** Alguém me explica: qual é a importância dos recursos genéticos regionais para a saúde? · importância recursos genéticos regionais saúde? · qual e a importania dos recursos geneticos regionais pra a saude

Os recursos genéticos regionais são fontes importantes de nutrientes e compostos bioativos fundamentais para nossa dieta e alternativas econômicas para os agricultores, principalmente da agricultura familiar. Em 2015, o Ministério da Saúde com a contribuição de uma equipe multidisciplinar, elaborou a publicação Alimentos regionais brasileiros, contendo uma extensa relação dos alimentos típicos de todas as regiões do País.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 439](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 439 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0445 — Recursos genéticos: o que é o ciclo de uma planta e quais são os tipos de ciclo que existem?

**Variantes:** Bah, uma dúvida: o que é o ciclo de uma planta e quais são os tipos de ciclo que existem (recursos genéticos)? · ciclo planta tipos ciclo (recursos genéticos)? · o q e o ciclo de uma planta e quais sao os tipos de ciclo q existem (recursos genéticos)

O ciclo diz respeito ao tempo de vida da planta, podendo ser anual ou perene. Essa classificação é regional. Uma mesma espécie pode ser selecionada como anual numa localidade e perene em outra. As plantas de ciclo anual germinam, desenvolvem e reproduzem em menos de 1 ano e priorizam a produção de sementes para atravessarem períodos desfavoráveis. Ocorrem, normalmente, em áreas de campo alteradas por distúrbios naturais (seca, geada, erosão) ou pelos homens (lavração, fogo, superpastejo, uso de herbicidas).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 445](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 445 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico. Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0450 — Quais outras instituições, no Brasil, conservam recursos genéticos vegetais?

**Variantes:** Queria entender: quais outras instituições, no Brasil, conservam recursos genéticos vegetais? · outras instituições brasil conservam recursos genéticos vegetais? · quais outras instituicoes, no brasil, conservam recursos geneticos vegetis

As organizações estaduais de pesquisa agropecuária (Oepas) como Instituto Agronômico de Campinas (IAC), Empresa de Pesquisa Agropecuária do Estado do Rio de Janeiro (Pesagro), Instituto Agronômico do Paraná (Iapar), Empresa de Pesquisa Agropecuária e Extensão Rural de Santa Catarina (Epagri), Empresa de Pesquisa Agropecuária de Minas Gerais (Epamig), Fundação Estadual de Pesquisa Agropecuária (Fepagro); universidades como Universidade Estadual de Campinas (Unicamp), Universidade Federal Rural do Rio de Janeiro (UFRRJ), Universidade Estadual do Norte Fluminense (Uenf). Também o Instituto Nacional de Pesquisa da Amazônia (Inpa) e a Emater em diferentes estados do Brasil, entre outras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 450](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 450 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

### AGTECH-RGEN-0455 — Recursos genéticos: como o Brasil, um país tropical, consegue produzir produtos de origem temperada como soja e maçã?

**Variantes:** Queria entender: como o Brasil, um país tropical, consegue produzir produtos de origem temperada como soja e maçã (recursos genéticos)? · brasil país tropical consegue produzir produtos origem (recursos genéticos)? · como o brasil, um pais tropical, consegue produzir produtos de origem temperda como soja e maca (recursos genéticos)

Um conjunto de ações de pesquisa foi necessário para possibilitar a adaptação de cultivos como a soja e a maçã. O uso da diversidade genética dessas espécies foi fundamental para o desenvolvimento de cultivares adaptadas às nossas condições tropicais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 455](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 455 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0470 — Recursos genéticos: qual é a diferença entre plantas hibernais e plantas estivais?

**Variantes:** Me tira uma dúvida: qual é a diferença entre plantas hibernais e plantas estivais (recursos genéticos)? · diferença plantas hibernais plantas estivais (recursos genéticos)? · qual e a diferenca entre plantas hibernis e plantas estivais (recursos genéticos)

A diferença entre plantas hibernais e estivais diz respeito à época do ano em que concentram seu crescimento: inverno e verão. Plantas hibernais são as plantas que completam o seu ciclo no inverno e são plantadas no verão. São forrageiras de clima temperado, de dias menos ensolarados, geralmente de pequeno crescimento, talos finos e folhagem tenra. Hibernais de inverno ou temperadas são espécies que crescem nos meses mais frios do ano. Germinam ou rebrotam no outono, desenvolvem durante o inverno, florescem na primavera.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 470](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 470 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0473 — Recursos genéticos: qual é o percentual da diversidade de plantas utilizada para alimentação humana?

**Variantes:** Queria entender: qual é o percentual da diversidade de plantas utilizada para alimentação humana (recursos genéticos)? · percentual diversidade plantas utilizada alimentação humana (recursos genéticos)? · qual e o percentual da diversidade de plantas utilizada pra alimentaao humana (recursos genéticos)

No mundo existem mais de 300 mil espécies de plantas. Dessas, cerca de 30 mil são comestíveis, mas apenas cerca de sete mil são utilizadas pelo homem e apenas 120 são cultivadas. Três espécies, milho, soja e arroz, constituem 50% das calorias ingeridas pelo homem. Cerca de 30 espécies constituem 95% da dieta humana. Apesar de termos uma diversidade ampla de espécies, utilizamos apenas pouco mais 30 espécies para nossa alimentação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 473](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 473 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0478 — Recursos genéticos: quais são as primeiras espécies de plantas que foram domesticadas?

**Variantes:** Queria entender: quais são as primeiras espécies de plantas que foram domesticadas (recursos genéticos)? · primeiras espécies plantas foram domesticadas (recursos genéticos)? · quais sao as primeiras especies de plantas q foram domesticaas (recursos genéticos)

As primeiras espécies de plantas domesticadas ainda são utilizadas até hoje. São elas: trigo, cevada e lentilha. Outras que podemos destacar são: milho, feijão, algodão, batata, abóbora, batata-doce, mamão, tomate, tabaco, abacate, pimentas, soja, arroz, cana-de-açúcar, centeio, aveia, ervilha, tâmaras, pêssego, figo, citros, uva, oliveira, café, milheto, cebola, melancia, cevada e outros. No Brasil, a mandioca, o amendoim e o abacaxi se destacam.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 478](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 478 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0481 — Recursos genéticos: quais são as espécies de plantas com maior contribuição no fornecimento de energia para o ser humano?

**Variantes:** Me explica uma coisa: quais são as espécies de plantas com maior contribuição no fornecimento de energia para o ser humano (recursos genéticos)? · espécies plantas maior contribuição fornecimento energia humano (recursos genéticos)? · quais sao as especes de plantas com maior contribuicao no fornecimento de energia pra o ser humano (recursos genéticos)

Atualmente, 30 espécies fornecem 95% das calorias consumidas pelos seres humanos. Destas, apenas quatro (arroz, soja, milho e batata) representam 60% do total das calorias ingeridas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 481](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 481 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0483 — Recursos genéticos: quais são as espécies de plantas com maior contribuição no fornecimento de substâncias bioativas para o ser humano?

**Variantes:** Queria entender: quais são as espécies de plantas com maior contribuição no fornecimento de substâncias bioativas para o ser humano (recursos genéticos)? · espécies plantas maior contribuição fornecimento substâncias bioativas (recursos genéticos)? · quais sao as especes de plantas com maior contribuicao no fornecimento de substancias bioativas pra o ser humano (recursos genéticos)

Frutas, legumes e cereais integrais, por exemplo, contêm grande parte das substâncias funcionais e, por isso, devem ser consumidos diariamente. Como exemplos têm-se o abacate (rico em vitaminas E e C, potentes antioxidantes), alho e cebola (alicina e compostos derivados), chá-verde (compostos fenólicos, antioxidantes), couve, brócolis, repolho e nabo, entre outros vegetais crucíferos (glicosinolatos, antioxidantes e fibras), aveia, trigo e arroz integral, entre outras fibras (ricos em glucanas), pimenta (capsaicinoides), tomate vermelho, amora e goiaba vermelha (carotenoide, licopeno).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 483](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 483 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019). Pergunta original do livro sem menção explícita ao tema; prefixo "Recursos genéticos" adicionado para dar contexto.

### AGTECH-RGEN-0485 — Quais são os recursos genéticos prioritários para a alimentação e conservação no Brasil?

**Variantes:** Tu sabe me dizer: quais são os recursos genéticos prioritários para a alimentação e conservação no Brasil? · recursos genéticos prioritários alimentação conservação brasil? · quais sao os recuros geneticos prioritarios pra a alimentacao e conservacao no brasil

Os recursos genéticos prioritários para a alimentação e a conservação são: soja, milho, cana-de-açúcar, café, laranja, arroz, feijão, trigo, batata, mandioca, amendoim, cevada, banana e tomate.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Recursos genéticos: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 485](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118901/2/500-PERGUNTAS-Recursos-Geneticos-ed-01-2019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Recursos genéticos: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118901) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 485 do livro da Embrapa "Recursos genéticos: o produtor pergunta, a Embrapa responde" (2019).

## Biotecnologia

### AGTECH-WK-0014 — O que é biotecnologia?

**Variantes:** Biotecnologia: o que significa? · Me explica o que é biotecnologia · oq é biotecnologia · biotecnologia? · Defina biotecnologia

Biotecnologia (biologia aplicada) é a tecnologia baseada nas ciências biológicas, em qualquer nível: molecular, celular, morfofisiológico, ecológico, biodiversidade, reprodução e genética. Ou seja, trata-se de olhar as diferentes ciências biológicas não pelo ângulo da preservação e descrição, mas pelo ângulo da produção econômica (produtos, serviços e tecnologias), tal qual definido em A Convenção sobre Diversidade Biológica da ONU: A biotecnologia clássica (fase 1) se baseia na utilização de organismos vivos da forma como são encontrados na natureza ou melhorados por genética estatística convencional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Biotecnologia](https://pt.wikipedia.org/wiki/Biotecnologia) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biotecnologia" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0015 — O que é organismo geneticamente modificado?

**Variantes:** Organismo geneticamente modificado: o que significa? · Me explica o que é organismo geneticamente modificado · oq é organismo geneticamente modificado · organismo geneticamente modificado? · Defina organismo geneticamente modificado

Organismos Geneticamente Modificados, frequentemente referidos pela sigla OGM, são organismos manipulados geneticamente de modo a favorecer características desejadas, como a cor, tamanho, etc. Os OGMs possuem alteração em trechos do genoma realizadas através da tecnologia do RNA/DNA recombinante ou engenharia genética. Na maior parte das vezes, quando se fala em Organismos Geneticamente Modificados, trata-se de organismos transgênicos. Mas OGMs e transgênicos não são sinônimos: todos os transgênicos são organismos geneticamente modificados, mas nem todos os OGM são transgênicos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Organismos geneticamente modificados](https://pt.wikipedia.org/wiki/Organismos_geneticamente_modificados) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Organismos geneticamente modificados" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0016 — O que é edição genética?

**Variantes:** Edição genética: o que significa? · Me explica o que é edição genética · oq é edicao genetica · edição genética? · Defina edição genética

Edição de genoma é um tipo de engenharia genética em que o ADN é inserido, substituído, ou removido de um genoma utilizando nucleases modificadas artificialmente, ou "tesoura molecular". Ao contrário das técnicas de engenharia genética anteriores, em que o material genético era inserido aleatoriamente no genoma do hospedeiro, a edição do genoma direciona as inserções para locais específicos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Edição de genoma](https://pt.wikipedia.org/wiki/Edi%C3%A7%C3%A3o_de_genoma) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Edição de genoma" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0017 — O que é CRISPR?

**Variantes:** CRISPR: o que significa? · Me explica o que é CRISPR · oq é crispr · CRISPR? · Defina CRISPR

O sistema CRISPR (do inglês Clustered Regularly Interspaced Short Palindromic Repeats), ou seja, Repetições Palindrômicas Curtas Agrupadas e Regularmente Interespaçadas, consiste em pequenas porções do DNA bacteriano compostas por repetições de nucleotídeos. Cada uma dessas repetições encontra-se adjacente a um “protoespaçador” (“espaçador de DNA”), que corresponde a uma região não-codificante inserida no DNA bacteriano após o contato com genomas invasores provenientes de bacteriófagos ou plasmídeos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – CRISPR](https://pt.wikipedia.org/wiki/CRISPR) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "CRISPR" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0018 — O que é melhoramento genético?

**Variantes:** Melhoramento genético: o que significa? · Me explica o que é melhoramento genético · oq é melhoramento genetico · melhoramento genético? · Defina melhoramento genético

O melhoramento genético é um campo de estudo que visa aprimorar características desejáveis em seres vivos para diferentes finalidades. Esse método de manipulação genética tem contribuído para avanços em vários campos, como a agricultura, a pecuária e a sustentabilidade; contemplando demandas econômicas, nutricionais, ambientais e sociais da atualidade. Historicamente, a prática da seleção artificial e cruzamento de agricultores e pecuaristas escolhiam plantas e animais com características desejáveis para reprodução, pode ser considerado um dos primeiros passos do melhoramento genético.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*KB Fenasoja:* EVT-006
*Fontes:* [Wikipédia (pt) – Melhoramento genético](https://pt.wikipedia.org/wiki/Melhoramento_gen%C3%A9tico) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Melhoramento genético" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0019 — O que é melhoramento de plantas?

**Variantes:** Melhoramento de plantas: o que significa? · Me explica o que é melhoramento de plantas · oq é melhoramento de plantas · melhoramento de plantas? · Defina melhoramento de plantas

Melhoramento de plantas é a ciência de alterar as características das plantas para produzir os resultados desejados. Isso tem sido usado para melhorar a qualidade da nutrição em produtos para humanos e animais. Os objetivos do melhoramento de plantas são produzir variedades de culturas que possuam características únicas e superiores para várias aplicações agrícolas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Melhoramento de plantas](https://pt.wikipedia.org/wiki/Melhoramento_de_plantas) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Melhoramento de plantas" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0020 — O que é cultivar?

**Variantes:** Cultivar: o que significa? · Me explica o que é cultivar · oq é cultivar · cultivar? · Defina cultivar

Cultivar é a designação dada a determinada forma de uma planta cultivada, correspondendo a um determinado genótipo e fenótipo que foi selecionado e recebeu um nome único e devidamente registado com base nas suas características produtivas, decorativas ou outras que o tornem interessante para cultivo. O cultivar deve apresentar em cultura, e manter durante o processo de propagação, um conjunto único de características que o distingam de maneira coerente de plantas semelhantes da mesma espécie.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Cultivar](https://pt.wikipedia.org/wiki/Cultivar) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Cultivar" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0021 — O que são bacillus thuringiensis?

**Variantes:** Bacillus thuringiensis: o que significa? · Me explica o que são bacillus thuringiensis · oq sao bacillus thuringiensis · bacillus thuringiensis? · Defina bacillus thuringiensis

Bacillus thuringiensis é uma espécie microbiológica da família Bacillaceae. Foi descoberto em 1911 por Ernst Berliner na província de Thuringia, Alemanha. Passou a ser utilizado como inseticida na França em 1938, e nos Estados Unidos da América na década de 1950. O Bacillus thuringiensis é uma bactéria de solo presente em todos os continentes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Bacillus thuringiensis](https://pt.wikipedia.org/wiki/Bacillus_thuringiensis) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Bacillus thuringiensis" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0022 — O que é Comissão Técnica Nacional de Biossegurança?

**Variantes:** Comissão Técnica Nacional de Biossegurança: o que significa? · Me explica o que é Comissão Técnica Nacional de Biossegurança · oq é comissao tecnica nacional de biosseguranca · Comissão Técnica Nacional de Biossegurança? · Defina Comissão Técnica Nacional de Biossegurança

A Comissão Técnica Nacional de Biossegurança (CTNBio) é uma instância colegiada multidisciplinar, criada através da lei nº 8.974, de 5 de janeiro de 1995.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Comissão Técnica Nacional de Biossegurança](https://pt.wikipedia.org/wiki/Comiss%C3%A3o_T%C3%A9cnica_Nacional_de_Biosseguran%C3%A7a) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Comissão Técnica Nacional de Biossegurança" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0023 — O que é marcador molecular?

**Variantes:** Marcador molecular: o que significa? · Me explica o que é marcador molecular · oq é marcador molecular · marcador molecular? · Defina marcador molecular

Marcador molecular são sequências de DNA que revelam polimorfismos entre indivíduos geneticamente relacionados. Os marcadores moleculares são amplamente utilizados para estudo populacional, mapeamento e análises de similaridade e ainda, distância genética. Além disso, é possível, com estes, identificarem acessos de plantas, isolados de um microrganismo ou até completar estudos de sistemática. Esta revisão tem o objetivo de esclarecer as utilidades aplicacionais dos marcadores moleculares, e também as diferentes técnicas utilizadas, no estudo dos marcadores moleculares, e suas respectivas particularidades, todas com a meta de detectar polimorfismos em uma molécula de DNA.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Marcador molecular](https://pt.wikipedia.org/wiki/Marcador_molecular) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Marcador molecular" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0024 — O que é genômica?

**Variantes:** Genômica: o que significa? · Me explica o que é genômica · oq é genomica · genômica? · Defina genômica

Genômica (português brasileiro) ou genómica (português europeu) é um ramo da genética que estuda o genoma completo de um organismo. Essa ciência pode se dedicar a determinar a sequência completa do DNA de organismos ou apenas ao mapeamento de uma escala genética menor.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Genómica](https://pt.wikipedia.org/wiki/Gen%C3%B3mica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Genómica" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0025 — O que é clonagem?

**Variantes:** Clonagem: o que significa? · Me explica o que é clonagem · oq é clonagem · clonagem? · Defina clonagem

Clonagem é a produção de indivíduos geneticamente iguais. É um processo de reprodução assexuada que resulta na obtenção de cópias geneticamente idênticas de um mesmo ser vivo – micro-organismo, vegetal ou animal. A reprodução assexuada é um método próprio dos organismos constituídos por duas ou mais ou por um escasso número de células, por via de regra absolutamente dependentes do meio onde vivem e muito vulneráveis às suas modificações. Clonagem em biologia é o processo de produção das populações de indivíduos geneticamente idênticos, que ocorre na natureza quando organismos, tais como bactérias, insetos e plantas se reproduzem assexuadamente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Clonagem](https://pt.wikipedia.org/wiki/Clonagem) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Clonagem" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0026 — O que é cultura de tecidos?

**Variantes:** Cultura de tecidos: o que significa? · Me explica o que é cultura de tecidos · oq é cultura de tecidos · cultura de tecidos? · Defina cultura de tecidos

Cultura de tecidos refere-se ao desenvolvimento de tecidos e/ou células separados de um organismo. Isto é facilitado tipicamente através do uso de um meio de cultura líquido, semi-sólido ou sólido, tais como um caldo ou ágar. A expressão "cultura de tecidos" é empregada mais frequentemente em referência a cultura de tecidos e células de animais, enquanto que a expressão mais específica cultura de tecidos de plantas é utilizada para vegetais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Cultura de tecidos](https://pt.wikipedia.org/wiki/Cultura_de_tecidos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Cultura de tecidos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0027 — O que é proteção de cultivares?

**Variantes:** Proteção de cultivares: o que significa? · Me explica o que é proteção de cultivares · oq é protecao de cultivares · proteção de cultivares? · Defina proteção de cultivares

Proteção de Cultivares ou Plant Variety Protection é um direito sui generis de propriedade intelectual sobre as novas cultivares (variedades cultivadas de plantas). Cultivar é a variedade de qualquer gênero ou espécie vegetal superior, bem como a linhagem componente de híbridos. Para ser passível de proteção, a cultivar deve ser nova, homogênea e estável, possuir denominação própria, distintividade e ser útil.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Proteção de cultivares](https://pt.wikipedia.org/wiki/Prote%C3%A7%C3%A3o_de_cultivares) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Proteção de cultivares" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Conectividade e startups

### AGTECH-WK-0039 — O que é startup?

**Variantes:** Startup: o que significa? · Me explica o que é startup · oq é startup · startup? · Defina startup

Uma startup (termo da língua inglesa sem tradução oficial) é uma empresa emergente e recém-criada ainda em fase de desenvolvimento, de alto potencial e alto risco, que começa do zero com poucos recursos, e que apresenta um conceito inovador ao mercado. Tal empresa tem como objetivo principal desenvolver ou aprimorar um modelo de negócio, preferencialmente escalável, disruptivo e repetível. Uma startup é comumente relacionada a tecnologia, mas pode aparecer em vários setores; O termo tornou-se popular internacionalmente durante a bolha da internet. quando um grande número de "empresas.com" foram fundadas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Startup](https://pt.wikipedia.org/wiki/Startup) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Startup" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0040 — O que é aceleradora?

**Variantes:** Aceleradora: o que significa? · Me explica o que é aceleradora · oq é aceleradora · aceleradora? · Defina aceleradora

Aceleradoras de startups são um tipo moderno de incubadoras de empresas. As aceleradoras, no entanto, tem uma metodologia mais complexa e estruturada. O processo para participar das aceleradoras é aberto, e estas geralmente procuram por startups consistindo de um team para apoiá-los financeiramente, oferecer consultoria, treinamento e participação em eventos durante um período específico, que pode ser de três a oito meses. Em troca, as aceleradoras recebem participação acionária na empresa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Aceleradora](https://pt.wikipedia.org/wiki/Aceleradora) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Aceleradora" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0041 — O que é incubadora de empresas?

**Variantes:** Incubadora de empresas: o que significa? · Me explica o que é incubadora de empresas · oq é incubadora de empresas · incubadora de empresas? · Defina incubadora de empresas

Uma incubadora de empresas, ou apenas incubadora, é um projeto ou uma empresa que tem como objetivo a criação ou o desenvolvimento de pequenas empresas ou microempresas, apoiando-as nas primeiras etapas de suas vidas. As incubadoras universitárias de empresas têm como objetivo abrigar empresas inovadoras frutos de projetos de pesquisa e desenvolvimento científico e tecnológico.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Incubadora de empresas](https://pt.wikipedia.org/wiki/Incubadora_de_empresas) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Incubadora de empresas" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0042 — O que é capital de risco?

**Variantes:** Capital de risco: o que significa? · Me explica o que é capital de risco · oq é capital de risco · capital de risco? · Defina capital de risco

Capital de risco, capital empreendedor, capital de investimento, é uma modalidade de investimentos alternativos utilizada para apoiar negócios por meio da compra de uma participação acionária, geralmente minoritária, com objetivo de ter as ações valorizadas para posterior saída da operação. Chama-se capital de risco não pelo risco do capital, porque qualquer investimento, mesmo a aplicação tradicional, em qualquer banco tem um risco, mas pela aposta em empresas cujo potencial de valorização é elevado e o retorno esperado é idêntico ao risco que os investidores querem correr.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Capital de risco](https://pt.wikipedia.org/wiki/Capital_de_risco) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Capital de risco" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0043 — O que é Investidor-anjo?

**Variantes:** Investidor-anjo: o que significa? · Me explica o que é Investidor-anjo · oq é investidor-anjo · Investidor-anjo? · Defina Investidor-anjo

Investidor anjo é uma pessoa física ou jurídica que faz investimentos com seu próprio capital em empresas nascentes com um alto potencial de crescimento, como as startups.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Investidor-anjo](https://pt.wikipedia.org/wiki/Investidor-anjo) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Investidor-anjo" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0044 — O que é parque tecnológico?

**Variantes:** Parque tecnológico: o que significa? · Me explica o que é parque tecnológico · oq é parque tecnologico · parque tecnológico? · Defina parque tecnológico

Um parque tecnológico é uma concentração geográfica de empresas, instituições de ensino, incubadoras de negócios, centros de pesquisa e laboratórios que criam um ambiente favorável à inovação tecnológica. À medida que passam a compartilhar do mesmo ambiente, empresas, universidades, centros de pesquisa e investidores, geram benefícios econômicos em comum e para a comunidade, são ambientes quando consolidados oferecem excepcional qualidade de desenvolvimento urbano, permitindo a geração de polos de desenvolvimento social e econômico.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Parque tecnológico](https://pt.wikipedia.org/wiki/Parque_tecnol%C3%B3gico) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Parque tecnológico" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0045 — O que é inovação aberta?

**Variantes:** Inovação aberta: o que significa? · Me explica o que é inovação aberta · oq é inovacao aberta · inovação aberta? · Defina inovação aberta

Inovação aberta (open innovation) é um termo abrangente criado por Henry Chesbrough, professor e diretor executivo no Centro de Inovação Aberta da Universidade de Berkeley e chairman do Centro de Open Innovation - Brasil.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Inovação aberta](https://pt.wikipedia.org/wiki/Inova%C3%A7%C3%A3o_aberta) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Inovação aberta" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0046 — O que é 4G?

**Variantes:** 4G: o que significa? · Me explica o que é 4G · oq é 4g · 4G? · Defina 4G

4G é a denominação usual da quarta geração de tecnologias de redes móveis celulares, desenvolvida para oferecer banda larga móvel, maior eficiência espectral e menor latência em comparação com as redes de terceira geração (3G). No uso comercial, o termo passou a ser associado principalmente ao LTE e às suas evoluções, como o LTE Advanced, embora a especificação formal da União Internacional de Telecomunicações (UIT) para sistemas de quarta geração seja o conjunto de requisitos denominado IMT-Advanced.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – 4G](https://pt.wikipedia.org/wiki/4G) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "4G" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0047 — O que é 5G?

**Variantes:** 5G: o que significa? · Me explica o que é 5G · oq é 5g · 5G? · Defina 5G

Em telecomunicações, o 5G é o padrão de tecnologia de quinta geração para redes móveis e de banda larga que as empresas de telefonia celular começaram a implantar em todo o mundo no final do ano de 2018. É o sucessor planejado das redes 4G que fornecem conectividade para a maioria dos dispositivos atuais. Como suas antecessoras, as redes 5G são redes móveis, nas quais a área de serviço é dividida em pequenas áreas geográficas chamadas de células. Todos os dispositivos sem fio 5G, em uma célula, são conectados à internet e à rede telefônica por ondas de rádio, por meio de um transmissor local na célula.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – 5G](https://pt.wikipedia.org/wiki/5G) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "5G" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0048 — O que é LoRaWAN?

**Variantes:** LoRaWAN: o que significa? · Me explica o que é LoRaWAN · oq é lorawan · LoRaWAN? · Defina LoRaWAN

LoRaWAN (Long Range Wide Area Network) é um protocolo de comunicação sem fio projetado para redes de longa distância e baixo consumo de energia, sendo amplamente utilizado em aplicações de Internet das Coisas (IoT). Ele é baseado na tecnologia de modulação LoRa (Long Range), desenvolvida pela empresa Semtech, que permite a transmissão de dados em baixas taxas através de bandas de frequência não licenciadas. Enquanto o LoRa define a camada física de comunicação, o LoRaWAN especifica a camada de rede, incluindo protocolos para comunicação entre dispositivos finais, gateways e servidores de aplicação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – LoRaWAN](https://pt.wikipedia.org/wiki/LoRaWAN) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "LoRaWAN" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0049 — O que é internet via satélite?

**Variantes:** Internet via satélite: o que significa? · Me explica o que é internet via satélite · oq é internet via satelite · internet via satélite? · Defina internet via satélite

Internet via satélite é um método de acesso à Internet que pode ser oferecido em qualquer parte do planeta. Possibilita altas taxas de transferência de dados, sendo sua comunicação feita do cliente para o satélite e deste para o servidor (ou podendo passar o sinal por outros satélites interligados). Como a maioria dos serviços de banda larga, a transmissão por satélite se faz de modo bidirecional (recebimento e envio de dados). Atualmente, a velocidade da ligação via satélite está entre 5 e 22 Mbps.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Internet via satélite](https://pt.wikipedia.org/wiki/Internet_via_sat%C3%A9lite) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Internet via satélite" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0050 — O que é Starlink?

**Variantes:** Starlink: o que significa? · Me explica o que é Starlink · oq é starlink · Starlink? · Defina Starlink

Starlink Services, LLC, que opera sob o nome Starlink, é uma subsidiária de telecomunicações da empresa aeroespacial norte-americana SpaceX. Ela fornece acesso à Internet de banda larga em cerca de 160 países e territórios. A empresa também pretende oferecer banda larga móvel em escala mundial. A SpaceX começou a lançar satélites Starlink em 2019.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Starlink](https://pt.wikipedia.org/wiki/Starlink) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Starlink" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0051 — O que é Hackathon?

**Variantes:** Hackathon: o que significa? · Me explica o que é Hackathon · oq é hackathon · Hackathon? · Defina Hackathon

Hackathon (palavra-valise inglesa, formada pelos vocábulos to hack, 'fatiar', 'quebrar', 'alterar ou ter acesso a um arquivo ou rede', e marathon, maratona), termo eventualmente aportuguesado para "hackaton," é uma maratona de programação na qual hackers se reúnem por horas, dias ou até semanas, a fim de explorar dados abertos, desvendar códigos e sistemas lógicos, discutir novas ideias e desenvolver projetos de software ou mesmo de hardware. Por ser um evento público (também referido como hack day, hackfest ou codefest), a maratona dá visibilidade e transparência a essas atividades, além de divulgar os novos produtos gerados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Hackathon](https://pt.wikipedia.org/wiki/Hackathon) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Hackathon" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0052 — O que é economia digital?

**Variantes:** Economia digital: o que significa? · Me explica o que é economia digital · oq é economia digital · economia digital? · Defina economia digital

A Economia digital refere-se a uma economia baseada em tecnologias de computação digital. A economia digital também é às vezes chamada de Economia da Internet, Nova Economia ou Economia da Web. Cada vez mais, a "economia digital" está entrelaçada com a economia tradicional, dificultando um delineamento claro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Economia digital](https://pt.wikipedia.org/wiki/Economia_digital) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Economia digital" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Bioinsumos

### AGTECH-WK-0028 — O que é Biofertilizante?

**Variantes:** Biofertilizante: o que significa? · Me explica o que é Biofertilizante · oq é biofertilizante · Biofertilizante? · Defina Biofertilizante

Biofertilizante é o subproduto da biodigestão e é de extrema importância como o próprio biogás. Possui características fertiprotetoras, também atuando como defensivo agrícola e repositores de matéria orgânica do solo. Podem ser obtidos por vias aeróbicas e/ou anaeróbicas, com a montagem do sistema de produção podendo ser adaptada de acordo com as necessidades e capacidades de cada produtor.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Biofertilizante](https://pt.wikipedia.org/wiki/Biofertilizante) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biofertilizante" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0029 — O que é biopesticida?

**Variantes:** Biopesticida: o que significa? · Me explica o que é biopesticida · oq é biopesticida · biopesticida? · Defina biopesticida

Segundo a Agência de Proteção Ambiental dos Estados Unidos, "biopesticidas são substâncias de ocorrência natural (pesticidas bioquímicos) que controlam pragas, micro-organismos que controlam pragas (pesticidas microbianos), e substâncias com acção pesticida produzidas por plantas contendo material genético adicionado (incluído em culturas geneticamente modificadas)". Vários materiais de ocorrências naturais, incluindo extractos de plantas e fungos, têm sido descritos como biopesticidas. Alguns exemplos são: quitina quitosano espinosinas feromonas de insectos e outros semioquímicos

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Biopesticida](https://pt.wikipedia.org/wiki/Biopesticida) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biopesticida" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0030 — O que é Trichoderma?

**Variantes:** Trichoderma: o que significa? · Me explica o que é Trichoderma · oq é trichoderma · Trichoderma? · Defina Trichoderma

Trichoderma é um género de fungos filamentosos pertencente à família Hypocreaceae, amplamente distribuído em diversos ecossistemas terrestres, com especial prevalência em solos agrícolas, florestais e em matéria orgânica em decomposição. Estes organismos são reconhecidos pela sua extraordinária capacidade de adaptação metabólica, permitindo-lhes colonizar nichos ecológicos variados e competir eficazmente com outros micro-organismos através de mecanismos complexos de micoparasitismo, antibiose e competição por nutrientes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Trichoderma](https://pt.wikipedia.org/wiki/Trichoderma) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Trichoderma" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0031 — O que são Bacillus?

**Variantes:** Bacillus: o que significa? · Me explica o que são Bacillus · oq sao bacillus · Bacillus? · Defina Bacillus

São bactérias com forma de bastonetes, Gram-positivas, obrigatoriamente ou facultativamente aeróbias, catalase positivas, produtoras de endósporos (esporos internos à bactéria) e de muitas enzimas, algumas tóxicas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Bacillus](https://pt.wikipedia.org/wiki/Bacillus) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Bacillus" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0032 — O que é beauveria bassiana?

**Variantes:** Beauveria bassiana: o que significa? · Me explica o que é beauveria bassiana · oq é beauveria bassiana · beauveria bassiana? · Defina beauveria bassiana

Beauveria bassiana é um fungo que existe naturalmente nos solos de todo o mundo. Causa uma doença fatal em vários insetos agindo como um parasita; pertencendo deste modo ao grupo de fungos entomopatogênicos. A espécie foi nomeada em homenagem ao entomologista italiano Agostino Bassi, que descobriu em 1835 ser a causa da doença muscardina que atacava e matava o domesticado bicho-da-seda. Espécies de Beauveria são fungos entomopatogênicos brancos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Beauveria bassiana](https://pt.wikipedia.org/wiki/Beauveria_bassiana) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Beauveria bassiana" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0033 — O que é metarhizium anisopliae?

**Variantes:** Metarhizium anisopliae: o que significa? · Me explica o que é metarhizium anisopliae · oq é metarhizium anisopliae · metarhizium anisopliae? · Defina metarhizium anisopliae

Metarhizium anisopliae, anteriormente conhecido como Entomophthora anisopliae (basiónimo), é um fungo que cresce naturalmente em solos de todo o mundo, causador de doença em várias espécies de insectos os quais parasita. Desde há muito tempo que se reconhece que muitos isolados são específicos, tendo-lhes sido atribuído estatuto de variedade, mas foram recentemente classificados como novas espécies de Metarhizium, como M. anisopliae, M. majus e M. acridum (antes M. anisopliae var. acridum e incluindo os isolados usados no controlo de gafanhotos).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Metarhizium anisopliae](https://pt.wikipedia.org/wiki/Metarhizium_anisopliae) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Metarhizium anisopliae" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0034 — O que é controle biológico por microrganismos?

**Variantes:** Controle biológico por microrganismos: o que significa? · Me explica o que é controle biológico por microrganismos · oq é controle biologico por microrganismos · controle biológico por microrganismos? · Defina controle biológico por microrganismos

O controle biológico tem como princípio controlar pragas agrícolas e insetos transmissores de doenças, baseado no uso de seus inimigos naturais, tal como outros insetos benéficos, predadores, parasitóides, e também microrganismos como por exemplo, fungos, vírus e bactérias. Realizar o controle biológico de pragas, é um período muito importante para que possa se impedir doenças contagiosas, prejuízos nas lavouras, e com o avanço do agronegócio, implementaram diversas possibilidades para que esses problemas possam ser solucionados, que são tão incidentes, e também desafios para os produtores rurais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Controle biológico por microrganismos](https://pt.wikipedia.org/wiki/Controle_biol%C3%B3gico_por_microrganismos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Controle biológico por microrganismos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0035 — O que é feromônio?

**Variantes:** Feromônio: o que significa? · Me explica o que é feromônio · oq é feromonio · feromônio? · Defina feromônio

Feromônios, ferormônios (português brasileiro) ou feromonas ou ferormonas (português europeu) (do grego φέρω phero "transmitir" e hormona, do grego ὁρμή "excitar") são substâncias químicas produzidas para fora do corpo que, ao serem disseminadas, promovem determinadas reações dentre outros individuos de uma mesma espécie. A palavra pheromone foi criada pelos cientistas Peter Karlson e Adolf Butenandt, por volta de 1959, a partir do grego antigo ϕέρω (pherein) "transportar" e ὁρμῶν (hormon), particípio presente de ὁρμάω (órmao) "excitar". Portanto, o termo já indica que se trata de substâncias que provocam excitação ou estímulo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Feromônio](https://pt.wikipedia.org/wiki/Ferom%C3%B4nio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Feromônio" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0036 — O que é biochar?

**Variantes:** Biochar: o que significa? · Me explica o que é biochar · oq é biochar · biochar? · Defina biochar

Biochar (termo de origem na língua inglesa, a partir de bio- e charcoal, "carvão vegetal"; também chamado 'biocarbono') é o nome que tem o carvão vegetal quando é empregado como correção para o solo. Ou seja, é biomassa de origem vegetal processada por meio de pirólise. Este uso do carbono tem vindo a ser investigado como forma de sequestrar carbono para reduzir as emissões de dióxido de carbono e recentemente isso foi demonstrado para o caso da China. Por isso, este sistema tem o potencial de ajudar a mitigar as alterações climáticas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Wikipédia (pt) – Biochar](https://pt.wikipedia.org/wiki/Biochar) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biochar" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0037 — O que é biogás?

**Variantes:** Biogás: o que significa? · Me explica o que é biogás · oq é biogas · biogás? · Defina biogás

Biogás é o nome comum dado a uma mistura de gases que foi produzida pela decomposição biológica da matéria orgânica na ausência de oxigênio. Normalmente consiste em uma mistura gasosa composta principalmente de gás metano (CH4) e gás carbônico (CO2), com pequenas quantidades de gás sulfídrico (H2S) e umidade. A produção de biogás ocorre naturalmente em qualquer local submerso em que o oxigênio atmosférico não consiga penetrar, como em pântanos, no fundo de copos d'água, intestino de animais, ou de forma antrópica como em aterros sanitários e usinas de biogás (ver: Biodigestor anaeróbico).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Biogás](https://pt.wikipedia.org/wiki/Biog%C3%A1s) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biogás" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0038 — O que é biodigestor?

**Variantes:** Biodigestor: o que significa? · Me explica o que é biodigestor · oq é biodigestor · biodigestor? · Defina biodigestor

Biodigestor anaeróbico é um equipamento usado para o processamento de matéria orgânica, como, por exemplo, fezes e urina, de humanos. Como método alternativo ao convencional, vem sendo utilizado em vários locais do mundo, como, por exemplo, o Palácio de Cristal no Rio de Janeiro, e em muitos países como tecnologia barata, eficaz e ecológica no tratamento de esgoto humano e animal. É possível instalar biodigestores em condomínios de prédios em capitais para biodigestar toda massa produzida. Existem empresas que fabricam o sistema e já revendem a um preço acessível todo o equipamento pronto e instalado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Biodigestor anaeróbico](https://pt.wikipedia.org/wiki/Biodigestor_anaer%C3%B3bico) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biodigestor anaeróbico" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Agricultura de precisão

### AGTECH-WK-0001 — O que é agricultura de precisão?

**Variantes:** Agricultura de precisão: o que significa? · Me explica o que é agricultura de precisão · oq é agricultura de precisao · agricultura de precisão? · Defina agricultura de precisão

Agricultura de precisão é um tipo de gestão de informação sobre culturas agrícolas, cujo objetivo é melhorar a atividade de produção agrícola e consequentemente a produtividade e sustentabilidade dessa atividade. A agricultura de precisão implica uma gestão das parcelas agrícolas que tem em conta a observação, a medida e a intervenção tendo em conta a variabilidade inter- e intra-cultivos, estando associada à utilização de aparelhagem de tecnologia avançada para avaliar e acompanhar de maneira mais precisa as condições das áreas de atividades agronômicas baseada no princípio da variabilidade do solo e clima.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* EVT-006
*Fontes:* [Wikipédia (pt) – Agricultura de precisão](https://pt.wikipedia.org/wiki/Agricultura_de_precis%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Agricultura de precisão" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0002 — O que é piloto automático?

**Variantes:** Piloto automático: o que significa? · Me explica o que é piloto automático · oq é piloto automatico · piloto automático? · Defina piloto automático

Piloto automático ou giropiloto é um instrumento que automaticamente guia navios, aviões, e mais recentemente, também automóveis. Contém giroscópios que comandam o navio ou avião, controlando as posições vertical e horizontal e mantendo o navio ou avião em determinada rota. O piloto automático permite uma navegação mais precisa e econômica. Um piloto automático está fazendo exatamente o que os pilotos dizem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Piloto automático](https://pt.wikipedia.org/wiki/Piloto_autom%C3%A1tico) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Piloto automático" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0003 — O que são GNSS?

**Variantes:** GNSS: o que significa? · Me explica o que são GNSS · oq sao gnss · GNSS? · Defina GNSS

Navegação por satélite, também chamada de posicionamento por satélite ou satnav, é o uso de satélites artificiais para navegação ou geoposicionamento. Um sistema global de navegação por satélite, ou GNSS, oferece cobertura a qualquer usuário na Terra, no ar, em terra ou no mar. Há quatro sistemas GNSS em operação, o Sistema de Posicionamento Global dos Estados Unidos, ou GPS, o GLONASS da Rússia, o BeiDou da China, ou BDS, e o Galileo da União Europeia. Há também dois sistemas regionais de navegação por satélite, ou RNSS, o Quasi-Zenith Satellite System do Japão, ou QZSS, e o Indian Regional Navigation Satellite System da Índia, ou IRNSS, também chamado de NavIC.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Sistema de navegação por satélite](https://pt.wikipedia.org/wiki/Sistema_de_navega%C3%A7%C3%A3o_por_sat%C3%A9lite) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Sistema de navegação por satélite" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0004 — O que é Sistema de Posicionamento Global?

**Variantes:** Sistema de Posicionamento Global: o que significa? · Me explica o que é Sistema de Posicionamento Global · oq é sistema de posicionamento global · Sistema de Posicionamento Global? · Defina Sistema de Posicionamento Global

O sistema de posicionamento global, ou GPS, do inglês Global Positioning System, é um sistema de navegação hiperbólica por satélite pertencente à Força Espacial dos Estados Unidos e operado pela Mission Delta 31. É um dos sistemas globais de navegação por satélite, conhecidos pela sigla GNSS, que fornecem localização geográfica e informações de tempo a um receptor em qualquer ponto da Terra ou próximo a ela onde a qualidade do sinal permita. O usuário não precisa transmitir dados, e o sistema funciona independentemente da recepção de telefonia ou internet, embora essas tecnologias possam ampliar a utilidade das informações de posicionamento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Sistema de posicionamento global](https://pt.wikipedia.org/wiki/Sistema_de_posicionamento_global) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Sistema de posicionamento global" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0005 — O que é RTK?

**Variantes:** RTK: o que significa? · Me explica o que é RTK · oq é rtk · RTK? · Defina RTK

Real Time Kinematic (RTK) ou Posicionamento Cinemático em Tempo-Real é uma técnica de posicionamento relativo GNSS utilizada por sistemas como GPS, GLONASS, Galileo e outros. A técnica baseia-se na medição de fase da onda portadora dos sinais dos satélites (ao invés das informações transmitidas por estes sinais) e sua correção utilizando dados oriundos de estações de referência. Uma estação de referência é um receptor GNSS fixo que possui sua posição previamente conhecida: esta estação de referência mede as fases das ondas portadoras para os satélites que detecta e envia estas medições ao receptor do usuário utilizando um sistema de telecomunicação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Real Time Kinematic](https://pt.wikipedia.org/wiki/Real_Time_Kinematic) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Real Time Kinematic" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0006 — O que é telemetria?

**Variantes:** Telemetria: o que significa? · Me explica o que é telemetria · oq é telemetria · telemetria? · Defina telemetria

Telemetria é a coleta in situ de medições ou outros dados em pontos remotos e sua transmissão automática para equipamentos receptores (telecomunicações) para monitoramento. A palavra deriva das raízes gregas tele, 'longe', e metron, 'medida'. Sistemas que precisam de instruções e dados externos para operar requerem o equivalente da telemetria: o telecomando.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Telemetria](https://pt.wikipedia.org/wiki/Telemetria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Telemetria" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0008 — O que é imagem multiespectral?

**Variantes:** Imagem multiespectral: o que significa? · Me explica o que é imagem multiespectral · oq é imagem multiespectral · imagem multiespectral? · Defina imagem multiespectral

Uma imagem multiespectral consiste em imagens de um mesmo objeto, tomadas com diferentes comprimentos de ondas eletromagnéticas. Pode ser luz visível, infravermelha, ultravioleta, raio-X ou qualquer outra faixa do espectro. Diversos aparelhos fazem fotos espectrais. Podem ser câmeras comuns de vigilância ou equipamentos de análise para laboratório, para análise espectral.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Imagem multiespectral](https://pt.wikipedia.org/wiki/Imagem_multiespectral) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Imagem multiespectral" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0009 — O que é estação meteorológica?

**Variantes:** Estação meteorológica: o que significa? · Me explica o que é estação meteorológica · oq é estacao meteorologica · estação meteorológica? · Defina estação meteorológica

Uma estação meteorológica é um local onde são recolhidos dados para análise do tempo meteorológico. Encontram-se equipadas com instrumentos (ou sensores eletrónicos) de medição e registro das variáveis meteorológicas/climáticas. Os seus dados são utilizados para a previsão do tempo e para a caracterização do clima, pelo que também podem ser designadas por estações climatológicas. Em nossos dias, por meio de programas de computador, integram-se os dados coletados, permitindo a sua apresentação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Estação meteorológica](https://pt.wikipedia.org/wiki/Esta%C3%A7%C3%A3o_meteorol%C3%B3gica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Estação meteorológica" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0010 — O que é internet das coisas?

**Variantes:** Internet das coisas: o que significa? · Me explica o que é internet das coisas · oq é internet das coisas · internet das coisas? · Defina internet das coisas

Internet das coisas é a infraestrutura de entidades, pessoas, sistemas e recursos de informação interconectados juntamente com serviços que processam e reagem às informações do mundo físico e do mundo virtual. Em outras palavras, a internet das coisas é uma rede de objetos físicos (veículos, prédios e outros dotados de tecnologia embarcada, sensores e conexão com a rede) capaz de reunir e de transmitir dados. É uma extensão da internet atual que possibilita que objetos do dia-a-dia, quaisquer que sejam mas que tenham capacidade computacional e de comunicação, se conectem à Internet.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Internet das coisas](https://pt.wikipedia.org/wiki/Internet_das_coisas) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Internet das coisas" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Pesquisa

### AGTECH-WK-0053 — O que é Embrapa?

**Variantes:** Embrapa: o que significa? · Me explica o que é Embrapa · oq é embrapa · Embrapa? · Defina Embrapa

A Empresa Brasileira de Pesquisa Agropecuária (Embrapa) é uma empresa pública de pesquisa vinculada ao Ministério da Agricultura e Pecuária (Mapa) do Brasil, tem como objetivo o desenvolvimento de tecnologias, conhecimentos e informações técnico-científicas voltadas para a agropecuária brasileira, e missão "Viabilizar soluções de pesquisa, desenvolvimento e inovação para a sustentabilidade da agricultura, em benefício da sociedade brasileira".

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*KB Fenasoja:* EVT-006
*Fontes:* [Wikipédia (pt) – Empresa Brasileira de Pesquisa Agropecuária](https://pt.wikipedia.org/wiki/Empresa_Brasileira_de_Pesquisa_Agropecu%C3%A1ria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Empresa Brasileira de Pesquisa Agropecuária" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0054 — O que é Instituto Agronômico de Campinas?

**Variantes:** Instituto Agronômico de Campinas: o que significa? · Me explica o que é Instituto Agronômico de Campinas · oq é instituto agronomico de campinas · Instituto Agronômico de Campinas? · Defina Instituto Agronômico de Campinas

O Instituto Agronômico de Campinas (IAC), órgão de pesquisa da Agência Paulista de Tecnologia dos Agronegócios, da Secretaria de Agricultura e Abastecimento do Estado de São Paulo, tem sua sede no município de Campinas. Foi fundado em 1887 pelo imperador D. Pedro II sob a denominação de Imperial Estação Agronômica de Campinas. Em 1892, passou para o Governo do Estado de São Paulo, que durante a primeira metade do século XX, fomentou a criação dos institutos científicos, resultando em um marco na história do estado, devido ao seu papel inovador e às suas ligações com o desenvolvimento industrial e econômico.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Instituto Agronômico de Campinas](https://pt.wikipedia.org/wiki/Instituto_Agron%C3%B4mico_de_Campinas) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Instituto Agronômico de Campinas" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0055 — O que é Escola Superior de Agricultura Luiz de Queiroz?

**Variantes:** Escola Superior de Agricultura Luiz de Queiroz: o que significa? · Me explica o que é Escola Superior de Agricultura Luiz de Queiroz · oq é escola superior de agricultura luiz de queiroz · Escola Superior de Agricultura Luiz de Queiroz? · Defina Escola Superior de Agricultura Luiz de Queiroz

Escola Superior de Agricultura "Luiz de Queiroz" (Esalq) é uma unidade da Universidade de São Paulo (USP) voltada ao ensino, pesquisa e extensão universitária nas áreas das ciências agrárias, sociais aplicadas e ambientais, localizada no Campus USP "Luiz de Queiroz" no município de Piracicaba - SP. A Esalq oferece sete cursos de graduação e dezesseis programas de pós-graduação (PPG), um PPG internacional e 2 PPGs interunidades. Os diversos cursos da Esalq abrigam cerca de 2.000 alunos de graduação e 1.100 alunos de pós-graduação.[carece de fontes]? A Esalq iniciou suas atividades em 1901, como resultado dos esforços de Luís Vicente de Sousa Queirós.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Escola Superior de Agricultura Luiz de Queiroz](https://pt.wikipedia.org/wiki/Escola_Superior_de_Agricultura_Luiz_de_Queiroz) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Escola Superior de Agricultura Luiz de Queiroz" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0056 — O que é Universidade Regional do Noroeste do Estado do Rio Grande do Sul?

**Variantes:** Universidade Regional do Noroeste do Estado do Rio Grande do Sul: o que significa? · Me explica o que é Universidade Regional do Noroeste do Estado do Rio Grande do Sul · oq é universidade regional do noroeste do estado do rio grande do sul · Universidade Regional do Noroeste do Estado do Rio Grande do Sul? · Defina Universidade Regional do Noroeste do Estado do Rio Grande do Sul

A Universidade Regional do Noroeste do Estado do Rio Grande do Sul (UNIJUÍ) é uma instituição privada sem fins lucrativos e multicampi, localizada na região Noroeste do Estado do Rio Grande do Sul. A universidade é atualmente administrada pela Fundação de Integração, Desenvolvimento e Educação do Noroeste do Estado (FIDENE). A reitoria localiza-se no município de Ijuí. A instituição é enquadrada no que descreve a lei nº 12.881/2013, tendo acesso a editais e direito à fomento direcionado às instituições públicas, assim como receber recursos orçamentários do poder público para seu desenvolvimento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Wikipédia (pt) – Universidade Regional do Noroeste do Estado do Rio Grande do Sul](https://pt.wikipedia.org/wiki/Universidade_Regional_do_Noroeste_do_Estado_do_Rio_Grande_do_Sul) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Universidade Regional do Noroeste do Estado do Rio Grande do Sul" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0057 — O que é Universidade Federal de Santa Maria?

**Variantes:** Universidade Federal de Santa Maria: o que significa? · Me explica o que é Universidade Federal de Santa Maria · oq é universidade federal de santa maria · Universidade Federal de Santa Maria? · Defina Universidade Federal de Santa Maria

A Universidade Federal de Santa Maria (UFSM) é uma instituição de ensino superior pública e federal brasileira, que fica em Santa Maria, no estado do Rio Grande do Sul. A UFSM tem sua sede na Cidade Universitária Professor José Mariano da Rocha Filho. O campus está localizado no bairro Camobi, km 9, rodovia ERS-509, onde se realiza a maior parte das atividades acadêmicas e administrativas. Existem, no centro da cidade, outras unidades acadêmicas e de atendimento à comunidade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Universidade Federal de Santa Maria](https://pt.wikipedia.org/wiki/Universidade_Federal_de_Santa_Maria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Universidade Federal de Santa Maria" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0058 — O que é Instituto Federal Farroupilha?

**Variantes:** Instituto Federal Farroupilha: o que significa? · Me explica o que é Instituto Federal Farroupilha · oq é instituto federal farroupilha · Instituto Federal Farroupilha? · Defina Instituto Federal Farroupilha

O Instituto Federal de Educação, Ciência e Tecnologia Farroupilha (IFFar) é uma instituição educacional pública federal criada, de acordo com a Lei nº 11.892 de 2008, mediante integração do Centro Federal de Educação Tecnológica de São Vicente do Sul e da Escola Agrotécnica Federal de Alegrete. A instituição integra, juntamente com o Instituto Federal do Rio Grande do Sul, a rede de educação pública federal gaúcha e foca especialmente no oeste do Rio Grande do Sul. Sua reitoria está instalada na Alameda Santiago do Chile, 195, Bairro Nossa Senhora das Dores, Santa Maria.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Instituto Federal Farroupilha](https://pt.wikipedia.org/wiki/Instituto_Federal_Farroupilha) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Instituto Federal Farroupilha" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Drones

### AGTECH-WK-0011 — O que é veículo aéreo não tripulado?

**Variantes:** Veículo aéreo não tripulado: o que significa? · Me explica o que é veículo aéreo não tripulado · oq é veiculo aereo nao tripulado · veículo aéreo não tripulado? · Defina veículo aéreo não tripulado · O que é drone?

Veículo aéreo não tripulado (VANT), também conhecido como drone (termo inglês para "zangão"), é todo e qualquer tipo de aeronave que pode ser controlada nos 3 eixos e que não necessite de pilotos embarcados para ser guiada (DECEA, 2010). Estes tipos de aeronaves podem ser controladas à distância por meios eletrônicos e computacionais. Quando estão sob a supervisão de humanos, são chamadas de aeronave remotamente pilotada (ARP ou RPA). Quando considerado adicionalmente o sistema de controle remoto e acessórios, o conjunto é denominado sistema de aeronave remotamente pilotada (SARP ou RPAS).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Veículo aéreo não tripulado](https://pt.wikipedia.org/wiki/Ve%C3%ADculo_a%C3%A9reo_n%C3%A3o_tripulado) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Veículo aéreo não tripulado" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0012 — O que é Agência Nacional de Aviação Civil?

**Variantes:** Agência Nacional de Aviação Civil: o que significa? · Me explica o que é Agência Nacional de Aviação Civil · oq é agencia nacional de aviacao civil · Agência Nacional de Aviação Civil? · Defina Agência Nacional de Aviação Civil

Agência Nacional de Aviação Civil (ANAC) é uma agência reguladora federal cuja responsabilidade é normatizar e supervisionar a atividade de aviação civil no Brasil, tanto no que toca seus aspectos econômicos quanto no que diz respeito à segurança técnica do setor. A substituição de órgãos diretamente ligados ao governo por uma autarquia, em 2005, visou a uma administração mais autônoma e técnica da aviação civil nacional, buscada por meio de descentralização administrativa e menor influência política direta.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Agência Nacional de Aviação Civil](https://pt.wikipedia.org/wiki/Ag%C3%AAncia_Nacional_de_Avia%C3%A7%C3%A3o_Civil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Agência Nacional de Aviação Civil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### AGTECH-WK-0013 — O que é Departamento de Controle do Espaço Aéreo?

**Variantes:** Departamento de Controle do Espaço Aéreo: o que significa? · Me explica o que é Departamento de Controle do Espaço Aéreo · oq é departamento de controle do espaco aereo · Departamento de Controle do Espaço Aéreo? · Defina Departamento de Controle do Espaço Aéreo

O Departamento de Controle do Espaço Aéreo (DECEA) é uma entidade governamental militar do Comando da Aeronáutica brasileiro, que por sua vez é subordinada ao Ministério da Defesa. Sua missão é gerenciar a operacionalidade dos serviços de tráfego no espaço aéreo de soberania do Brasil, bem como coordenar a sua defesa junto com o Comando de Operações Aeroespaciais (COMAE).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Departamento de Controle do Espaço Aéreo](https://pt.wikipedia.org/wiki/Departamento_de_Controle_do_Espa%C3%A7o_A%C3%A9reo) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Departamento de Controle do Espaço Aéreo" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.
