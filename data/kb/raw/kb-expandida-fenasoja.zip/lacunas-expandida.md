# Lacunas — KB expandida do bot Fenasoja

Gerado em 2026-10-17. Contexto: [kb-expandida.md](kb-expandida.md). Lacunas da KB Fenasoja original: [../lacunas.md](../lacunas.md).

## 1. Resumo honesto

- Meta pedida: ~2.000–2.500 canônicas e ~10 mil perguntas. Resultado real: **2414 canônicas e 10889 perguntas**.
- A distribuição por área é **desequilibrada**: AGRO concentra ~63% das entradas (vinda dos livros da Embrapa). FEIRAS (31), TEC (60) e FAQ (7) ficaram finas, porque havia poucas fontes primárias consultáveis e não completei com conteúdo sem fonte.
- **Wikipédia** (479 entradas, `confirmado` em relação ao verbete): fonte terciária. Serve para conceitos introdutórios, não para dados atuais. Recomenda-se revisão humana amostral.
- **Livros da Embrapa** (1.525 entradas): textos de 1998 a 2019. Conceitos continuam válidos em geral, mas cultivares, produtos, registros de defensivos, preços e estatísticas podem estar desatualizados. Itens com números viraram `dado`/`parcial` com aviso.
- **Variantes** dos livros, IBGE e Wikipédia são geradas por regra (coloquial, curta, sem acento/erro). Elas são úteis para busca trigram, mas não são linguagem natural de usuários reais. Recomenda-se coletar perguntas reais dos logs do bot e incluí-las como variantes.
- Respostas dos livros são **recortes literais** (até 5 frases), às vezes terminando antes do fim da resposta original. Em 734 perguntas sem o tema explícito, foi adicionado um prefixo de contexto (ex.: "Milho: como controlar os enfezamentos?").
- 6 entradas foram removidas por pergunta canônica duplicada (registro em `kb-expandida.json > meta`).
- Nenhum `conflito` foi registrado nesta versão. Isso não prova ausência de divergências: livros antigos e IBGE recente podem divergir em números.

## 2. Temas pedidos e sem cobertura (ou com cobertura fraca)

| Tema | Situação | Próximo passo sugerido |
|---|---|---|
| Calendário de plantio/colheita RS/BR | Página da Conab deu 404; não há entrada fixa. ZARC e livros cobrem só em parte. | Buscar o calendário agrícola da Conab (novo endereço) ou boletins da Emater/RS. |
| CBOT/B3: conceitos de contrato, vencimentos, bushel | CME bloqueou (403); página da B3 veio quase vazia (244 caracteres). Só há entradas de conceito via Wikipédia e entradas dinâmicas. | Consultar manuais da B3 (PDF) e material educacional do CEPEA. |
| Logística e portos (Rio Grande, Paranaguá, ferrovias) | Só conceitos gerais da Wikipédia. | Antaq, Portos RS, Conab (logística). |
| Seguro rural: Proagro, PSR, percentuais | Só a lei do PSR e a relação com o ZARC. Regras de obrigatoriedade estão como `parcial`. | MAPA (PSR), BCB (Proagro/MCR); as páginas do BCB vieram vazias (renderização JS). |
| Manual de Crédito Rural, Selic, câmbio | Páginas HTML do BCB vieram vazias; só as APIs SGS (usadas como fonte dinâmica). | Usar as APIs SGS ao vivo; PDF do MCR. |
| Hortitec, AgroBrasília (ano dos números) | Hortitec não respondeu; AgroBrasília sem ano (`parcial`). | Tentar de novo; confirmar o ano no site. |
| Dicas para expositores | Só "como ser expositor na Fenasoja" (KB Fenasoja). As páginas do Sebrae sobre feiras vieram vazias. | Guia do Sebrae para expositores (PDF). |
| FAQ do visitante | Quase tudo já está na KB Fenasoja (prioridade 1). Regras sobre pets, comida/bebida e achados e perdidos: `sem_fonte`. | Pedir à organização e publicar no site. |
| LGPD (ANPD), CAR (gov.br), bioinsumos, agricultura de precisão e plantio direto (temas Embrapa) | As páginas deram 401/404. Usadas as leis (Planalto) e os livros. | Tentar URLs novas. |
| Cooperativas da região (Cotrirosa etc.), indústria metalmecânica de Santa Rosa | Não pesquisado nesta rodada. | Sites oficiais das cooperativas, FEE/DEE-RS. |
| Dados de safra RS atuais (Emater) e PIB do agro | Não incluídos como fixos; tratados como dinâmicos via Conab. | Informativo Conjuntural da Emater (semanal). |

## 3. Fontes tentadas que falharam ou vieram vazias (não citadas)

| chave | HTTP | caracteres | URL |
|---|---|---|---|
| bcbcambio | 200 | 25 | https://www.bcb.gov.br/estabilidadefinanceira/historicocotacoes |
| bcbmcr | 200 | 25 | https://www.bcb.gov.br/estabilidadefinanceira/creditorural |
| bcbcopom | 200 | 25 | https://www.bcb.gov.br/controleinflacao/copom |
| bcbselic | 200 | 25 | https://www.bcb.gov.br/controleinflacao/taxaselic |
| cmesoy | 403 | 600 | https://www.cmegroup.com/markets/agriculture/oilseeds/soybean.html |
| hortitec | 000 | 0 | https://www.hortitec.com.br/ |
| conab | 000 | 0 | https://www.conab.gov.br/ |
| comexstat | 200 | 1 | https://comexstat.mdic.gov.br/ |
| psafra_af_incra | 401 | 182 | https://www.gov.br/incra/pt-br/assuntos/noticias/plano-safra-da-agricultura-familiar-2025-26-tera-investimento-de-r-89-bilhoes |
| bioins_emb | 404 | 869 | https://www.embrapa.br/tema-bioinsumos/sobre-o-tema |
| spd | 404 | 346 | https://www.embrapa.br/agencia-de-informacao-tecnologica/tematicas/agricultura-e-meio-ambiente/qualidade/dinamica/sistema-plantio-direto |
| agprec | 404 | 882 | https://www.embrapa.br/tema-agricultura-de-precisao/sobre-o-tema |
| car_gov | 404 | 26 | https://www.gov.br/servicosflorestais/pt-br/assuntos/cadastro-ambiental-rural |
| bcb_pix | 200 | 25 | https://www.bcb.gov.br/estabilidadefinanceira/pix |
| anpd_lgpd | 401 | 182 | https://www.gov.br/anpd/pt-br/acesso-a-informacao/perguntas-frequentes-2013-anpd |
| bcb_mcr | 200 | 1 | https://www3.bcb.gov.br/mcr |
| bcb_selic_api | 200 | 39 | https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json |
| bcb_ptax_api | 200 | 40 | https://api.bcb.gov.br/dados/serie/bcdata.sgs.1/dados/ultimos/1?formato=json |
| inmet_prev | 200 | 17 | https://previsao.inmet.gov.br/ |
| conab_cal | 404 | 26 | https://www.gov.br/conab/pt-br/atuacao/informacoes-agropecuarias/safras/calendario-agricola-plantio-e-colheita |
| fee_rs | 404 | 968 | https://www.estado.rs.gov.br/economia |

Obs.: `bcb_selic_api` e `bcb_ptax_api` retornam JSON curto válido. Elas são citadas só nas entradas dinâmicas, como endpoint para consulta ao vivo, e não como valor fixo.

## 4. Livros da Embrapa por ano (desatualização potencial)

| Livro | Ano | Entradas |
|---|---|---|
| Sistema plantio direto: o produtor pergunta, a Embrapa responde | 1998 | 130 |
| Suínos: o produtor pergunta, a Embrapa responde | 1998 | 50 |
| Ovinos: o produtor pergunta, a Embrapa responde | 2007 | 40 |
| Produção orgânica de hortaliças: o produtor pergunta, a Embrapa responde | 2007 | 25 |
| Hortas: o produtor pergunta, a Embrapa responde | 2009 | 15 |
| Milho: o produtor pergunta, a Embrapa responde | 2011 | 220 |
| Gado de corte: o produtor pergunta, a Embrapa responde | 2011 | 120 |
| Gado de leite: o produtor pergunta, a Embrapa responde | 2012 | 160 |
| Arroz: o produtor pergunta, a Embrapa responde | 2013 | 50 |
| Feijão: o produtor pergunta, a Embrapa responde | 2014 | 40 |
| Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde | 2014 | 130 |
| Sorgo: o produtor pergunta, a Embrapa responde | 2015 | 30 |
| Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde | 2015 | 140 |
| Soja: o produtor pergunta, a Embrapa responde | 2019 | 300 |
| Pêssego, nectarina e ameixa: o produtor pergunta, a Embrapa responde | 2019 | 15 |
| Recursos genéticos: o produtor pergunta, a Embrapa responde | 2019 | 60 |

## 5. Entradas `parcial`, `sem_fonte` e `dinâmico`

| id | status | pergunta | lacuna / nota |
|---|---|---|---|
| AGRO-SOJ-0004 | parcial | Quando e por que o cultivo da soja deslanchou no mundo? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0009 | parcial | Como evoluiu o plantio e a produção de soja no Brasil? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0010 | parcial | Como pode ser dividido o avanço da soja pelo território brasileiro? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0161 | parcial | Quais são os nutrientes mais absorvidos pela soja e acumulados nos grãos? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0162 | parcial | Soja: qual é a diferença entre adubação corretiva e adubação de manutenção? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0163 | parcial | Quais são os nutrientes mais utilizados na adubação da soja? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0168 | parcial | Qual é a recomendação de adubação com cobalto e molibdênio para a soja? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0172 | parcial | Quais são as vantagens no manejo da adubação dos sistemas de sucessão de culturas com a soja? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0181 | parcial | O que é o inoculante para FBN em soja? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0200 | parcial | Quais são os benefícios da cultura do trigo no sistema de produção de soja? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0329 | parcial | Quais são os fungicidas usados para controlar a ferrugem-asiática da soja? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0472 | parcial | Qual é a importância da soja entre as grandes explorações agrícolas mundiais? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0477 | parcial | Por que a Argentina, sendo apenas o terceiro produtor de soja, é o primeiro exportador de farelo e de óleo? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0483 | parcial | Por que é fácil vender soja no mercado mundial? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0493 | parcial | Como é consumida a soja que o Brasil produz? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-SOJ-0500 | parcial | Quais são os impactos ambientais da produção de soja? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-MIL-0482 | parcial | Qual a importância do milho entre as grandes explorações agrícolas mundiais? | Atualizar estatísticas de 2011 com fonte recente (IBGE/Conab) |
| AGRO-MIL-0489 | parcial | Quais são as regiões de maior produtividade na cultura do milho, no Brasil? | Atualizar estatísticas de 2011 com fonte recente (IBGE/Conab) |
| AGRO-MIL-0494 | parcial | Por que o Brasil importa milho se tem excedente exportável? | Atualizar estatísticas de 2011 com fonte recente (IBGE/Conab) |
| AGRO-MIL-0497 | parcial | Qual a participação dos diferentes segmentos da cadeia produtiva do milho no consumo do cereal, no Brasil? | Atualizar estatísticas de 2011 com fonte recente (IBGE/Conab) |
| AGRO-SPD-0008 | parcial | Quando e em que região surgiu o Sistema Plantio Direto? | Resposta resumida do item nº 8 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar consu |
| AGRO-SPD-0043 | parcial | Qual a importância de treinamento de todos os funcionários envolvidos na execução do SPD? | Resposta resumida do item nº 43 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar cons |
| AGRO-SPD-0085 | parcial | Plantio direto: quando se deve optar pelo manejo mecânico das culturas ou da palha? | Resposta resumida do item nº 85 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com agr |
| AGRO-SPD-0086 | parcial | Plantio direto: qual a melhor opção de manejo do nabo-forrageiro e qual o momento adequado? | Resposta resumida do item nº 86 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com agr |
| AGRO-SPD-0116 | parcial | Como conduzir o SPD, se os restos culturais do algodoeiro devem ser destruídos? | Resposta resumida do item nº 116 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0162 | parcial | Plantio direto: qual o melhor veículo para o inoculante? | Resposta resumida do item nº 162 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0312 | parcial | Quais as máquinas e implementos imprescindíveis para adoção do SPD? | Resposta resumida do item nº 312 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0369 | parcial | Plantio direto: qual a estratégia para controlar o capim-amargoso (Digitaria insularis)? | Resposta resumida do item nº 369 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0371 | parcial | Plantio direto: como se controla a erva-quente (Espermacoce latifolia)? | Resposta resumida do item nº 371 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0372 | parcial | Plantio direto: qual a estratégia de controle da trapoeraba (Commelina benghalensis)? | Resposta resumida do item nº 372 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0373 | parcial | Plantio direto: como controlar o colonião (Panicum maximum L.)? | Resposta resumida do item nº 373 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com ag |
| AGRO-SPD-0393 | parcial | Plantio direto: qual o potencial de dano do percevejo-castanho? | Resposta resumida do item nº 393 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0401 | parcial | Plantio direto: como controlar o tamanduá-da-soja? | Resposta resumida do item nº 401 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com ag |
| AGRO-SPD-0410 | parcial | Plantio direto: como controlar os grilos? | Resposta resumida do item nº 410 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com ag |
| AGRO-SPD-0420 | parcial | Quais as recomendações para o uso de fungicidas na parte aérea das culturas do trigo e da soja, no SPD? | Resposta resumida do item nº 420 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com ag |
| AGRO-SPD-0423 | parcial | Quais os fungicidas recomendados para o tratamento de sementes de soja, milho, algodão e de cereais de inverno (trigo, aveia e cevada), no SPD? | Resposta resumida do item nº 423 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SPD-0427 | parcial | Quais as recomendações para o uso de fungicidas na parte aérea da soja, no SPD? | Resposta resumida do item nº 427 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com ag |
| AGRO-SPD-0434 | parcial | Plantio direto: como deve ser a cobertura da pastagem para se realizar a dessecação e posterior semeadura da soja? | Resposta resumida do item nº 434 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Orientação técnica geral: recomendar confirmar com ag |
| AGRO-SPD-0462 | parcial | Plantio direto: quais pastagens perenes são adequadas para fazer parte da rotação com a lavoura? | Resposta resumida do item nº 462 do livro da Embrapa "Sistema plantio direto: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar con |
| AGRO-SUI-0377 | parcial | Suínos: quais as raças mais criadas no Brasil? Por quê? | Resposta resumida do item nº 377 do livro da Embrapa "Suínos: o produtor pergunta, a Embrapa responde" (1998). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit |
| AGRO-SUI-0389 | parcial | Suínos: qual é o peso ideal para abate? | Atualizar estatísticas de 1998 com fonte recente (IBGE/Conab) |
| AGRO-SUI-0500 | parcial | Suínos: quais as alternativas para reduzir o custo de produção? | Atualizar estatísticas de 1998 com fonte recente (IBGE/Conab) |
| AGRO-SOR-0499 | parcial | Qual é a rentabilidade do sorgo em comparação à do milho de inverno? | Atualizar estatísticas de 2015 com fonte recente (IBGE/Conab) |
| AGRO-PES-0439 | parcial | Quais são os principais estados produtores de pêssego, ameixa e nectarina no Brasil? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-PES-0440 | parcial | Quais são os principais municípios produtores de pêssego, ameixa e nectarina no Brasil? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-PES-0459 | parcial | Qual é a importância socioeconômica do cultivo de pessegueiro, ameixeira e nectarineira no Rio Grande do Sul? | Atualizar estatísticas de 2019 com fonte recente (IBGE/Conab) |
| AGRO-ORG-0219 | parcial | Produção orgânica: onde os inimigos naturais podem ser encontrados? | Resposta resumida do item nº 219 do livro da Embrapa "Produção orgânica de hortaliças: o produtor pergunta, a Embrapa responde" (2007). Produtos e registros de defensivos mudam: in |
| AGRO-ORG-0466 | parcial | Produção orgânica: quais as principais características do processo de modernização da agricultura brasileira? | Resposta resumida do item nº 466 do livro da Embrapa "Produção orgânica de hortaliças: o produtor pergunta, a Embrapa responde" (2007). Produtos e registros de defensivos mudam: in |
| AGRO-HOR-0351 | parcial | Hortas: como saber se uma planta está doente? | Resposta resumida do item nº 351 do livro da Embrapa "Hortas: o produtor pergunta, a Embrapa responde" (2009). Orientação técnica geral: recomendar confirmar com agrônomo, veteriná |
| AGRO-FBN-002 | parcial | Quanto custa inocular a soja? | Data do levantamento de custo não informada. |
| AGRO-ENSO-003 | dinâmico | Estamos em ano de El Niño? | Consultar o ENSO Diagnostic Discussion mais recente (NOAA CPC, publicado na 2ª quinta-feira de cada mês) e boletins do INMET/CPTEC; citar data. |
| AGRO-DYN-001 | dinâmico | Como está a previsão do tempo para Santa Rosa? | Consultar INMET (portal.inmet.gov.br / API de previsão) ou CPTEC ao vivo; informar data/hora; para alertas, citar o aviso vigente. |
| FEIRAS-SRC-001 | parcial | O que é o Show Rural Coopavel? | Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição. A cidade (Cascavel) não foi confirmada no texto e |
| FEIRAS-ABR-001 | parcial | O que é a AgroBrasília? | Ano dos números da AgroBrasília não identificado. |
| FEIRAS-GER-001 | parcial | Quais são as principais feiras do agronegócio no Rio Grande do Sul? | Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição. "Perfil" de cada feira é síntese editorial a part |
| TEC-LGPD-005 | parcial | Qual a multa da LGPD? | Lei consultada no Planalto em 17/10/2026. Não é aconselhamento jurídico. Sanções além da multa citadas de forma resumida; conferir o art. 52. |
| MERC-SEG-002 | parcial | Qual a relação entre o Zarc e o seguro rural ou Proagro? | A fonte não detalha as regras de obrigatoriedade; tratar como parcial. |
| MERC-DYN-001 | dinâmico | Qual o preço da soja hoje? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Fontes: CEPEA (indicado |
| MERC-DYN-002 | dinâmico | Qual o preço do milho hoje? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. |
| MERC-DYN-003 | dinâmico | Qual o preço do trigo hoje? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. |
| MERC-DYN-004 | dinâmico | Qual o preço do boi gordo hoje? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. |
| MERC-DYN-005 | dinâmico | Quanto está o preço do leite pago ao produtor? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. |
| MERC-DYN-006 | dinâmico | Quanto está a soja na Bolsa de Chicago? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Fonte primária: CME Gro |
| MERC-DYN-007 | dinâmico | Quanto está o dólar hoje? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Endpoint: https://api.b |
| MERC-DYN-008 | dinâmico | Qual é a taxa Selic atual? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. Endpoint: https://api.b |
| MERC-DYN-009 | dinâmico | Qual a estimativa da safra de grãos atual da Conab? | Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar. |
| SUST-ILPF-0468 | parcial | Quais são as linhas de crédito disponíveis para o produtor rural financiar a implantação do sistema de integração? | Atualizar estatísticas de 2015 com fonte recente (IBGE/Conab) |
| SUST-ILPF-0469 | parcial | Quais são os itens financiáveis e as condições para acessar linhas de créditos que financiam projetos de ILP e de ILPF? | Atualizar estatísticas de 2015 com fonte recente (IBGE/Conab) |
| SUST-LEG-010 | parcial | O que fazer com as embalagens vazias de agrotóxicos? | Prazo de devolução e endereço de postos de recebimento na região de Santa Rosa não confirmados. |
| SUST-LEG-014 | parcial | O que é uma biofábrica? | Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou p |
| SUST-LEG-015 | parcial | Posso guardar semente de cultivar protegida para plantar de novo? | Lei 10.711/2003 (sementes e mudas) não consultada. |
| SUST-LEG-017 | parcial | Quais são os fundamentos da Lei das Águas? | Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou p |
| RS-INS-001 | parcial | O que é a Emater/RS-Ascar? | Descrição resumida a partir do portal; detalhes institucionais (natureza jurídica, número de escritórios) não extraídos. |
| RS-INS-002 | parcial | O que é a Seapi? | Atribuições detalhadas (defesa agropecuária etc.) não extraídas; confirmar na página da Seapi. |
| FAQ-SF-001 | sem_fonte | Posso levar meu cachorro na Fenasoja? | Regra de pets no parque não localizada. |
| FAQ-SF-002 | sem_fonte | Onde fica o achados e perdidos da Fenasoja? | Local de achados e perdidos não localizado. |
| FAQ-SF-003 | sem_fonte | Posso levar comida e bebida para a Fenasoja? | Regra sobre alimentos/bebidas não localizada. |