# KB expandida — Sustentabilidade (SUST)

Gerado em 2026-10-17. Índice geral: [../kb-expandida.md](../kb-expandida.md). JSON da área: [sustentabilidade.json](sustentabilidade.json).

**212 perguntas canônicas · 959 perguntas no total (canônicas + variantes).**

| confirmado | parcial | sem_fonte | conflito | dinâmico |
|---|---|---|---|---|
| 206 | 6 | 0 | 0 | 0 |

| conceito | dado | orientação |
|---|---|---|
| 197 | 5 | 10 |

**Por tipo de fonte:** Embrapa – Coleção 500 Perguntas 500 Respostas: 140; Curadoria manual sobre fontes oficiais: 21; Wikipédia (pt) – verbete: 51

## Subcategorias

| Subcategoria | Entradas |
|---|---|
| Integração lavoura-pecuária-floresta (ILPF) | 140 |
| ESG e carbono | 28 |
| Legislação ambiental | 14 |
| Agricultura de baixo carbono | 11 |
| Código Florestal | 6 |
| Clima e carbono | 2 |
| Resíduos e embalagens | 2 |
| Defensivos | 2 |
| Bioinsumos | 2 |
| Sementes e biotecnologia | 2 |
| Plano ABC+ | 2 |
| Água | 1 |

## Entradas

## Integração lavoura-pecuária-floresta (ILPF)

### SUST-ILPF-0001 — O que é integração lavoura-pecuária-floresta (ILPF)?

**Variantes:** Me explica uma coisa: o que é integração lavoura-pecuária-floresta (ILPF)? · integração lavoura-pecuária-floresta ilpf? · o q e integraao lavoura-pecuaria-floresta (ilpf)

É um sistema de produção sustentável que integra atividades agrícolas, pecuárias e florestais, realizadas na mesma área, em cultivo consorciado, em sucessão ou em rotação, e busca efeitos sinérgicos entre os componentes do agroecossistema, contemplando a adequação ambiental, a valorização do homem e a viabilidade econômica da atividade agropecuária.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 1](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 1 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0002 — Quais são as modalidades ou categorias do sistema de ILPF?

**Variantes:** Alguém me explica: quais são as modalidades ou categorias do sistema de ILPF? · modalidades categorias sistema ilpf? · quais sao as modalidaes ou categorias do sistema de ilpf

O sistema de ILPF pode ser classificado em quatro modalidades: • Integração lavoura-pecuária (ILP) ou sistema agropastoril. • Integração pecuária-floresta (IPF) ou sistema silvipastoril. • Integração lavoura-floresta (ILF) ou sistema silviagrícola. • Integração lavoura-pecuária-floresta (ILPF) ou sistema agrossilvipastoril. As categorias são uma forma alternativa de classificação e podem ser divididas em: • Sistemas de integração sem componente florestal (ou seja, ILP). • Sistemas de integração com componente florestal (ou seja, IPF, ILF e ILPF).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 2](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 2 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0003 — O que é integração lavoura-pecuária (ILP) ou sistema agropastoril?

**Variantes:** Alguém me explica: o que é integração lavoura-pecuária (ILP) ou sistema agropastoril? · integração lavoura-pecuária ilp sistema agropastoril? · o q e integraao lavoura-pecuaria (ilp) ou sistema agropastoril

É o sistema de produção que integra os componentes agrícola e pecuário, em rotação, consórcio ou sucessão, na mesma área e no mesmo ano agrícola ou por múltiplos anos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 3](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 3 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0004 — O que é integração pecuária-floresta (IPF) ou sistema silvipastoril?

**Variantes:** Tu sabe me dizer: o que é integração pecuária-floresta (IPF) ou sistema silvipastoril? · integração pecuária-floresta ipf sistema silvipastoril? · o q e integracao pecuaria-floresta (ipf) ou sistema silvipastoil

É o sistema de produção que integra os componentes pecuário (pastagem e animal) e florestal, em consórcio.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 4](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 4 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0005 — O que é integração lavoura-floresta (ILF) ou sistema silviagrícola?

**Variantes:** Me explica uma coisa: o que é integração lavoura-floresta (ILF) ou sistema silviagrícola? · integração lavoura-floresta ilf sistema silviagrícola? · o q e integraao lavoura-floresta (ilf) ou sistema silviagricola

É o sistema de produção que integra os componentes florestal e agrícola pela consorciação de espécies arbóreas e agrícolas perenes ou a consorciação de espécies arbóreas e agrícolas (anuais) em rotação e/ou sucessão.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 5](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 5 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0006 — O que é integração lavoura-pecuária-floresta (ILPF) ou sistema agrossilvipastoril?

**Variantes:** Tu sabe me dizer: o que é integração lavoura-pecuária-floresta (ILPF) ou sistema agrossilvipastoril? · integração lavoura-pecuária-floresta ilpf sistema agrossilvipastoril? · o q e integracao lavoura-pecuaria-floresta (ilpf) ou sistema agrossilvipastoil

É o sistema de produção que integra os componentes agrícola e pecuário, em rotação, consórcio ou sucessão, na mesma área e no mesmo ano agrícola ou por múltiplos anos, em consórcio com o componente florestal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 6](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 6 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0007 — ILPF: qual é o significado dos termos consórcio, sucessão e rotação de culturas?

**Variantes:** Bah, uma dúvida: qual é o significado dos termos consórcio, sucessão e rotação de culturas (ilpf)? · significado termos consórcio sucessão rotação culturas (ilpf)? · qual e o significdo dos termos consorcio, sucessao e rotacao de culturas (ilpf)

O consórcio é um sistema de cultivo no qual duas ou mais espécies vegetais são cultivadas na mesma área simultaneamente. A sucessão de cultivos ocorre quando diferentes espécies vegetais são semeadas, uma após a colheita da outra, dentro do mesmo ano agrícola, tendo como exemplo para a região central do Brasil a sucessão soja-milho safrinha. A rotação ocorre quando há alternância de espécies vegetais, ocupando o mesmo espaço físico e período do ano, dentro de princípios técnicos, visando principalmente sanar problemas fitossanitários.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 7](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 7 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0011 — Qual é a diferença entre o sistema agropastoril (ou ILP) e o sistema agrossilvipastoril (ou ILPF)?

**Variantes:** Me tira uma dúvida: qual é a diferença entre o sistema agropastoril (ou ILP) e o sistema agrossilvipastoril (ou ILPF)? · diferença sistema agropastoril ilp sistema agrossilvipastoril ilpf? · qual e a diferenca entre o sistema agropastoril (ou ilp) e o sistema agrossilvipastoil (ou ilpf)

Ambos os sistemas promovem a integração de atividades. Entretanto, o sistema agropastoril (ou ILP) não contempla o componente florestal, enquanto o sistema agrossilvipastoril (ou ILPF) e os outros sistemas de integração (IPF e ILF) caracterizam-se pela presença desse componente. Os sistemas de integração com componente florestal são baseados no arranjo espacial de aleias (em inglês, alley cropping), em que as árvores são plantadas em faixas ou renques de linhas simples ou linhas múltiplas com espaçamentos amplos, e o cultivo de culturas anuais e/ou espécies forrageiras ocorre nos espaços entre as linhas de árvores (ou seja, nas aleias).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 11](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 11 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0012 — Quais são os princípios que regem todos os sistemas de integração?

**Variantes:** Bah, uma dúvida: quais são os princípios que regem todos os sistemas de integração? · princípios regem todos sistemas integração? · quais sao os principios q regem todos os sistemas de integraao

Os princípios são os seguintes: • Diversificação das atividades de produção rural. • Ocorrência e proveito de efeitos sinérgicos decorrentes das atividades de produção rural desenvolvidas na mesma área ao longo do tempo. • Aumento da viabilidade econômica e da sustentabilidade ambiental de propriedades rurais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*KB Fenasoja:* EVT-006
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 12](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 12 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0014 — ILPF: o que é agrossilvicultura?

**Variantes:** Tchê, me ajuda: o que é agrossilvicultura (ilpf)? · agrossilvicultura (ilpf)? · o q e agrossilvicultra (ilpf)

Existe, atualmente, na literatura uma grande variedade de termos que são empregados para denominar e conceituar a prática de combinar espécies florestais com culturas agrícolas e/ou com a pecuária. A agrossilvicultura pode ser considerada como a ciência que estuda os SAFs, que, por sua vez, apresentam-se como um conjunto de técnicas alternativas de utilização dos recursos naturais, nos quais espécies florestais são utilizadas em associação a cultivos agrícolas e/ou animais em uma mesma superfície. De uma forma abrangente, a agrossilvicultura se assemelha, conceitualmente, com os sistemas de integração que contêm o componente florestal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 14](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 14 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0019 — Quais são as formas mais comuns do sistema de ILP?

**Variantes:** Bah, uma dúvida: quais são as formas mais comuns do sistema de ILP? · formas comuns sistema ilp? · quais sao as formas mais comuns do sistema de ilp

O sistema de ILP pode ser adotado de diversas formas, com diferentes composições de espécies agrícolas e forrageiras em diferentes arranjos. Entretanto, as formas mais comuns têm as seguintes características: envolvem a consorciação de culturas agrícolas com forrageiras em safra ou safrinha; após a colheita da cultura agrícola, a pastagem tem curta permanência (de 4 meses até, no máximo, 4 anos); com a eliminação sequencial da pastagem, ocorre formação de palhada para o sistema de plantio direto da cultura agrícola subsequente e novo ciclo de rotação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 19](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 19 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0020 — Como o sistema de ILP iniciou no Brasil?

**Variantes:** Bah, uma dúvida: como o sistema de ILP iniciou no Brasil? · sistema ilp iniciou brasil?

Historicamente, nas terras baixas do Sul do País, as áreas de cultivos de arroz irrigado eram também utilizadas para pecuária de corte, em rotação com pastagens. Também na região Sul, áreas de planalto ocupadas com “campos nativos”, com a disponibilidade de herbicidas e semeadoras, foram substituídas por lavouras de soja em plantio direto. No Brasil Central, foi lançado o sistema Barreirão, que é composto por um conjunto de tecnologias e práticas de recuperação de áreas de pastagens em degradação, embasadas no consórcio arroz-pastagem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 20](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 20 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico.

### SUST-ILPF-0021 — Por que os sistemas de ILPF e ILP são classificados como sistemas de produção sustentáveis?

**Variantes:** Me explica uma coisa: por que os sistemas de ILPF e ILP são classificados como sistemas de produção sustentáveis? · sistemas ilpf ilp classificados sistemas produção sustentáveis? · pq os sistemas de ilpf e ilp sao classificados como sisteas de producao sustentaveis

Porque são alternativas para conciliar a produção de alimentos, fibras e energia, aliando viabilidade econômica com sustentabilidade ambiental. A demanda crescente por alimentos, bioenergia e produtos florestais, em contraposição à necessidade de redução de desmatamento e mitigação da emissão de gases de efeito estufa (GEEs), requer soluções que permitam incentivar o desenvolvimento socioeconômico, sem comprometer a sustentabilidade dos recursos naturais. A intensificação do uso da terra em áreas agrícolas e pastoris e o aumento da eficiência dos sistemas de produção podem contribuir para harmonizar esses interesses.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*KB Fenasoja:* EVT-006
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 21](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 21 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0028 — O que são efeitos sinérgicos entre os componentes de sistemas de integração? E como se manifestam?

**Variantes:** Uma pergunta: o que são efeitos sinérgicos entre os componentes de sistemas de integração? E como se manifestam? · efeitos sinérgicos componentes sistemas integração manifestam? · o q sao efeitos sinergicos entre os componenes de sistemas de integracao e como se manifestam

Entende-se por efeito sinérgico o resultado decorrente da ação simultânea dos componentes do sistema de integração. Ou seja, existe interação de fatores sobre o ambiente, e o efeito resultante é maior que a soma dos efeitos de cada um dos componentes utilizados isoladamente – o todo supera a soma das partes. Como exemplo desses efeitos, podemos citar: • Maior qualidade de diferentes gramíneas forrageiras em sistemas com árvores. • Maior tolerância das lavouras aos veranicos. • Maior eficiência de adubos. • Melhoria no desempenho de bovinos criados em pasto, entre outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 28](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 28 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0029 — Quais são os principais benefícios econômicos esperados com a adoção do sistema de ILP?

**Variantes:** Tu sabe me dizer: quais são os principais benefícios econômicos esperados com a adoção do sistema de ILP? · principais benefícios econômicos esperados adoção sistema ilp? · quais sao os principais beneficos economicos esperados com a adocao do sistema de ilp

Os principais benefícios econômicos são: • Maior produtividade das culturas anuais e da pecuária de corte ou de leite. • Redução dos custos de produção com a estabilização do sistema em médio prazo. • Maior estabilidade de renda em razão da diversificação das atividades econômicas. • Redução da vulnerabilidade das lavouras aos riscos climáticos e às oscilações de mercado. Além disso, o produtor também poderá se beneficiar da dinamização de vários setores da economia, principalmente em âmbito regional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 29](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 29 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0031 — Quais são os principais benefícios proporcionados pela utilização de sistemas de ILP ou de ILPF para o produtor?

**Variantes:** Tu sabe me dizer: quais são os principais benefícios proporcionados pela utilização de sistemas de ILP ou de ILPF para o produtor? · principais benefícios proporcionados utilização sistemas ilp ilpf? · quais sao os principais beneficios proporcionados pela utilizaao de sistemas de ilp ou de ilpf pra o produtor

Para o produtor, os benefícios são: • Estabilidade econômica. • Aumento da renda com a diversificação das atividades. • Redução de custos em médio e em longo prazo. • Redução da vulnerabilidade aos riscos climáticos. • Melhoria na qualidade de vida do produtor e de sua família. Além disso, ao adotar sistemas de ILP ou de ILPF, o produtor é beneficiado pelo uso mais eficiente dos seus recursos, como terra, máquinas agrícolas e mão de obra, entre outros. Beneficia-se também em aspectos ambientais, com a melhoria da qualidade do solo e da água, a possibilidade de redução de uso de agrotóxicos, a melhoria do ambiente produtivo para produção animal, entre outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 31](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 31 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico.

### SUST-ILPF-0052 — Quais são as modalidades de sistemas de integração lavoura-pecuária (ILP)?

**Variantes:** Bah, uma dúvida: quais são as modalidades de sistemas de integração lavoura-pecuária (ILP)? · modalidades sistemas integração lavoura-pecuária ilp? · quais sao as modalidades de sisteas de integracao lavoura-pecuaria (ilp)

Basicamente os sistemas de ILP podem ser agrupados em quatro classes e podem sofrer ajustes conforme as condições regionais de clima e de solo. • Consorciação de culturas graníferas e forrageiras: cultivo simultâneo de duas espécies, geralmente uma anual granífera, como milho (Zea mays) ou sorgo (Sorghum bicolor), e uma forrageira, geralmente perene, como as braquiárias (Urochloa spp. syn. Brachiaria spp.). Em alguns casos, o consórcio pode ser também com pastagens anuais, como milheto (Pennisetum glaucum) e sorgo de pastejo (Sorghum sudanense), e forrageiras perenes. Essa modalidade de ILP é possível graças ao diferencial, no tempo e no espaço, de acúmulo de biomassa ao longo do ciclo das espécies.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 52](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 52 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0058 — ILPF: quais são os principais requisitos para iniciar a atividade de lavoura em área de pastagem/pecuária?

**Variantes:** Me explica uma coisa: quais são os principais requisitos para iniciar a atividade de lavoura em área de pastagem/pecuária (ilpf)? · principais requisitos iniciar atividade lavoura área pastagem (ilpf)? · quais sao os principis requisitos pra iniciar a atividade de lavoura em area de pastagem/pecuaria (ilpf)

Com o auxílio da assistência técnica, deve-se planejar todas as etapas, desde a análise das condições das terras para receber o empreendimento, até os investimentos que deverão ser realizados (correção química e física do solo, aquisição de novas máquinas e equipamentos) e a escolha das lavouras nas quais será implantado o sistema no primeiro ano e nos subsequentes. Todas as etapas devem estar bem definidas de tal modo que seja possível maximizar o uso da terra, levando em consideração a sua aptidão agrícola, a diversificação das culturas e o aumento da produtividade, a fim de reduzir os custos de produção, aumentar a renda e conservar o meio ambiente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 58](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 58 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0061 — ILPF: quais são as vantagens e desvantagens da implantação do consórcio milho-braquiária?

**Variantes:** Tu sabe me dizer: quais são as vantagens e desvantagens da implantação do consórcio milho-braquiária (ilpf)? · vantagens desvantagens implantação consórcio milho-braquiária (ilpf)? · quais sao as vantagens e desvantagns da implantacao do consorcio milho-braquiaria (ilpf)

A implantação do consórcio milho-braquiária, também denominado de sistema Santa Fé, demonstra ser uma alternativa interessante para os produtores que desejam recuperar ou reformar pastagens e/ou aumentar a produção de palha no seu sistema produtivo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 61](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 61 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0065 — ILPF: quais são as formas de distribuição das sementes das forrageiras com as culturas anuais?

**Variantes:** Me tira uma dúvida: quais são as formas de distribuição das sementes das forrageiras com as culturas anuais (ilpf)? · formas distribuição sementes forrageiras culturas anuais (ilpf)? · quais sao as formas de distribuicao das sementes das forrageiras com as cultuas anuais (ilpf)

As seguintes formas de distribuir as sementes do capim podem ser consideradas como possibilidades de semeadura: • Plantio da lavoura com a semente da forrageira misturada ao fertilizante e semeada na mesma linha da cultura principal: a mistura deve ocorrer nas horas que antecedem a operação de semeadura para evitar que o contato com o adubo danifique as sementes do capim. O inconveniente é que as faixas entre as linhas de semeadura irão ficar sem o capim, proporcionando um pasto mal formado e com touceiras grandes, o que cria dificuldades operacionais e afeta a qualidade de plantios futuros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 65](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 65 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0066 — Qual é o sistema de manejo do solo recomendado para a adequada implantação do sistema de ILP?

**Variantes:** Me tira uma dúvida: qual é o sistema de manejo do solo recomendado para a adequada implantação do sistema de ILP? · sistema manejo solo recomendado adequada implantação sistema? · qual e o sistema de manejo do solo recomenddo pra a adequada implantacao do sistema de ilp

É desejável adotar o sistema de plantio direto (SPD) desde o início da implantação de sistemas de ILP. Entretanto, nem sempre isso é possível por causa das condições de solo e de degradação em que a área a ser reformada se encontra. Os solos degradados necessitam correções químicas e físicas em profundidade para eliminar impedimentos na subsuperfície. Compactação, deficiência de nutrientes e alumínio são as principais limitações nesses casos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 66](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 66 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0075 — ILPF: como se implanta e se conduz o sistema Santa Brígida?

**Variantes:** Alguém me explica: como se implanta e se conduz o sistema Santa Brígida (ilpf)? · implanta conduz sistema santa brígida (ilpf)? · como se implata e se conduz o sistema santa brigida (ilpf)

A implantação do sistema Santa Brígida segue, basicamente, as premissas dos sistemas de produção convencional de milho, acrescentando-se a espécie leguminosa. Dessecação da área Obedece às recomendações convencionais. Porém deve-se respeitar o fato de, no SPD, a dessecação ser feita por, pelo menos, duas a três semanas antes da semeadura do milho e/ou da leguminosa. Esse procedimento evita que exsudatos com moléculas do dessecante passem da planta-alvo para as raízes das culturas principais. Semeadura e adubação A braquiária pode ser semeada imediatamente antes da cultura do milho, em áreas que não apresentem infestação de plantas daninhas de folha estreita, ou em pós-emergência da cultura do milho.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 75](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 75 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0076 — ILPF: no que se baseia o sistema São Mateus?

**Variantes:** Uma pergunta: no que se baseia o sistema São Mateus (ilpf)? · baseia sistema mateus (ilpf)? · no q se baseia o sistema sao mateus (ilpf)

O sistema São Mateus é indicado para a região do Bolsão Sul-Mato-Grossense, tendo como base a utilização do sistema de ILP com a antecipação da correção química e física do solo e do cultivo de soja em plantio direto para amortizar os custos da recuperação da pastagem. Tal sistema de produção proporciona a diversificação das atividades e dilui os riscos de frustrações, ampliando a rentabilidade e a margem de lucro da propriedade rural.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 76](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 76 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0077 — ILPF: como se implanta o sistema São Mateus?

**Variantes:** Uma pergunta: como se implanta o sistema São Mateus (ilpf)? · implanta sistema mateus (ilpf)? · como se implata o sistema sao mateus (ilpf)

As etapas de implantação do sistema São Mateus são as seguintes: • No período do inverno e da primavera, deve-se realizar a limpeza e adequação da área, o terraceamento, a correção das deficiências químicas do solo com a aplicação de calcário, gesso e adubos, observando-se as recomendações técnicas de aplicação e a correta incorporação ao solo, visando à construção de camada corrigida com 20 cm a 30 cm. • No início do período chuvoso, deve-se implantar pastagem temporária de braquiária (cv. Marandú, BRS Piatã ou Xaraés, por exemplo, com 4 kg/ha a 6 kg/ha de sementes puras viáveis), visando tanto à adequação física do solo pelo desenvolvimento das raízes da forrageira quanto à formação da cobertura de palha…

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 77](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 77 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0081 — Quais são os principais critérios para definir o espaçamento em sistemas de ILPF?

**Variantes:** Tchê, me ajuda: quais são os principais critérios para definir o espaçamento em sistemas de ILPF? · principais critérios definir espaçamento sistemas ilpf? · quais sao os principais criteros pra definir o espacamento em sistemas de ilpf

Os principais critérios são: • Finalidade de produção das árvores. • Declividade e face de exposição do terreno. • Proteção dos demais componentes (cultivos e/ou rebanhos). • Conservação do solo e da água.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 81](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 81 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0082 — Qual é a forma de distribuição espacial do componente florestal em sistemas de ILPF?

**Variantes:** Bah, uma dúvida: qual é a forma de distribuição espacial do componente florestal em sistemas de ILPF? · forma distribuição espacial componente florestal sistemas ilpf? · qual e a forma de distribuicao espacial do componente florestal em sisteas de ilpf

O Brasil possui elevada pluviosidade e alta incidência luminosa durante todo o ano na maioria das regiões. Assim, a distribuição das árvores deverá ser em renques perpendiculares ao sentido pendente ou ao declive do terreno, que é uma forma eficiente de impedir a erosão do solo e a perda de água por escorrimento superficial.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 82](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 82 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0083 — Quais são os principais requisitos para a implantação do componente florestal em sistemas de ILPF?

**Variantes:** Me explica uma coisa: quais são os principais requisitos para a implantação do componente florestal em sistemas de ILPF? · principais requisitos implantação componente florestal sistemas ilpf? · quais sao os principais requisitos pra a implantaao do componente florestal em sistemas de ilpf

• Apresentar boa adaptação à região de cultivo, principalmente no que diz respeito à tolerância à seca (para a região Centro-Oeste) e à geada (para a região Sul). Em algumas localidades, tolerância ao encharcamento do solo. • Gerar produtos com valor de mercado. • Apresentar rápido crescimento (pelo menos 2 m de altura por ano). • Não ser tóxica para os animais nem produzir efeitos de alelopatia com as lavouras. • Deve formar copa alta para proporcionar bons rendimentos de produtos madeireiros e não madeireiros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 83](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 83 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0085 — Quais são os principais passos para a implantação do componente florestal madeireiro em sistemas de ILPF?

**Variantes:** Tu sabe me dizer: quais são os principais passos para a implantação do componente florestal madeireiro em sistemas de ILPF? · principais passos implantação componente florestal madeireiro sistemas? · quais sao os principais passos pra a implantaao do componente florestal madeireiro em sistemas de ilpf

Os principais passos são: • Definir quais são os produtos esperados das árvores (madeira fina para lenha, carvão, celulose, moirões de cerca, ou madeira grossa para serraria, laminação, faqueados).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 85](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 85 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0087 — Qual é a melhor maneira de distribuir as espécies arbóreas na área do sistema de integração com componente florestal?

**Variantes:** Me tira uma dúvida: qual é a melhor maneira de distribuir as espécies arbóreas na área do sistema de integração com componente florestal? · melhor maneira distribuir espécies arbóreas área sistema? · qual e a melhor maneira de distribuir as especies arboreas na area do sistema de integracao com componente floresal

O ideal é utilizar renques de linha simples ou de múltiplas linhas (2, 3, ou mais). Essa forma de distribuição permite o trânsito de máquinas e implementos, além de favorecer o manejo do rebanho e a colheita da madeira. É importante lembrar que a distância entre os renques deve ser calculada para permitir que os implementos transitem sem dificuldades. Por exemplo, é necessário considerar a largura da barra de um pulverizador, a largura da plantadeira, a largura da plataforma da colheitadeira, etc.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 87](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 87 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### SUST-ILPF-0089 — ILPF: qual é o espaçamento ideal para otimizar a produção de madeira e não inviabilizar a pecuária?

**Variantes:** Bah, uma dúvida: qual é o espaçamento ideal para otimizar a produção de madeira e não inviabilizar a pecuária (ilpf)? · espaçamento ideal otimizar produção madeira não inviabilizar (ilpf)? · qual e o espacamento ideal pra otimizar a produao de madeira e n inviabilizar a pecuaria (ilpf)

O espaçamento varia de acordo com os seguintes fatores: espécie arbórea, espécie forrageira e estratégia de implantação e de manejo do sistema (pastejo rotativo, realização de desbastes, etc.). O espaçamento ideal é aquele que não impede o acúmulo de forragem em quantidade e qualidade, ao longo do ciclo do sistema com pecuária, e que proporcione a produção do componente florestal selecionado. A manutenção de um “espaçamento ideal” depende de desbastes e da relação desses com a cobertura de copa das árvores no terreno.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 89](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 89 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0090 — Como selecionar a espécie arbórea para compor o sistema de ILPF?

**Variantes:** Tchê, me ajuda: como selecionar a espécie arbórea para compor o sistema de ILPF? · selecionar espécie arbórea compor sistema ilpf? · como selecioar a especie arborea pra compor o sistema de ilpf

A escolha adequada das espécies arbóreas a serem introduzidas é de grande importância para o sucesso do sistema. As árvores devem ser escolhidas de acordo com os seguintes aspectos: adaptação ao sítio; arquitetura da copa favorável; facilidade de estabelecimento; cumprimento das exigências do mercado para os produtos das árvores; escolha de espécies de rápido crescimento; tipo de raiz das árvores; controle de erosão e escoamento superficial de águas da chuva; sombra para os animais e compatibilidade com pastagens e gado, ou seja, não apresentando efeitos negativos aos animais, como toxicidade ou alelopatia para os demais componentes (cultivo de grãos e pastagens).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 90](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 90 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0094 — Qual é o melhor destino para a madeira produzida em sistemas de ILPF?

**Variantes:** Queria entender: qual é o melhor destino para a madeira produzida em sistemas de ILPF? · melhor destino madeira produzida sistemas ilpf? · qual e o melhor destino pra a madeira produzida em sisteas de ilpf

A madeira produzida no sistema de ILPF pode ter vários destinos, como serraria, laminação, lenha, palanques de cerca, carvão, escoras, celulose, construção civil, entre outros. A melhor destinação será aquela para a qual o sistema foi planejado, que atenda tanto o interesse do produtor rural, no que se refere à receita, aos produtos e/ou serviços, quanto o mercado consumidor local ou regional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 94](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 94 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0105 — Quais são as formas ou modalidades de sistema de integração lavoura-pecuária (ILP) mais adotadas nas regiões Centro-Oeste e Sudeste?

**Variantes:** Queria entender: quais são as formas ou modalidades de sistema de integração lavoura-pecuária (ILP) mais adotadas nas regiões Centro-Oeste e Sudeste? · formas modalidades sistema integração lavoura-pecuária ilp adotadas? · quais sao as formas ou modalidades de sistema de integraao lavoura-pecuaria (ilp) mais adotadas nas regioes centro-oeste e sudeste

Nessas regiões, três modalidades de integração lavoura-pecuária (ILP) se destacam: • Fazendas de pecuária, em que a introdução de culturas de grãos [arroz (Oryza sativa), milho (Zea mays), sorgo (Sorghum bicolor), soja (Glycine max)] em áreas de pastagens tem por objetivo recuperar a produtividade dos pastos. • Fazendas especializadas em lavouras de grãos, que adotam as gramíneas forrageiras para melhorar a cobertura de solo para o sistema de plantio direto (SPD) e, na entressafra, há oportunidade para uso dessa forragem na alimentação de bovinos (boi safrinha ou pasto safrinha). • Fazendas que, sistematicamente, adotam a rotação de pasto e lavoura para intensificar o uso da terra e se beneficiar do sinergismo entre as duas atividades.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 105](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 105 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0107 — Quais são as opções de consórcio de culturas existentes para o sistema de ILP com situação prévia de agricultura, nas regiões Centro-Oeste e Sudeste?

**Variantes:** Tu sabe me dizer: quais são as opções de consórcio de culturas existentes para o sistema de ILP com situação prévia de agricultura, nas regiões Centro-Oeste e Sudeste? · opções consórcio culturas existentes sistema ilp situação? · quais sao as opcoes de consorcio de cultuas existentes pra o sistema de ilp com situacao previa de agricultura, nas regioes centro-oeste e sudeste

É possível consorciar milho ou sorgo com praticamente todas as cultivares de capim disponíveis no mercado. As culturas de milho e de sorgo, em razão da maior capacidade de competição com as gramíneas forrageiras (Urochloa spp., syn. Brachiaria spp. e Panicum maximum) na fase inicial de estabelecimento, têm sido as mais adotadas nos consórcios cultura anual-pasto. O consórcio de culturas de grãos com forrageiras tem por objetivo antecipar o estabelecimento das pastagens em sistemas de ILP e, desse modo, o uso da forrageira para produção de palha para o SPD ou para a alimentação animal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 107](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 107 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0109 — ILPF: o que é e como se implanta o sistema boi safrinha?

**Variantes:** Queria entender: o que é e como se implanta o sistema boi safrinha (ilpf)? · implanta sistema boi safrinha (ilpf)? · o q e e como se implanta o sistema boi safriha (ilpf)

Os termos “boi safrinha” ou “pasto safrinha” referem-se ao uso da forragem produzida em consórcio no verão, com a finalidade de cobertura de solo para o SPD, também para a alimentação de bovinos na estação da seca (inverno). É uma pastagem de curta duração num período em que, normalmen-te, ocorre deficit de forragem. A pastagem pode ser utilizada para cria, recria ou terminação de bovinos, bem como para produção de feno para uso na própria fazenda e/ou comercialização. Com esse sistema, no sudoes-te goiano, por exemplo, alguns pecuaristas têm conseguido realizar uma estação de monta em novilhas durante o mês de agosto.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 109](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 109 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0111 — Qual é a maior contribuição de sistemas de ILP para a realidade edafoclimática das regiões Centro-Oeste e Sudeste?

**Variantes:** Queria entender: qual é a maior contribuição de sistemas de ILP para a realidade edafoclimática das regiões Centro-Oeste e Sudeste? · maior contribuição sistemas ilp realidade edafoclimática regiões? · qual e a maior contribuicao de sistemas de ilp pra a realidade edafoclimatca das regioes centro-oeste e sudeste

A intensificação do uso dos fatores de produção merece destaque. Com esse sistema, é possível manter a área produzindo o ano todo, por exemplo: soja na primeira safra de verão, milho consorciado com uma gramínea forrageira e, depois da colheita, alimentação animal na estação da seca. Com essa diversificação de atividades, há uma redução de risco de produção e financeiro (diluição dos custos), além da possibilidade de manutenção de mão de obra definitiva nas propriedades.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 111](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 111 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0112 — ILPF: quais são os índices de produtividade (agronômica, zootécnica) observados em fazendas consideradas referenciais no sistema boi safrinha?

**Variantes:** Bah, uma dúvida: quais são os índices de produtividade (agronômica, zootécnica) observados em fazendas consideradas referenciais no sistema boi safrinha (ilpf)? · índices produtividade agronômica zootécnica observados fazendas consideradas (ilpf)? · quais sao os indices de produtividade (agronomica, zootecnica) observados em fazenas consideradas referenciais no sistema boi safrinha (ilpf)

Considerando sistemas bem manejados, citam-se como exemplos de impactos positivos do sistema de ILP na modalidade boi safrinha: • Ganhos de produtividade de soja de 10% a 15% quando em sucessão a pastagens de maior produtividade e adubadas. • No sistema de ILP com pastagem de curta duração (apenas na estação da seca), tem-se observado ganho de peso, em equivalente-carcaça, entre 6 arrobas/ha e 12 arrobas/ha. • Ciclagem de nutrientes (a ciclagem de nitrogênio, fósforo e potássio estimada em fazendas do oeste baiano, em equivalente-fertilizante, foi de 60 kg/ha/ano de ureia, 95 kg/ha/ano de superfosfato simples e 85 kg/ha/ano de cloreto de potássio, respectivamente).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 112](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 112 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0124 — Quais são os herbicidas recomendados para supressão do crescimento das braquiárias em consórcio com milho na modalidade de ILP, visando ao estabelecimento do sistema boi safrinha?

**Variantes:** Queria entender: quais são os herbicidas recomendados para supressão do crescimento das braquiárias em consórcio com milho na modalidade de ILP, visando ao estabelecimento do sistema boi safrinha? · herbicidas recomendados supressão crescimento braquiárias consórcio milho? · quais sao os herbicidas recomendados pra supressao do crescimento das braquiarias em consorcio com milho na modalidade de ilp, visando ao estabelecimeto do sistema boi safrinha

Existem vários herbicidas com ação graminicida que podem ser aplicados com o propósito de suprimir o crescimento das gramíneas forrageiras (capins). Os mais estudados pela pesquisa e em uso pelos produtores são: atrazine, nicossulfuron e mesotrione. A aplicação de atrazine, embora possa ser feita em pré-emergência da cultura do milho solteiro, em semeadura simultânea de milho com capim não é recomendada, pois pode afetar a germinação e o estabelecimento da espécie forrageira (capim). A dose desses herbicidas a ser utilizada depende, principalmente, da espécie ou cultivar de forrageira e do estádio de desenvolvimento (número de folhas e perfilhos).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 124](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 124 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico.

### SUST-ILPF-0125 — ILPF: quais são os métodos de semeadura de gramíneas forrageiras para seu estabelecimento em consórcio com milho ou sorgo?

**Variantes:** Uma pergunta: quais são os métodos de semeadura de gramíneas forrageiras para seu estabelecimento em consórcio com milho ou sorgo (ilpf)? · métodos semeadura gramíneas forrageiras estabelecimento consórcio milho (ilpf)? · quais sao os metodos de semeadra de gramineas forrageiras pra seu estabelecimento em consorcio com milho ou sorgo (ilpf)

Existem dois modos de distribuição de sementes de gramíneas forrageiras: em linha e a lanço. A semeadura em linha pode ser feita ainda na mesma linha da cultura anual ou nas entrelinhas. A mistura das sementes da forrageira com o fertilizante, no mesmo dia do plantio, é outra alternativa que foi muito utilizada pelos produtores. Com a expansão do consórcio de forrageiras com milho e sorgo, tem se observado, também, uma evolução na indústria de semeadeiras. Existem atualmente no mercado, várias delas com a terceira caixa acoplada para sementes de forrageiras, que aumenta a eficiência operacional da semeadura simultânea da cultura e das forrageiras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 125](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 125 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0126 — ILPF: qual é a melhor proporção de área para cada componente (lavoura e pastagem) em uma propriedade?

**Variantes:** Bah, uma dúvida: qual é a melhor proporção de área para cada componente (lavoura e pastagem) em uma propriedade (ilpf)? · melhor proporção área cada componente lavoura pastagem (ilpf)? · qual e a melhor proporao de area pra cada componente (lavoura e pastagem) em uma propriedade (ilpf)

Em sistemas de ILP bem manejados e consolidados, a proporção de área de pecuária e produção de grãos, de modo geral, tem sido definida de acordo com a preferência do produtor e com as perspectivas de maiores ganhos (produção e renda). Em fazendas monitoradas pela Embrapa, verificou-se que essa proporção tem sido dinâmica ao longo do tempo. Em uma mesma propriedade a área de pastagem variou de 30% a 70%, e vice-versa para a lavoura. Existem ainda fazendas em que a área de pastagem em rotação com lavoura dentro da propriedade é fixa, normalmente variando de 25% a um terço da propriedade.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 126](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 126 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico. Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0127 — Qual é o melhor arranjo (distribuição) dos componentes lavoura e pastagem em fazendas que desenvolvem o sistema de ILP?

**Variantes:** Me tira uma dúvida: qual é o melhor arranjo (distribuição) dos componentes lavoura e pastagem em fazendas que desenvolvem o sistema de ILP? · melhor arranjo distribuição componentes lavoura pastagem fazendas? · qual e o melhor arranjo (distribuicao) dos componentes lavoura e pastagem em fazendas q desenvolem o sistema de ilp

Nas fazendas de pecuária que evoluíram para o sistema de ILP, a distribuição das áreas com lavoura e pastagem, de modo geral, não obedeceram a nenhum arranjo específico. No entanto, com a evolução do sistema os produtores têm notado que a modulação da área (áreas dos componentes agrupadas em módulos), além de facilitar a rotação lavoura-pasto, simplifica o manejo animal, a construção/remoção de cercas, a locação de bebedouros e, sobretudo, aumenta a eficiência operacional de máquinas e implementos por causa da redução de manobras e da possibilidade de “passadas” mais longas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 127](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 127 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0132 — Quais são as principais dificuldades encontradas na implantação do sistema de ILPF com componente florestal?

**Variantes:** Tu sabe me dizer: quais são as principais dificuldades encontradas na implantação do sistema de ILPF com componente florestal? · principais dificuldades encontradas implantação sistema ilpf componente? · quais sao as principais dificuldades encontradas na implantacao do sistema de ilpf com componente floresal

São várias as dificuldades, entre as quais podemos citar: • Disponibilidade de mão de obra qualificada. • Necessidade de equipamentos e/ou prestadores de serviço específicos para implantação e condução da componente florestal. • Disponibilidade de materiais genéticos comprovadamente de crescimento superior para cada região. • Planejamento e sincronização das atividades de implantação e condução dos componentes agrícola, pecuária e florestal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 132](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 132 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0133 — Quais são os principais arranjos para distribuição espacial do componente florestal em sistemas de ILPF nas regiões Centro-Oeste e Sudeste?

**Variantes:** Me tira uma dúvida: quais são os principais arranjos para distribuição espacial do componente florestal em sistemas de ILPF nas regiões Centro-Oeste e Sudeste? · principais arranjos distribuição espacial componente florestal sistemas? · quais sao os principais arranjos pra distribuicao espacial do componente florestal em sisteas de ilpf nas regioes centro-oeste e sudeste

A adoção da ILPF pode ser facilitada pela adequada distribuição espacial das árvores no terreno, visando às práticas de conservação do solo e água, ao favorecimento do trânsito de máquinas e à observância de aspectos comportamentais dos animais. Para tanto, o arranjo espacial mais simples e eficaz é o de renques (conjunto de linhas), no qual as árvores são plantadas em renques (formados por linhas simples, duplas, triplas, quádruplas, etc.) com espaçamentos amplos. Não é aconselhável a utilização de mais de três linhas de árvores nos renques por causa da dificuldade de manejo dos animais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 133](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 133 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0138 — Quando a desrama das árvores deve ser feita no sistema de ILPF?

**Variantes:** Uma pergunta: quando a desrama das árvores deve ser feita no sistema de ILPF? · desrama árvores feita sistema ilpf? · quando a desrama das arvores deve ser feita no sistema de ilpf

Em monocultivos, é comum realizar a primeira desrama na idade de fechamento do dossel, que ocorre, frequentemente, entre 2 e 4 anos de idade, em espécies de rápido crescimento como o eucalipto. Para sistemas de integração, o momento dessa intervenção pode ser antecipado, uma vez que, ao crescer em espaçamentos amplos, as árvores produzem copas mais densas, com maior quantidade de galhos grossos, havendo a necessidade de sua remoção mais cedo, se o objetivo for reduzir o núcleo nodoso e produzir maior proporção de madeira livre de nós de alta qualidade e de maior valor agregado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 138](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 138 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0140 — Quando o desbaste deve ser feito no sistema de ILPF?

**Variantes:** Uma pergunta: quando o desbaste deve ser feito no sistema de ILPF? · desbaste feito sistema ilpf? · quando o desbate deve ser feito no sistema de ilpf

Se a opção for desbastar, o momento do desbaste e o método e a intensidade a serem aplicados devem ser considerados. O primeiro desbaste pode ser considerado o mais importante tratamento silvicultural aplicado durante a rotação de uma determinada espécie florestal, pois define o curso e a flexibilidade das operações subsequentes e os sortimentos florestais futuros. Devem ser os mais pesados (maior porcentagem de árvores removidas) já que árvores jovens têm maior capacidade de resposta à abertura de espaços criada pelos desbastes. O primeiro desbaste deve ser realizado assim que a copa ou o sistema radicular das árvores comece a interferir no crescimento dos demais componentes do sistema.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 140](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 140 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0141 — Quando se deve colocar o gado na área de ILPF?

**Variantes:** Uma pergunta: quando se deve colocar o gado na área de ILPF? · colocar gado área ilpf? · quando se deve colocar o gado na area de ilpf

Quando as espécies florestais atingirem um tamanho em que não serão prejudicadas pelo gado, em razão da movimentação do rebanho, aproximação das mudas de árvores para coceira, etc. No caso específico de eucalipto, recomenda-se a introdução de gado quando as plantas estiverem com, pelo menos, 6 cm de diâmetro medidos a altura do peito (1,3 m de altura a partir do solo). Além do desenvolvimento da espécie arbórea, a altura do capim também deve ser considerada (ex.: Mombaça – 90 cm, Tanzânia – 70 cm, Marandú – 25 cm, Xaraés – 30 cm).

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 141](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 141 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### SUST-ILPF-0148 — ILPF: quando o gado deve entrar no sistema de IPF com teca no Estado de Mato Grosso antes da entrada dos animais?

**Variantes:** Alguém me explica: quando o gado deve entrar no sistema de IPF com teca no Estado de Mato Grosso antes da entrada dos animais (ilpf)? · gado entrar sistema ipf teca estado mato (ilpf)? · quando o gado deve entrar no sistema de ipf com teca no estado de mato grosso antes da entrada dos animais (ilpf)

A expectativa de entrada dos animais dentro do sistema é de 6 meses a 1 ano depois da sua implantação, quando a maioria das árvores estiver com 3 m de altura. Antes do plantio, é feito um rebaixamento do pasto por meio de uma maior pressão de pastejo (maior lotação de animal). Após o plantio das árvores de teca, a pastagem é vedada por 6 meses a 1 ano, dependendo do crescimento das árvores e da disponibilidade de forrageira. É possível entrar com animais jovens já aos 6 meses após o plantio das árvores. A entrada de animais adultos só deve ocorrer após 1 ano do plantio das árvores.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 148](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 148 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0154 — ILPF: quais são os principais cuidados a serem tomados durante o manejo mecanizado de lavouras graníferas (soja, milho, milheto, etc.) para não prejudicar as seringueiras?

**Variantes:** Tu sabe me dizer: quais são os principais cuidados a serem tomados durante o manejo mecanizado de lavouras graníferas (soja, milho, milheto, etc.) para não prejudicar as seringueiras (ilpf)? · principais cuidados serem tomados durante manejo mecanizado (ilpf)? · quais sao os principais cuidados a serem tomados durante o manejo mecanizado de lavouras graniferas (soja, milho, milheto, etc.) pra n prejudicar as seringueias (ilpf)

O primeiro cuidado é plantar mudas de seringueira (estacas) de saquinho, de tamanho adequado e uniforme, sadias e vigorosas, em áreas de lavoura com solo corrigido, cultivado em SPD e com boa palhada de cobertura, no final do período chuvoso (abril e maio para o Centro-Oeste e o Sudeste brasileiro). Com uma irrigação adequada (utilizando tanque-pipa, preferencialmente) no período da seca, as mudas estarão “pegas” e bem desenvolvidas por ocasião da semeadura (em SPD) da lavoura granífera, no começo do período chuvoso do ano agrícola seguinte.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 154](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 154 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0156 — Quais são as principais modalidades de sistema de integração lavoura-pecuária (ILP) e de integração lavoura-pecuária-floresta (ILPF) na região Sul do Brasil?

**Variantes:** Bah, uma dúvida: quais são as principais modalidades de sistema de integração lavoura-pecuária (ILP) e de integração lavoura-pecuária-floresta (ILPF) na região Sul do Brasil? · principais modalidades sistema integração lavoura-pecuária ilp integração? · quais sao as principais modalidades de sistema de integraao lavoura-pecuaria (ilp) e de integracao lavoura-pecuaria-floresta (ilpf) na regiao sul do brasil

Na região Sul do Brasil, a modalidade mais importante é a ILP com pastagens anuais de inverno para produção de carne e/ou leite entre abril e setembro, constituídas principalmente por aveia-preta (Avena strigosa) e azevém (Lolium multiflorum) em consórcio, seguidas do cultivo em sucessão de culturas graníferas de verão, como a soja (Glycine max), o milho (Zea mays), o arroz (Oryza sativa) e o feijão (Phaseolus vulgaris).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 156](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 156 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0157 — Quais são os tipos de propriedade rural que adotam e/ou que têm potencial para adotar os sistemas de ILP e de ILPF na região Sul?

**Variantes:** Me tira uma dúvida: quais são os tipos de propriedade rural que adotam e/ou que têm potencial para adotar os sistemas de ILP e de ILPF na região Sul? · tipos propriedade rural adotam potencial adotar sistemas? · quais sao os tipos de propriedade rural q adotam e/ou q tem potencial pra adotar os sisteas de ilp e de ilpf na regiao sul

Geralmente propriedades que priorizam a otimização do uso dos recursos – terra, mão de obra, máquinas e insumos – almejam maior rentabilidade por área e por tempo. Na região Sul, é comum o uso de sistemas de integração tanto em propriedades pequenas (menos de 20 ha cultivados), as quais geralmente possuem no sistema a criação de bovinos para produção de leite, quanto em propriedades com áreas extensas (mais de 500 ha), que geralmente utilizam bovinos para corte e culturas altamente mecanizadas, sobretudo soja e milho.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 157](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 157 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0158 — Em quais regiões do Sul do Brasil os sistemas de ILP e ILPF vêm sendo mais adotados e em quais têm grande potencial de adoção?

**Variantes:** Queria entender: em quais regiões do Sul do Brasil os sistemas de ILP e ILPF vêm sendo mais adotados e em quais têm grande potencial de adoção? · regiões sul brasil sistemas ilp ilpf vêm? · em quais regioes do sul do brasil os sistemas de ilp e ilpf vem sendo mais adotados e em quais tem grande potencal de adocao

A adoção do sistema de ILP ocorre de forma expressiva principalmente em regiões de clima subtropical, onde o cultivo de forrageiras de inverno é possível em sucessão à soja e a outros cultivos de verão. Esse cenário ocorre principalmente nas regiões de várzea e coxilha com cultivo de arroz irrigado – Planalto Médio, Depressão Central e Campos de Cima da Serra, no Rio Grande do Sul, região Central e Oeste de Santa Catarina e Centro-Sul do Paraná. Já no contexto de ILPF, o cenário é mais restritivo, com área menos expressiva, atendendo a especificidades regionais. No sul do Paraná, o sistema de ILPF é adotado com atividade de pecuária leiteira, geralmente em pequenas propriedades.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 158](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 158 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0159 — Na região Sul, a rotação de culturas em sistema de ILP pode ser simplificada no cultivo sequencial de soja no verão e aveia-azevém no inverno?

**Variantes:** Me tira uma dúvida: na região Sul, a rotação de culturas em sistema de ILP pode ser simplificada no cultivo sequencial de soja no verão e aveia-azevém no inverno? · região sul rotação culturas sistema ilp simplificada? · na regiao sul, a rotacao de culturas em sistema de ilp pode ser simplificada no cultivo sequencal de soja no verao e aveia-azevem no inverno

Não. A rotação de culturas constitui a alternância ordenada de diferentes culturas, em determinado espaço de tempo (ciclo), na mesma área e na mesma estação do ano. Em outras palavras, a rotação de culturas implica a variação de culturas dentro de uma mesma estação do ano (ex.: alternância entre milho e soja no verão). Assim, o uso contínuo e exclusivo de aveia e azevém (em cultivo solteiro ou consorciado) no inverno, seguido de soja no verão, não constitui um sistema de rotação, mas sim uma sucessão de culturas, e, dessa forma, deve ser evitado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 159](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 159 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0160 — Quais são as principais opções de consórcio de culturas existentes para o sistema de ILP na região Sul?

**Variantes:** Tu sabe me dizer: quais são as principais opções de consórcio de culturas existentes para o sistema de ILP na região Sul? · principais opções consórcio culturas existentes sistema ilp? · quais sao as principais opcoes de consorio de culturas existentes pra o sistema de ilp na regiao sul

Na parte mais fria da região Sul (subtropical), a principal e mais difundida opção é o consórcio entre aveia-preta e azevém no inverno, implantados simultaneamente. Além da facilidade de obtenção de sementes, implantação e manejo, esse consórcio, quando comparado ao cultivo solteiro de aveia-preta ou azevém, possui alta compatibilidade com o cultivo de soja, milho ou feijão em sucessão e proporciona forragem de alta qualidade por um período maior de tempo. Nesse sentido, a aveia, de crescimento mais rápido, permite que o início do pastejo ocorra cedo, enquanto o azevém, por ser mais tardio, possibilita que os animais permaneçam na área por um período maior de tempo, geralmente até o outubro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 160](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 160 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0161 — Quais são as principais opções de sucessão ou rotação de culturas existentes para o sistema de ILP na região Sul?

**Variantes:** Queria entender: quais são as principais opções de sucessão ou rotação de culturas existentes para o sistema de ILP na região Sul? · principais opções sucessão rotação culturas existentes sistema? · quais sao as principais opcoes de sucessao ou rotacao de culturas existenes pra o sistema de ilp na regiao sul

No contexto atual, o cenário mais encontrado na região subtropical é o cultivo de aveia-preta, aveia-branca (Avena sativa) ou aveia + azevém, implantados após a colheita da soja ou do milho de verão. Como a rotação de culturas ocorre apenas em pequeno percentual da área, na primavera, após o período de pastejo, a soja retorna à área e isso caracteriza uma sucessão de culturas. Em áreas com rotação de culturas, a principal opção para rotação com a soja é o milho de verão. Com menor área cultivada, o feijão entra como uma opção de cultivo de verão, que, por ter ciclo curto em relação à soja e ao milho, proporciona mais tempo à produção forrageira de inverno.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SOJ-015
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 161](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 161 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0162 — Quais são as implicações dos ciclos de desenvolvimento de cultivares e/ou culturas de verão nos sistemas de ILP na região Sul?

**Variantes:** Queria entender: quais são as implicações dos ciclos de desenvolvimento de cultivares e/ou culturas de verão nos sistemas de ILP na região Sul? · implicações ciclos desenvolvimento cultivares culturas verão sistemas? · quais sao as implicaces dos ciclos de desenvolvimento de cultivares e/ou culturas de verao nos sistemas de ilp na regiao sul

Em vários locais da região Sul do Brasil o uso de variedades precoces de culturas de verão pode ajudar no estabelecimento da pastagem de inverno em sucessão, antecipando a entrada dos animais na pastagem. Além dos benefícios que o menor ciclo proporciona à sanidade do cultivo de verão, que passa menos tempo exposto a insetos-praga e doenças, as temperaturas favoráveis do outono, antes da chegada do inverno, aceleram o estabelecimento do pasto. Ao fazer o planejamento da rotação de culturas, prática indispensável para a boa condução dos sistemas de ILPF, é interessante utilizar culturas que permitam maior penetração de luz no solo ao final do ciclo, como é o caso do milho.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 162](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 162 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0163 — Quais são as principais espécies forrageiras anuais e perenes recomendadas para os sistemas de ILP e ILPF na região Sul?

**Variantes:** Tchê, me ajuda: quais são as principais espécies forrageiras anuais e perenes recomendadas para os sistemas de ILP e ILPF na região Sul? · principais espécies forrageiras anuais perenes recomendadas sistemas? · quais sao as principis especies forrageiras anuais e perenes recomendadas pra os sistemas de ilp e ilpf na regiao sul

As principais espécies forrageiras de inverno indicadas são aveia-preta, azevém e as leguminosas trevo-branco (Trifolium repens) e cornichão. Os cereais de inverno de duplo propósito (forragem e grãos) têm aumentado em importância principalmente de trigo cultivar BRS Tarumã, aveia-branca, centeio, triticale (X. Triticosecale) e cevada. Para o verão, são indicadas as gramíneas forrageiras perenes, como as braquiárias (U. brizantha cv. Marandú, Urochloa decumbens e U. ruziziensis) e os panicuns (P. maximum cvs. Aruana, Mombaça, Tanzânia). Entre as anuais de verão, são indicadas o milheto (Pennisetum americanum), o capim-sudão (Sorghum sudanense) e os sorgos forrageiros (Sorghum bicolor).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 163](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 163 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0164 — ILPF: quais são as principais opções de espécies para ensilagem ou fenação para a região Sul e quais são as principais vantagens e limitações de cada uma?

**Variantes:** Tu sabe me dizer: quais são as principais opções de espécies para ensilagem ou fenação para a região Sul e quais são as principais vantagens e limitações de cada uma (ilpf)? · principais opções espécies ensilagem fenação região sul (ilpf)? · quais sao as principais opcoes de especies pra ensilagem ou fenacao pra a regiao sul e quais sao as principais vantagens e limitaces de cada uma (ilpf)

Para ensilagem na região Sul, as principais opções são o milho e o sorgo durante o verão. Na estação fria, são indicados os cereais de inverno (aveia-branca, trigo, cevada, centeio e triticale), além de aveia-preta e azevém. O milho é a cultura preferencial por combinar as melhores características produtivas e de valor nutritivo. O sorgo, embora possa ter maior produtividade, em geral resulta em forragem de menor valor nutritivo. As espécies de verão são mais produtivas e podem render mais que o dobro, no que se refere à matéria seca acumulada, em relação às de inverno.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 164](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 164 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0167 — Para as condições de solo e de clima da região Sul, quais são as maiores contribuições de sistemas de ILP e de ILPF para a sustentabilidade das propriedades rurais?

**Variantes:** Bah, uma dúvida: para as condições de solo e de clima da região Sul, quais são as maiores contribuições de sistemas de ILP e de ILPF para a sustentabilidade das propriedades rurais? · condições solo clima região sul maiores contribuições? · para as condices de solo e de clima da regiao sul, quais sao as maiores contribuicoes de sistemas de ilp e de ilpf pra a sustentabilidade das propriedades rurais

Na região Sul, tanto em grandes quanto em pequenas propriedades, os sistemas de integração de produção permitem a diversificação das atividades. Com isso, otimiza-se o uso da terra, das máquinas, dos insumos e da mão de obra, diluindo custos e riscos relacionados à atividade rural, além de aumentar a produção por área. Em termos econômicos, isso proporciona maior competitividade e estabilidade ao agronegócio. Em relação a aspectos agronômicos, a integração de atividades na mesma área permite utilizar diferentes espécies vegetais, o que possibilita o manejo mais racional de insetos-praga, doenças e plantas daninhas, reduzindo o aparecimento de resistência aos agrotóxicos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* EVT-006
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 167](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 167 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico.

### SUST-ILPF-0170 — ILPF: quando e como deve ser feita a dessecação das pastagens antes da implantação de culturas para grãos na região Sul do Brasil?

**Variantes:** Alguém me explica: quando e como deve ser feita a dessecação das pastagens antes da implantação de culturas para grãos na região Sul do Brasil (ilpf)? · feita dessecação pastagens antes implantação culturas grãos (ilpf)? · quando e como deve ser feita a dessecaao das pastagens antes da implantacao de culturas pra graos na regiao sul do brasil (ilpf)

Inicialmente é importante frisar que, no momento da implantação das culturas de grãos, o pasto deve estar adequadamente dessecado, a fim de evitar possível interferência do pasto sobre as culturas semeadas em sucessão. O principal herbicida utilizado no Brasil para dessecações, seja de pastagens seja de outras plantas, é o glifosato, que é um herbicida não seletivo, sistêmico, que apresenta custo acessível e adequado funcionamento. Para pastagens de azevém resistentes a esse herbicida, muito comuns nos três estados do Sul do Brasil, geralmente são empregados herbicidas graminicidas ou dessecantes de contato para auxiliar na dessecação da pastagem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 170](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 170 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico. Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0171 — Quais são os principais gargalos para a implantação e con-dução de sistemas de ILP ou ILPF por produtores tradicionais de grãos na região Sul?

**Variantes:** Tu sabe me dizer: quais são os principais gargalos para a implantação e con-dução de sistemas de ILP ou ILPF por produtores tradicionais de grãos na região Sul? · principais gargalos implantação con-dução sistemas ilp ilpf? · quais sao os principais gargalos pra a implantacao e con-ducao de sistemas de ilp ou ilpf por produtores tradicionis de graos na regiao sul

O grande gargalo na introdução desses sistemas em propriedades cujo foco é a produção de grãos é o medo do efeito negativo dos animais em pastejo quanto à compactação do solo e à falta de palha para cultivo de grãos em sucessão. Precisa haver grande convencimento técnico e capacitação no que se refere aos efeitos benéficos dos animais no sistema de produção, e a intensidade de pastejo é o ponto-chave para conciliar a produção animal com a vegetal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 171](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 171 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0172 — Quais são os principais gargalos para a implantação e condução de sistemas de ILP ou ILPF para produtores tradicionais de gado na região Sul?

**Variantes:** Tchê, me ajuda: quais são os principais gargalos para a implantação e condução de sistemas de ILP ou ILPF para produtores tradicionais de gado na região Sul? · principais gargalos implantação condução sistemas ilp ilpf? · quais sao os principais gargalos pra a implantaao e conducao de sistemas de ilp ou ilpf pra produtores tradicionais de gado na regiao sul

Os principais gargalos se referem à necessidade de adequar a infraestrutura da propriedade para produção de grãos, principalmente no que se refere à aquisição de máquinas, o que exige alto investimento e conhecimentos sobre o manejo de espécies para produção de grãos ou madeira. Uma alternativa é o arrendamento de áreas para agricultores – algo muito comum nos três estados do Sul do Brasil. Nesse caso, o pecuarista continua focado na pecuária, mas alcança os benefícios dos sistemas de integração por meio da parceria com agricultores.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 172](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 172 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0173 — Quais são as principais modalidades de parcerias entre pecuaristas e agricultores na região Sul para viabilizar o sistema de ILP em larga escala?

**Variantes:** Tchê, me ajuda: quais são as principais modalidades de parcerias entre pecuaristas e agricultores na região Sul para viabilizar o sistema de ILP em larga escala? · principais modalidades parcerias pecuaristas agricultores região sul? · quais sao as principais modalidades de parcerias entre pecuaristas e agricultores na regiao sul pra viabiliar o sistema de ilp em larga escala

No Sul do Brasil, a questão das parceiras entre agricultores e pecuaristas é crucial para a viabilização do sistema de ILP em larga escala. No Planalto do Rio Grande de Sul, em Santa Catarina e no Paraná, é comum o cultivo de grãos no verão e a implantação das forrageiras de inverno pelos agricultores, e estas últimas são arrendadas para pecuaristas que usam a pastagem para a engorda de animais. Geralmente o pagamento é feito em porcentagem do ganho de peso alcançado no período que os animais permanecem nas pastagens arrendadas (cerca de 50% a 70% do ganho de peso).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 173](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 173 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0174 — Na região Sul, quais são as principais oportunidades para inserção do componente florestal em sistemas de integração com pastagens e/ou lavouras?

**Variantes:** Uma pergunta: na região Sul, quais são as principais oportunidades para inserção do componente florestal em sistemas de integração com pastagens e/ou lavouras? · região sul principais oportunidades inserção componente florestal? · na regiao sul, quais sao as principais oportunidades pra insercao do componente florestal em sisteas de integracao com pastagens e/ou lavouras

As principais oportunidades decorrem da presença de arranjos produtivos locais (APLs) que têm na madeira sua fonte de matéria-prima, bem como dos setores de papel e celulose, de mobiliário, de carne, leite e couro. Dois dos três maiores polos da cadeia da madeira e de mobiliário do País estão na região Sul, onde a atividade leiteira é a de maior crescimento no País desde 2010. Todos esses setores e suas respectivas cadeias produtivas carecem de produtos que atendam aos anseios da produção ambientalmente adequada, especialmente na região Sul, onde os sistemas de uso da terra estão sob pressão para que adotem formas de produção mais sustentáveis.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 174](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 174 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0176 — Quais são os principais arranjos para distribuição espacial das árvores em sistemas de ILPF na região Sul?

**Variantes:** Uma pergunta: quais são os principais arranjos para distribuição espacial das árvores em sistemas de ILPF na região Sul? · principais arranjos distribuição espacial árvores sistemas ilpf? · quais sao os principais arranjos pra distribuicao espacial das arvores em sisteas de ilpf na regiao sul

A maneira adequada de distribuir as árvores na área em sistema de ILPF é pelo arranjo em renques de linha simples, ou múltiplas linhas (2, 3 ou mais), preferencialmente alocadas em nível para auxiliar no controle da erosão. Essa forma de distribuição permite o trânsito de máquinas e implementos e favorece o manejo do rebanho e a colheita da madeira. É importante lembrar que a distância entre os renques deve ser calculada para permitir que os implementos transitem sem dificuldades. Por exemplo, deve-se levar em consideração a largura da barra do pulverizador, da plantadeira e da plataforma da colheitadeira.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 176](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 176 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0177 — Como deve ser o manejo das árvores em sistemas de ILPF na região Sul?

**Variantes:** Tchê, me ajuda: como deve ser o manejo das árvores em sistemas de ILPF na região Sul? · manejo árvores sistemas ilpf região sul? · como deve ser o manejo das arvores em sisteas de ilpf na regiao sul

De modo geral, o manejo das árvores pode ser resumido como manejo de copa, em que o objetivo é manter um ambiente luminoso que permita a produção de lavouras e de forrageiras que seja suficiente para um bom desempenho dos animais no sistema. Para tanto, será necessário realizar desbastes (retirar árvores inteiras) para manter a cobertura de copa das árvores entre 30% e 35%. Os desbastes cumprem duas funções: favorecer o crescimento das melhores árvores para a produção de toras e regular a sombra, evitando que o sistema fique com excesso de sombreamento, o que é prejudicial para o crescimento da lavoura e da pastagem. Também é possível escalonar a produção de madeira e de grãos.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 177](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 177 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### SUST-ILPF-0180 — Nas condições de solos hidromórficos, nos quais o cultivo do arroz irrigado é predominante, que cuidados de manejo de solo devem ser priorizados na adoção de sistemas de ILP?

**Variantes:** Bah, uma dúvida: nas condições de solos hidromórficos, nos quais o cultivo do arroz irrigado é predominante, que cuidados de manejo de solo devem ser priorizados na adoção de sistemas de ILP? · condições solos hidromórficos cultivo arroz irrigado predominante? · nas condicoes de solos hidromorficos, nos quais o cultivo do arroz irrigado e predominante, q cuidados de manejo de solo devem ser priorizaos na adocao de sistemas de ilp

Nas áreas de cultivo de arroz irrigado, o primeiro aspecto a ser considerado para a introdução de sistemas de ILP é a rotação das atividades nos talhões, ou seja, o arroz irrigado cultivado por 1 a 2 anos e as culturas de sequeiro (soja, milho, sorgo) em rotação e/ou sucessão com pastagens de inverno e de verão durante 3 ou 4 anos. Quanto ao manejo do solo, os primeiros aspectos a serem considerados são a incorporação da palhada de arroz e a drenagem do solo após a colheita do cereal. O recomendado na incorporação da palhada é o uso de equipamento do tipo rolo-faca. Para drenagem é recomendado drenos superficiais e drenos internos ao solo com subsoladores do tipo torpedo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 180](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 180 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0181 — Quais são as formas ou modalidades de sistemas de integração lavoura-pecuária (ILP) e de integração lavoura-pecuária-floresta (ILPF) mais comumente adotadas na sub-região dos cerrados do Nordeste?

**Variantes:** Bah, uma dúvida: quais são as formas ou modalidades de sistemas de integração lavoura-pecuária (ILP) e de integração lavoura-pecuária-floresta (ILPF) mais comumente adotadas na sub-região dos cerrados do Nordeste? · formas modalidades sistemas integração lavoura-pecuária ilp integração? · quais sao as formas ou modalidades de sistemas de integraao lavoura-pecuaria (ilp) e de integracao lavoura-pecuaria-floresta (ilpf) mais comumente adotadas na sub-regiao dos cerrados do nordeste

No Cerrado nordestino, que abrange o sudoeste do Piauí, o sul e o leste do Maranhão e o oeste da Bahia, onde a produção de grãos é a principal atividade rural, os sistemas mais adotados são: • Sistema agropastoril ou ILP: composto pelos componentes agrícola e pecuário na mesma área por meio do consórcio de milho (Zea mays) com forrageiras para atividade de bovinocultura e ovinocultura em pasto, na entressafra, e soja (Glycine max) em semeadura direta depois do pastejo. • Sistema agrossilvipastoril ou ILPF: mais indicado para regiões onde há demanda por produtos madeireiros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 181](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 181 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0182 — Quais são as formas ou modalidades de sistemas de ILP e de ILPF mais comumente adotadas na sub-região da pré-Amazônia maranhense?

**Variantes:** Uma pergunta: quais são as formas ou modalidades de sistemas de ILP e de ILPF mais comumente adotadas na sub-região da pré-Amazônia maranhense? · formas modalidades sistemas ilp ilpf comumente adotadas? · quais sao as formas ou modalidades de sistemas de ilp e de ilpf mais comumente adotaas na sub-regiao da pre-amazonia maranhense

Neste bioma, que ocorre no Estado do Maranhão, as atividades predominantes são a pecuária de corte e leite e a produção de madeira para lenha, carvão e celulose.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 182](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 182 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0183 — Quais são as formas ou modalidades de ILP e de ILPF mais comumente adotadas nas sub-regiões da Caatinga, do Agreste e da Zona da Mata do Nordeste?

**Variantes:** Tchê, me ajuda: quais são as formas ou modalidades de ILP e de ILPF mais comumente adotadas nas sub-regiões da Caatinga, do Agreste e da Zona da Mata do Nordeste? · formas modalidades ilp ilpf comumente adotadas sub-regiões? · quais sao as formas ou modalidades de ilp e de ilpf mais comumete adotadas nas sub-regioes da caatinga, do agreste e da zona da mata do nordeste

Os modelos descritos na resposta da pergunta anterior também são os mais indicados para a Caatinga, o Agreste e a Zona da Mata. Para as fazendas de pecuária de corte ou leite situadas nessas sub-regiões, um dos sistemas mais recomendados é o agrossilvipastoril, ou ILPF, no qual se consorcia a gliricídia (Gliricidia sepium) com milho e capim-braquiarão (Urochloa brizantha syn. Brachiaria brizantha). Esse sistema pode ser utilizado na recuperação de pastagens degradadas ou na formação de novas pastagens. O sistema tem início com o plantio do milho em toda a área, em consórcio com o capim-braquiarão.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 183](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 183 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0184 — Quais são os tipos de propriedade rural que adotam e/ou que têm potencial de adoção dos sistemas de ILP e de ILPF no Cerrado e na pré-Amazônia da região Nordeste?

**Variantes:** Bah, uma dúvida: quais são os tipos de propriedade rural que adotam e/ou que têm potencial de adoção dos sistemas de ILP e de ILPF no Cerrado e na pré-Amazônia da região Nordeste? · tipos propriedade rural adotam potencial adoção sistemas? · quais sao os tipos de propriedade rural q adotam e/ou q tem potencial de adocao dos sisteas de ilp e de ilpf no cerrado e na pre-amazonia da regiao nordeste

As propriedades produtoras de grãos desses biomas têm potencial para a pecuária, seja de grandes animais (bovinos de corte e leite), seja de pequenos ruminantes (ovinos e caprinos), e ainda para o componente florestal, uma vez que esse polo demanda produtos madeireiros (lenha e carvão) e está limítrofe com a região pecuária desses estados, o que favorece incluir o componente pecuário. Outras propriedades são as fazendas de pecuária da pré-Amazônia maranhense, que, além de já explorarem a atividade pecuária de corte em larga escala, tem potencial para introduzir o componente agrícola como forma de recuperar/renovar o pasto.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 184](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 184 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0185 — Quais são os tipos de propriedade rural que adotam e/ou que têm potencial para adoção dos sistemas de ILP e de ILPF nas sub-regiões da Caatinga, do Agreste e da Zona da Mata do Nordeste?

**Variantes:** Alguém me explica: quais são os tipos de propriedade rural que adotam e/ou que têm potencial para adoção dos sistemas de ILP e de ILPF nas sub-regiões da Caatinga, do Agreste e da Zona da Mata do Nordeste? · tipos propriedade rural adotam potencial adoção sistemas? · quais sao os tipos de propriedde rural q adotam e/ou q tem potencial pra adocao dos sistemas de ilp e de ilpf nas sub-regioes da caatinga, do agreste e da zona da mata do nordeste

Grande parte dos estabelecimentos rurais na Caatinga, no Agreste e na Zona da Mata da região Nordeste é de pequenas propriedades. Considerando-se que a pecuária é a atividade econômica principal desses locais, os modelos adotados estão relacionados com atividades de sistemas de produção animal. Dessa forma, as propriedades dedicadas predominantemente à pecuária bovina de corte e leite e à ovinocultura têm maior potencial de uso do sistema ILPF, enquanto as propriedades lavoureiras de milho possuem maior potencial para adoção do sistema de ILP.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 185](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 185 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0188 — Quais são as opções de consórcio de culturas existentes para o sistema de ILP com situação prévia de pecuária na região Nordeste?

**Variantes:** Tu sabe me dizer: quais são as opções de consórcio de culturas existentes para o sistema de ILP com situação prévia de pecuária na região Nordeste? · opções consórcio culturas existentes sistema ilp situação? · quais sao as opcoes de consorcio de culturas existentes pra o sistema de ilp com situaao previa de pecuaria na regiao nordeste

Nas sub-regiões onde a pecuária é a atividade predominante, como a pré-Amazônia maranhense, onde o sistema de ILP é mais usado para recuperar/renovar pastagens degradadas, as opções mais indicadas são o consórcio de milho com forrageiras em terras altas e o de arroz com forrageiras (áreas de baixadas sujeitas à inundação periódica nos períodos de chuvas). A cultura do milho nesse sistema pode ser para produção de grãos ou silagem. Na Caatinga, no Agreste e na Zona da Mata, a opção para situação prévia de pecuária é a mesma para a situação prévia de agricultura. Na maioria das situações, o sistema de ILP é usado para recuperação da pastagem degradada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 188](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 188 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0189 — Quais são as opções de sucessão e de rotação de culturas existentes para a ILP na região Nordeste?

**Variantes:** Alguém me explica: quais são as opções de sucessão e de rotação de culturas existentes para a ILP na região Nordeste? · opções sucessão rotação culturas existentes ilp região? · quais sao as opcoes de sucesao e de rotacao de culturas existentes pra a ilp na regiao nordeste

No polo produtor de grãos do Cerrado nordestino, a área de cultivo com a lavoura de soja no plano de rotação de culturas de grãos mais indicado para o sistema de ILP ocupa 2/3 ou 3/4, e a lavoura de milho com forrageiras ocupa 1/3 ou 1/4. Após a colheita do milho, a pastagem fica formada, e sua utilização ocorre apenas na entressafra com terminação de bovinos e ovinos em pasto (modalidade boi safrinha). Depois da retirada dos animais, no final do período seco, a palhada restante deve ser utilizada para o plantio direto na safra seguinte. Nesse plano, segue-se a rotação de área, na qual, a cada safra, o consórcio e a pastagem passam para a área que foi cultivada com soja, e assim sucessivamente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 189](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 189 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0199 — Como deve ser o manejo silvicultural do componente florestal na condução de sistemas de ILPF na região Nordeste?

**Variantes:** Queria entender: como deve ser o manejo silvicultural do componente florestal na condução de sistemas de ILPF na região Nordeste? · manejo silvicultural componente florestal condução sistemas ilpf? · como deve ser o manejo silvicultural do componente florestal na conducao de sistemas de ilpf na regiao nordete

O arranjo florestal no sistema de ILPF é feito por intercalação da espécie arbórea, que é plantada em renques separados em faixas ou aleias, onde se cultivam lavouras por cerca de 3 anos. Daí até ao final do ciclo da espécie arbórea, a pastagem que será formada no terceiro ano pelo consórcio com milho será utilizada para a pecuária de corte ou leite. Nesse arranjo, o manejo inicia-se com os cuidados na aquisição e no manejo das mudas do viveiro ao plantio, que devem apresentar bom estado sanitário e vigor. Na área onde serão plantadas as mudas da espécie arbórea, devem ser identificados os formigueiros e cupinzeiros e deve ser aplicado o defensivo de combate.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 199](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 199 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico. Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico.

### SUST-ILPF-0202 — Quais são os principais cuidados a serem observados na aquisição de sementes de forrageiras e quais são as formas de semeadura nos consórcios de ILP e ILPF observados na região Nordeste?

**Variantes:** Me explica uma coisa: quais são os principais cuidados a serem observados na aquisição de sementes de forrageiras e quais são as formas de semeadura nos consórcios de ILP e ILPF observados na região Nordeste? · principais cuidados serem observados aquisição sementes forrageiras? · quais sao os principais cuidados a serem observados na aquisicao de semenes de forrageiras e quais sao as formas de semeadura nos consorcios de ilp e ilpf observados na regiao nordeste

As sementes devem ser de boa qualidade, com valor cultural (VC) superior a 50%, preferencialmente em torno de 80%, livres de impurezas e sem torrões de terra que possam levar junto alguns patógenos como nematoides e outros. As formas de semeadura das forrageiras no consórcio com milho e arroz são as seguintes: • Misturadas ao adubo químico na plantadeira, se a semeadura for simultânea e as sementes maiores, como as de braquiárias. • Distribuídas a lanço em plantadeiras com terceira caixa. • Distribuídas a lanço se em solo gradeado com plantio do milho ou arroz no mesmo dia e se as sementes forem muito miúdas, como, por exemplo, as forrageiras do gênero Panicum sp.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 202](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 202 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0206 — Quais são as formas ou modalidades de sistema de integração lavoura-pecuária (ILP) mais comumente adotadas na região Norte?

**Variantes:** Queria entender: quais são as formas ou modalidades de sistema de integração lavoura-pecuária (ILP) mais comumente adotadas na região Norte? · formas modalidades sistema integração lavoura-pecuária ilp comumente? · quais sao as formas ou modalidades de sistema de integracao lavoura-pecuaria (ilp) mais comumente adotaas na regiao norte

As modalidades de sistema de ILP mais comumente adotadas na região Norte são: • Consórcio de milho (Zea mays) com braquiária (siste- ma Santa Fé) para renovação de pastagens em áreas predominantemente de pecuária. • Soja (Glycine max) e/ou arroz (Oryza sativa) como cultura principal e forrageira implan-tada em sobressemeadura ou após a colheita. • Soja como cultura principal, milho safrinha consorciado com braquiária em polos sojicultores tradicionais. Existem também variações em decorrência das peculiaridades de produtores quanto a suas prioridades de produção. Para produtores rurais que têm a pecuária como principal atividade, a utilização do sistema decorre da necessidade de renovação das pastagens.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 206](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 206 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0208 — Quais são os tipos de propriedade rural que adotam e/ou que têm potencial de adoção dos sistemas de ILP, integração pecuária-floresta (IPF) e integração lavoura-pecuária-floresta (ILPF) na região Norte?

**Variantes:** Tchê, me ajuda: quais são os tipos de propriedade rural que adotam e/ou que têm potencial de adoção dos sistemas de ILP, integração pecuária-floresta (IPF) e integração lavoura-pecuária-floresta (ILPF) na região Norte? · tipos propriedade rural adotam potencial adoção sistemas? · quais sao os tipos de propriedade rural q adotam e/ou q tem potencial de adocao dos sistemas de ilp, integracao pecuaria-floresta (ipf) e integraao lavoura-pecuaria-floresta (ilpf) na regiao norte

Em sua maioria, são propriedades médias ou grandes com foco na recuperação de pastagens degradadas com baixos índices de produtividade. Em geral, nessas propriedades há acesso a máquinas agrícolas para a produção de grãos, e que também podem ser utilizadas em atividades pecuárias, o que facilita a adoção do sistema integrado. O sistema de ILP é adotado por meio do consórcio (milho + capim) ou da sucessão, com a semeadura de uma cultura de grãos na safra (arroz ou soja) e, em seguida, a semeadura do capim, consorciado ou não com a cultura do milho, para grão e/ou silagem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 208](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 208 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0210 — Quais são as opções de consórcio de culturas para o sistema de ILP com situação prévia de agricultura na região Norte?

**Variantes:** Alguém me explica: quais são as opções de consórcio de culturas para o sistema de ILP com situação prévia de agricultura na região Norte? · opções consórcio culturas sistema ilp situação prévia? · quais sao as opcoes de consorio de culturas pra o sistema de ilp com situacao previa de agricultura na regiao norte

Em sub-regiões onde as atividades agrícolas estão estabelecidas ou em expansão, o sistema de ILP tem sido praticado pelo consórcio de algumas culturas como: milho (grão e/ou silagem) + capim (braquiárias e panicuns); soja + capim (sobressemeadura); arroz + capim. Os capins mais comumente utilizados são as braquiárias, principalmente Urochloa brizantha e Urochloa ruziziensis.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 210](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 210 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0211 — Quais são as opções de consórcio de culturas para o sistema de ILP com situação prévia de pecuária na região Norte?

**Variantes:** Me tira uma dúvida: quais são as opções de consórcio de culturas para o sistema de ILP com situação prévia de pecuária na região Norte? · opções consórcio culturas sistema ilp situação prévia? · quais sao as opcoes de consorcio de culturas pra o sistema de ilp com situacao previa de pecuaia na regiao norte

Nas regiões onde a pecuária está estabelecida e os pecuaristas estão buscando melhorias de seus índices produtivos visando à maior eficiência da atividade, em geral, os produtores iniciam o processo com milho ou arroz consorciado com espécies de gramíneas forrageiras (especialmente do gênero braquiária) e aplicam essa prática agropecuária na recuperação de pastagens degradadas, sendo este o maior potencial de adoção de sistemas de integração na região Norte.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 211](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 211 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0214 — Quais são as principais espécies forrageiras recomendadas para o sistema de ILP na região Norte?

**Variantes:** Bah, uma dúvida: quais são as principais espécies forrageiras recomendadas para o sistema de ILP na região Norte? · principais espécies forrageiras recomendadas sistema ilp região? · quais sao as principais especies forrageias recomendadas pra o sistema de ilp na regiao norte

As espécies forrageiras tradicionalmente utilizadas e recomendadas são milho e sorgo para silagem; e, para o uso como pastagem, as espécies de braquiárias (U. ruzizienses, U. brizantha cv. Marandú, cv. Xaraes, cv. Piatã, U. humidicola) são predominantes nos sistemas; no entanto, outras opções têm sido apontadas e pesquisadas na região, como: Paspalum atratum cv. Pojuca e Panicun maximum cv. Mombaça. O plantio de milho e sorgo para silagem garante a alimentação suplementar do gado no período seco, e, após a colheita da forragem, a pastagem que foi consorciada com a cultura estará implantada. Assim o produtor terá disponíveis duas alternativas (silagem e pastagem) para a alimentação do gado no período seco.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 214](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 214 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0215 — Como deve ser o manejo animal em áreas recém-implantadas de sistema de ILP na região Norte?

**Variantes:** Me tira uma dúvida: como deve ser o manejo animal em áreas recém-implantadas de sistema de ILP na região Norte? · manejo animal áreas recém-implantadas sistema ilp região? · como deve ser o manejo animal em areas recem-implantadas de sistema de ilp na regiao norte

O ingresso de animais em áreas de intensa produção agrícola objetiva intensificar o uso da terra. Os animais entram no sistema após a colheita e alimentam-se dos resíduos da cultura e das plantas de cobertura utilizadas. No entanto, é necessário aguardar a recuperação da espécie forrageira destinada à pastagem por um período de 30 a 45 dias. Após esse período, os animais são introduzidos na área para um pastejo leve, dito pastejo de formação, e, finalmente, um período de isolamento da área, deixando-a apta para emprego das mesmas técnicas de manejo recomendadas para pastagens puras (pastejo rotacionado, categorias de animais separadas, etc.).

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 215](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 215 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### SUST-ILPF-0216 — Quais são as práticas para implantação do sistema de ILP com as finalidades de produção de forragem na entressafra seca e para produção de palhada para melhorar o sistema de plantio direto (SPD) na região Norte?

**Variantes:** Tchê, me ajuda: quais são as práticas para implantação do sistema de ILP com as finalidades de produção de forragem na entressafra seca e para produção de palhada para melhorar o sistema de plantio direto (SPD) na região Norte? · práticas implantação sistema ilp finalidades produção forragem? · quais sao as praticas pra implantacao do sistema de ilp com as finalidades de producao de forragem na entressara seca e pra producao de palhada pra melhorar o sistema de plantio direto (spd) na regiao norte

A implantação inicia-se na safra do ano anterior. O produtor deverá seguir as práticas recomendadas para implantação de um sistema de ILP, como: analisar o solo e calcular a necessidade de correção e adubação; adquirir sementes, preparar a área e aplicar calcário; semear as culturas de grãos e forrageiras; após a colheita dos grãos, aguardar período de pousio na área para iniciar o pastejo; introduzir os animais para pastejo no período seco; isolar a área pelo menos 30 dias antes da dessecação; proceder a dessecação e sequência de ações para implantação do SPD. Essa prática está concentrada na sobressemeadura da forrageira no cultivo da soja e o consórcio de milho com braquiária.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 216](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 216 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0219 — Quais são as principais opções de espécies florestais nativas para o sistema de ILPF na região Norte?

**Variantes:** Me tira uma dúvida: quais são as principais opções de espécies florestais nativas para o sistema de ILPF na região Norte? · principais opções espécies florestais nativas sistema ilpf? · quais sao as principais opcoes de especes florestais nativas pra o sistema de ilpf na regiao norte

Embora a diversidade de espécies nativas na Amazônia seja grande, a disponibilidade de conhecimentos silviculturais para exploração delas ainda é restrita. No entanto, algumas vêm sendo estudadas e utilizadas. São elas: bordão de velho (Samanea tubulosa), cedro-doce (Bombacopsis quinata), taxi-branco (Sclerolobium paniculatum), paricá (Schizolobium parahyba), baginha (Stryphnodendron pulcherrimum), mogno (Swietenia macrophylla), mulateiro (Calicophyllum spruceanum), cumaru (Dipteryx odorata), castanha-do-brasil (Bertholletia excelsa), entre outras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 219](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 219 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0221 — Como deve ser o manejo silvicultural do componente florestal na condução de sistemas de ILPF na região Norte?

**Variantes:** Uma pergunta: como deve ser o manejo silvicultural do componente florestal na condução de sistemas de ILPF na região Norte? · manejo silvicultural componente florestal condução sistemas ilpf? · como deve ser o manejo silvicultural do componente florestal na conducao de sisteas de ilpf na regiao norte

O manejo deve levar em consideração o objetivo do sistema implantado e a finalidade do componente florestal. Dependendo da espécie florestal, é necessária a realização de podas para promover o aumento da taxa de crescimento das árvores e desbastes de algumas árvores de baixo crescimento, sendo estas destinadas para diversos fins, como: energéticos, moirões, etc. Essas práticas têm como objetivo favorecer o desenvolvimento dos demais indivíduos que continuarão na área, contribuir para a maior luminosidade na área de pastagem, além de favorecer a obtenção de madeira de alto valor agregado.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 221](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 221 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### SUST-ILPF-0222 — Quais são as principais experiências de sistemas de ILP e de ILPF da região Norte?

**Variantes:** Queria entender: quais são as principais experiências de sistemas de ILP e de ILPF da região Norte? · principais experiências sistemas ilp ilpf região norte? · quais sao as principis experiencias de sistemas de ilp e de ilpf da regiao norte

Diversas iniciativas de sistemas de ILPF estão sendo conduzidas na região Norte. No Acre, as unidades demonstrativas localizam-se nos municípios de Senador Guiomar e de Rio Branco. Em Rondônia, estudos estão sendo realizados nas Unidades de Referência Tecnológicas (URTs) em Porto Velho (ILP, IPF e ILPF) e Vilhena (ILP e ILPF). Os produtores das regiões do Cone Sul (Corumbiara, Chupinguaia, etc.) e centro-norte do estado têm adotado o sistema de ILP para renovação de pastagens degradas aproveitando a expansão agrícola nessas regiões, principalmente com a cultura da soja.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 222](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 222 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0223 — ILPF: quais são os índices de produtividade (agronômica, zootécnica e florestal) observados nessas unidades experimentais ou fazendas referência?

**Variantes:** Uma pergunta: quais são os índices de produtividade (agronômica, zootécnica e florestal) observados nessas unidades experimentais ou fazendas referência (ilpf)? · índices produtividade agronômica zootécnica florestal observados nessas (ilpf)? · quais sao os indices de produtividade (agronomica, zootecnca e florestal) observados nessas unidades experimentais ou fazendas referencia (ilpf)

Em Rondônia, os índices de produtividade têm sido superiores às médias nacionais. Na safra 2011–2012, foram obtidas produtividades médias de arroz e soja cultivados em sistemas de ILP, em Porto Velho, de 3.429 kg/ha e 3.372 kg/ha respectivamente. Em avaliações do componente florestal em Vilhena, RO, o crescimento do clone GG100 em sistema de ILPF obteve um incremento médio anual (IMA) por árvore de 0,0836 m³/ano. Entretanto, em Paragominas, Pará, esse clone não se desenvolveu satisfatoriamente. Por sua vez, o mogno africano tem apresentado índices surpreendentes de desenvolvimento em todas as unidades experimentais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 223](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 223 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0224 — Quais são as principais oportunidades para a adoção dos sistemas de ILPF na região Norte?

**Variantes:** Uma pergunta: quais são as principais oportunidades para a adoção dos sistemas de ILPF na região Norte? · principais oportunidades adoção sistemas ilpf região norte? · quais sao as principais oportunidades pra a adocao dos sisteas de ilpf na regiao norte

A pecuária é a principal e mais expressiva atividade agropecuária da região Norte e explora vastas áreas de pastagens, que, em razão da exploração e do manejo inadequado, grande parte delas apresenta algum grau de degradação (estimativa de 30 milhões de hectares). Isso reflete nas baixas produtividades da atividade na região. Nesse sentido, o uso de sistemas de ILPF é uma excelente alternativa para recuperação dessas áreas degradadas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 224](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 224 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0226 — Quais são os principais benefícios dos sistemas de integração para a região Norte?

**Variantes:** Uma pergunta: quais são os principais benefícios dos sistemas de integração para a região Norte? · principais benefícios sistemas integração região norte? · quais sao os principais beneficios dos sisteas de integracao pra a regiao norte

• A recuperação do passivo ambiental ocasionado pelo desmatamento e pelas queimadas, por meio da introdução do componente florestal nos sistemas tradicionais de exploração. • Amortização dos custos para renovação/recuperação das pastagens. • Melhoria das condições físicas, químicas e biológicas do solo. • Produção de forragem em quantidade e qualidade disponíveis tanto para pastejo quanto para cobertura do solo. • Redução da sazonalidade das pastagens e reinserção das áreas de pastagens degradadas ao processo produtivo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 226](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 226 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0228 — Como os sistemas de ILP, IPF e ILPF têm potencial de reduzir a pressão de desmatamento na região Norte?

**Variantes:** Queria entender: como os sistemas de ILP, IPF e ILPF têm potencial de reduzir a pressão de desmatamento na região Norte? · sistemas ilp ipf ilpf potencial reduzir pressão? · como os sisteas de ilp, ipf e ilpf tem potencial de reduzir a pressao de desmatamento na regiao norte

Tida como uma das últimas fronteiras agrícolas do Brasil, a região Norte vem aumentando anualmente a área plantada com culturas agrícolas (soja, milho, sorgo, etc.) por meio de empresas e produtores vindos de regiões tradicionais. Nesse novo cenário, houve aumento da competitividade, pressão ambiental e profissio-nalização/tecnificação das atividades de preparo do solo, plantio, colheita e, em certos casos, pós-colheita. Para fazer frente a essas mudanças, a utilização de sistemas de integração de produção agropecuária e florestal, pela intensificação de áreas já antropizadas, vem contribuindo sobremaneira para a redução da pressão sobre a floresta.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 228](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 228 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0229 — Como os sistemas de integração têm favorecido a atividade pecuária na região Norte?

**Variantes:** Bah, uma dúvida: como os sistemas de integração têm favorecido a atividade pecuária na região Norte? · sistemas integração favorecido atividade pecuária região norte? · como os sisteas de integracao tem favorecido a atividade pecuaria na regiao norte

Os sistemas de integração possibilitam aos produtores rurais uma oportunidade de recuperação de áreas improdutivas ou de baixa produtividade com retorno do investimento em curto prazo por meio de culturas de ciclo curto, ou seja, com a amortização dos custos de recuperação de pastagens degradadas. Além disso, sistemas de integração com componente florestal favorecem o bem-estar animal e a qualidade dos produtos da pecuária.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 229](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 229 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0233 — Quais são os procedimentos práticos para otimização do desempenho de forrageiras tropicais em sistema de ILP?

**Variantes:** Alguém me explica: quais são os procedimentos práticos para otimização do desempenho de forrageiras tropicais em sistema de ILP? · procedimentos práticos otimização desempenho forrageiras tropicais sistema? · quais sao os procedimentos praticos pra otimizacao do desempenho de forrageias tropicais em sistema de ilp

Além da escolha da forrageira, conforme a região e modalidade de uso da pastagem, o produtor deve se cercar de cuidados em relação ao preparo, à correção e à adubação do solo; à qualidade sanitária da semente e semeadura (taxas, métodos, época, profundidade); à competição com os cultivos e as invasoras; e ao manejo (adubação e pastejo) da pastagem para o seu estabelecimento e sua utilização. Nesse processo, a questão mais relevante é a população de plantas da forrageira porque ela afetará a sua capacidade de competição, a velocidade de estabelecimento e a produtividade inicial da pastagem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 233](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 233 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0239 — Qual é o potencial de produtividade das principais forrageiras tropicais em sistema de ILP e ILPF?

**Variantes:** Tchê, me ajuda: qual é o potencial de produtividade das principais forrageiras tropicais em sistema de ILP e ILPF? · potencial produtividade principais forrageiras tropicais sistema ilp? · qual e o potencial de produtividade das principais forrageias tropicais em sistema de ilp e ilpf

O principal modulador da produtividade da forrageira é a fertilidade do solo que passa por melhorias imediatas ou gradativas em sistema de ILP e ILPF visando atender às exigências dos cultivos anuais em rotação. De modo geral, o residual de fertilidade das lavouras e as adubações de manutenção promovem um aumento no patamar de produtividade das pastagens em sistemas integrados em comparação com sistemas convencionais com menor uso de insumos. Além disso, com a adoção de sistemas integrados, normalmente, são agregados ganhos no manejo do sistema de produção que também contribuirão para a elevação do patamar de produtividade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 239](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 239 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0240 — Qual é o método de pastejo mais adequado para sistema de ILP e ILPF?

**Variantes:** Alguém me explica: qual é o método de pastejo mais adequado para sistema de ILP e ILPF? · método pastejo adequado sistema ilp ilpf? · qual e o metodo de pastejo mais adequdo pra sistema de ilp e ilpf

A escolha do método de pastejo vai depender da forrageira a ser utilizada. As braquiárias (Marandú, BRS Piatã, Xaraés, BRS Paiaguás) podem ser manejadas tanto sob pastejo contínuo quanto sob pastejo rotacionado. No entanto, para a utilização mais eficiente e para a produção de forragem de melhor valor nutritivo, recomenda-se o pastejo rotacionado para as cultivares de Panicum maximum (Massai, Mombaça, Tanzânia-1, BRS Zuri). No pastejo rotacionado, há maior controle sobre animais e pastagem, proporcionando maior eficiência de uso da forragem produzida.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 240](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 240 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0245 — Como fazer a dessecação adequada das forrageiras tropicais visando ao sistema de plantio direto (SPD) em sistema de ILP e ILPF?

**Variantes:** Me explica uma coisa: como fazer a dessecação adequada das forrageiras tropicais visando ao sistema de plantio direto (SPD) em sistema de ILP e ILPF? · dessecação adequada forrageiras tropicais visando sistema plantio? · como fazer a dessecaao adequada das forrageiras tropicais visando ao sistema de plantio direto (spd) em sistema de ilp e ilpf

Em regiões com estação seca menos prolongada, a aplicação do herbicida dessecante deve ser realizada entre 15 e 30 dias antes da semeadura da lavoura, de acordo com a sensibilidade da forrageira utilizada. Esse tempo será necessário para a efetiva dessecação (morte) da forrageira, melhorando a plantabilidade da lavoura subsequente, sem riscos de atrasos ou necessidade de reaplicações. Para regiões com estação seca muito prolongada, em que as plantas forrageiras se apresentam com poucos tecidos verdes ou como feno em pé, ao final da estação seca, uma estratégia de manejo é a realização de um rebaixamento da pastagem, seja utilizando um pastejo intenso ou o corte mecanizado (roçada).

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 245](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 245 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico. Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico.

### SUST-ILPF-0253 — Como pode ser amenizada a estacionalidade na produção de pasto em propriedades que adotam sistema de ILP?

**Variantes:** Tchê, me ajuda: como pode ser amenizada a estacionalidade na produção de pasto em propriedades que adotam sistema de ILP? · amenizada estacionalidade produção pasto propriedades adotam sistema? · como pode ser amenizada a estacionalidde na producao de pasto em propriedades q adotam sistema de ilp

Considerando a propriedade como um todo, a falta de forragem durante o período seco pode ser contornada com a programação de rotação de áreas com sistema de ILP, que proporcionam pastagem de alta qualidade nesse período, desafogando as pastagens mais velhas e ampliando a capacidade de suporte da propriedade. Uma possibilidade é a divisão da propriedade em cinco talhões, de modo que, durante o verão, um talhão (ou 20% da área) seja utilizado com lavouras, e, durante a época seca, estes tenham 20% da área com pastagem nova. Assim, em um período de 5 anos, todas as áreas com pastagens da propriedade serão renovadas, podendo-se iniciar um novo ciclo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 253](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 253 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0254 — Qual é o período crítico de disponibilidade de pasto em sistema de ILP?

**Variantes:** Me tira uma dúvida: qual é o período crítico de disponibilidade de pasto em sistema de ILP? · período crítico disponibilidade pasto sistema ilp? · qual e o periodo critico de disponibilidde de pasto em sistema de ilp

Pode ocorrer falta de pasto em sistema de ILP nos períodos de transição lavoura-pastagem e pastagem-lavoura. O primeiro pastejo pode sofrer atrasos, em razão da colheita da soja tardia, do uso de sementes forrageiras de baixa qualidade, da baixa disponibilidade de água no solo, do ataque de pragas e do uso de forrageiras inadequadas. No final da estação seca, muitas pastagens anuais devem ser vedadas para dessecação e retorno das culturas em sequência. Em alguns anos, o desempenho dos animais pode ser inferior ao esperado, seja em virtude do baixo padrão genético do lote ou de problemas meteorológicos, como baixa precipitação ou ocorrência de geada. Esse fato pode comprometer o planejamento da rotação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SOJ-015
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 254](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 254 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0256 — Quais são as principais espécies forrageiras subtropicais recomendadas e utilizadas em sistema de integração lavoura-pecuária (ILP) e qual é a produtividade média de matéria seca (MS)?

**Variantes:** Me explica uma coisa: quais são as principais espécies forrageiras subtropicais recomendadas e utilizadas em sistema de integração lavoura-pecuária (ILP) e qual é a produtividade média de matéria seca (MS)? · principais espécies forrageiras subtropicais recomendadas utilizadas sistema? · quais sao as principis especies forrageiras subtropicais recomendadas e utilizadas em sistema de integracao lavoura-pecuaria (ilp) e qual e a produtividade media de materia seca (ms)

As principais espécies forrageiras de inverno indicadas para comporem sistema de ILP em regiões subtropicais são: aveia preta (Avena strigosa), azevém (Lolium multiflorum), as leguminosas anuais como a ervilhaca (Vicia spp.) e o trevo vesiculoso (Trifolium vesiculosum), e as leguminosas perenes como o trevo branco (Trifolium repens) e cornichão (Lotus corniculatus). Os cereais de inverno de duplo propósito (forragem e grãos) como o trigo (Triticum aestivum), a aveia branca (Avena sativa), o centeio (Secale cereale), o triticale (x Triticosecale) e a cevada (Hordeum vulgare) têm aumentado a participação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 256](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 256 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0257 — Qual é o manejo das pastagens anuais de inverno em sistema de ILP com soja cultivada em sucessão?

**Variantes:** Uma pergunta: qual é o manejo das pastagens anuais de inverno em sistema de ILP com soja cultivada em sucessão? · manejo pastagens anuais inverno sistema ilp soja? · qual e o manejo das pastagns anuais de inverno em sistema de ilp com soja cultivada em sucessao

A pastagem de inverno mais utilizada na região subtropical brasileira é composta por aveia preta e azevém (Lolium multiflorum Lam.). Essas forrageiras são estabelecidas no início do outono e, cerca de 60 dias após a semeadura, atingem estatura de 20 cm a 30 cm, com acúmulo de forragem superior a 1.000 kg/ha de matéria seca. Pode-se iniciar o pastejo que, no método de lotação contínua, deve manter o pasto nessa faixa de 20 cm a 30 cm, ajustando-se a carga animal ao longo da estação de crescimento. A adubação deve seguir a indicada baseada em análise de solo e, tampouco, deve ser descuidada a cobertura nitrogenada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 257](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 257 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0259 — ILPF: os cereais de inverno de duplo propósito como o trigo substituem as pastagens anuais de aveia preta-azevém?

**Variantes:** Tu sabe me dizer: os cereais de inverno de duplo propósito como o trigo substituem as pastagens anuais de aveia preta-azevém (ilpf)? · cereais inverno duplo propósito trigo substituem pastagens (ilpf)? · os cereais de inverno de duplo proposto como o trigo substituem as pastagens anuais de aveia preta-azevem (ilpf)

Os cereais de duplo propósito são aqueles que inicialmente podem ser desfolhados fornecendo pasto adicional aos das pastagens tradicionais no final de outono e parte do inverno, meses de menor luminosidade e temperaturas baixas que afetam marcadamente a taxa de crescimento das forrageiras de inverno. Assim, há necessidade de áreas maiores para obtenção de forragem em quantidade adequada ao rebanho, quando os cereais de inverno são incluídos no planejamento forrageiro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 259](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 259 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0260 — Quais são as principais espécies forrageiras subtropicais de verão e de inverno recomendadas e utilizadas em sistema de integração pecuária-floresta (IPF)?

**Variantes:** Uma pergunta: quais são as principais espécies forrageiras subtropicais de verão e de inverno recomendadas e utilizadas em sistema de integração pecuária-floresta (IPF)? · principais espécies forrageiras subtropicais verão inverno recomendadas? · quais sao as principais especies forrageiras subtropicis de verao e de inverno recomendadas e utilizadas em sistema de integracao pecuaria-floresta (ipf)

Entre as forrageiras gramíneas tropicais perenes, recomenda-se a grama missioneira gigante (Axonopus catharinensis), a braquiária brizanta, o panicum (cvs. Aruana e Mombaça), a pensacola (Paspalum notatum) e a hemártria (Hemarthria altissima cv. Flórida). Entre as leguminosas tropicais, recomenda-se o amendoim forrageiro (Arachis pintoi cvs. Alqueire ou Amarillo). Para todas essas espécies forrageiras, o nível máximo de sombreamento tolerado para um bom crescimento (medido entre 10 e 14 horas) deve ser de 50% em relação ao sol pleno. Entre as forrageiras de inverno, recomenda-se o azevém anual, aveia branca, aveia preta e o capim lanudo (Holcus lanatus).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 260](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 260 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0264 — ILPF: quais são as recomendações para se estabelecer uma pastagem em sistema de IPF?

**Variantes:** Uma pergunta: quais são as recomendações para se estabelecer uma pastagem em sistema de IPF (ilpf)? · recomendações estabelecer pastagem sistema ipf (ilpf)? · quais sao as recomendaces pra se estabelecer uma pastagem em sistema de ipf (ilpf)

O estabelecimento da pastagem deve ser priorizado no primeiro e segundo anos em um sistema de IPF, quando há pouco sombreamento entre as linhas de árvores, pois a germinação e emergência de sementes e o pegamento de mudas forrageiras são normalmente afetados pelo sombreamento. Os principais problemas de produção e persistência da pastagem observados em sistema de IPF em condições de propriedade rural ocorrem por má formação durante essa fase, principalmente por causa da baixa densidade de plantas forrageiras. Uma alternativa também é estabelecer a pastagem no ano anterior ao plantio das árvores.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 264](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 264 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0267 — ILPF: como melhor manejar a pastagem com animais em um sistema de IPF?

**Variantes:** Tchê, me ajuda: como melhor manejar a pastagem com animais em um sistema de IPF (ilpf)? · melhor manejar pastagem animais sistema ipf (ilpf)? · como melhor manejar a pastaem com animais em um sistema de ipf (ilpf)

Recomenda-se manejar a pastagem com uma carga animal mais leve do que aquelas adotadas em pastagens abertas, tendo em vista que a quantidade de reservas acumuladas da fotossíntese é menor em ambientes sombreados do que a pleno sol. Isso significa adotar uma oferta de forragem de 12% do peso vivo (oferecer 12 kg de matéria seca para cada 100 kg de peso vivo na área). Portanto, a quantidade de matéria seca da forragem deve ser medida em amostras de área conhecida (por exemplo, cortes em quadros de 50 cm x 50 cm) e convertidas para um hectare. Após, então, calcula-se a quantidade de peso vivo necessário por hectare também. Esse procedimento deve ser repetido mensalmente ou estacionalmente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 267](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 267 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0268 — ILPF: qual é o momento de renovação da pastagem em um sistema de IPF e quais são os procedimentos a adotar?

**Variantes:** Tchê, me ajuda: qual é o momento de renovação da pastagem em um sistema de IPF e quais são os procedimentos a adotar (ilpf)? · momento renovação pastagem sistema ipf procedimentos adotar (ilpf)? · qual e o momento de renovaao da pastagem em um sistema de ipf e quais sao os procedimentos a adotar (ilpf)

Em um sistema de IPF, com o desenvolvimento das árvores ao longo do tempo, o sombreamento aumenta, podendo comprometer a produtividade e a persistência da pastagem nas entrelinhas. O primeiro sinal de que a pastagem está se degradando em um sistema de IPF é o amarelecimento das folhas superiores das forrageiras, a diminuição da densidade de plantas forrageiras (número de plantas por m2) em relação à usada na semeadura ou no plantio da área, aumento gradativo da presença de invasoras, ou solo descoberto.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 268](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 268 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0269 — ILPF: quais são os espaçamentos ideais de plantio das árvores em um sistema de IPF?

**Variantes:** Tchê, me ajuda: quais são os espaçamentos ideais de plantio das árvores em um sistema de IPF (ilpf)? · espaçamentos ideais plantio árvores sistema ipf (ilpf)? · quais sao os espacamenos ideais de plantio das arvores em um sistema de ipf (ilpf)

A pesquisa, a assistência técnica oficial e as empresas florestais já testaram diferentes modelos e espaçamentos entre árvores nas latitudes do Sul do Brasil. Dos diferentes estudos e de experiências realizados, conclui-se que o espaçamento entre linhas das árvores, no estabelecimento do sistema, deve ser igual ou superior a 20 m. Nas condições do Sul do Brasil, espaçamentos menores que este têm se mostrado insuficientes para uma persistência da pastagem em longo prazo. É possível adotar plantio de árvores em linhas simples ou em renques de linhas duplas, triplas ou quádruplas, dependendo do objetivo da espécie arbórea e do aproveitamento da madeira.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 269](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 269 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0270 — ILPF: qual é a orientação das linhas de plantio de árvores que mais favorece o crescimento e a persistência da pastagem em um sistema de IPF?

**Variantes:** Alguém me explica: qual é a orientação das linhas de plantio de árvores que mais favorece o crescimento e a persistência da pastagem em um sistema de IPF (ilpf)? · orientação linhas plantio árvores favorece crescimento persistência (ilpf)? · qual e a orientacao das linhas de plantio de arvores q mais favorece o crescimeto e a persistencia da pastagem em um sistema de ipf (ilpf)

O plantio das árvores deve ser feito, preferencialmente, em curvas de nível, especialmente quando existem fatores de riscos à degradação do solo por erosão (elevada declividade, solo descoberto, elevado índice de precipitação local, etc.) ou preocupações em relação à conservação da água no solo. Entretanto, em casos de baixo risco de degradação do solo, é possível realizar o plantio linear em linhas. Nesse caso, para a região Sul do Brasil, a pesquisa tem observado que a orientação leste-oeste favorece sistemas integrados com forrageiras de verão. Ao contrário, o plantio na orientação norte-sul favorece sistemas que envolvem forrageiras de clima temperado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 270](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 270 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0271 — Quais são as principais espécies forrageiras subtropicais recomendadas para sistema de ILP em solos hidromórficos onde predomina o cultivo de arroz irrigado manejo geral desse sistema?

**Variantes:** Me explica uma coisa: quais são as principais espécies forrageiras subtropicais recomendadas para sistema de ILP em solos hidromórficos onde predomina o cultivo de arroz irrigado manejo geral desse sistema? · principais espécies forrageiras subtropicais recomendadas sistema ilp? · quais sao as principis especies forrageiras subtropicais recomendadas pra sistema de ilp em solos hidromorficos onde predomina o cultivo de arroz irrigado manejo geral desse sistema

As principais espécies forrageiras utilizadas nesse sistema de ILP, durante o período de pousio da lavoura de arroz irrigado, são as de inverno; e a mais recomendada é o azevém anual, de preferência de ciclo mais longo, visando prolongar seu uso em pastejo até meados da primavera. Em consorciação ao azevém, recomenda-se trevo branco, cornichão, trevo persa ou trevo vermelho. Durante o período de verão, pode ser usado o campo nativo que vem retornando, assim como as espécies anuais capim sudão, sorgo forrageiro ou milheto. O primeiro aspecto a ser considerado é o planejamento de uso das áreas e as oportunidades de renda com a diversificação das atividades.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 271](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 271 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0274 — Quanto tempo se pode pastejar áreas implantadas em sistema de ILP nas terras baixas sem afetar o bom desempenho de forrageiras temperadas/subtropicais?

**Variantes:** Me explica uma coisa: quanto tempo se pode pastejar áreas implantadas em sistema de ILP nas terras baixas sem afetar o bom desempenho de forrageiras temperadas/subtropicais? · tempo pastejar áreas implantadas sistema ilp terras? · quanto tempo se pode pastear areas implantadas em sistema de ilp nas terras baixas sem afetar o bom desempenho de forrageiras temperadas/subtropicais

No primeiro inverno, após a implantação das pastagens na sucessão da cultura do arroz, o início do pastejo poderá ocorrer entre 40 e 60 dias após a semeadura das forrageiras (maio-junho), desde que sejam observadas as recomendações técnicas de incorporação da palhada do arroz, drenagem do terreno e recuperação da fertilidade do solo. Quando não são observadas essas recomendações, o início do pastejo vai ocorrer entre 120 e 150 dias após a semeadura, o que se dará entre agosto e setembro. Nesse primeiro ano, o tempo de pastejo poderá ser de 60 ou de 120 dias ou mais, em razão do manejo empregado pelos produtores.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 274](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 274 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0276 — Qual é o manejo do pastejo e do pastoreio em sistema de ILP nas áreas de terras baixas, com predominância dos solos hidromórficos?

**Variantes:** Bah, uma dúvida: qual é o manejo do pastejo e do pastoreio em sistema de ILP nas áreas de terras baixas, com predominância dos solos hidromórficos? · manejo pastejo pastoreio sistema ilp áreas terras? · qual e o manejo do pastejo e do pastorio em sistema de ilp nas areas de terras baixas, com predominancia dos solos hidromorficos

O primeiro ponto destacado deve ser as condições de manejo do solo e rotações de áreas visando a melhor adequação para que as pastagens de inverno e de verão atinjam seu máximo crescimento nesses ambientes. Após acúmulo de forragem, é importante ajustar o nível de oferta de forragem aos animais, em torno de três a quatro vezes o consumo, isso vai determinar maior sobra de pasto, e, como consequência, proteger o solo do impacto dos animais e dar uma boa cobertura de palhada visando ao plantio direto de qualidade das culturas em sucessão.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 276](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 276 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0279 — Como as forrageiras, em sistema de ILP nos solos hidromórficos, podem reduzir a emissão dos gases de efeito estufa (GEE), atendendo aos preceitos do plano e do Programa ABC?

**Variantes:** Uma pergunta: como as forrageiras, em sistema de ILP nos solos hidromórficos, podem reduzir a emissão dos gases de efeito estufa (GEE), atendendo aos preceitos do plano e do Programa ABC? · forrageiras sistema ilp solos hidromórficos reduzir emissão? · como as forrageiras, em sistema de ilp nos solos hidromorficos, podem reduzir a emissao dos gases de efeito estufa (gee), atendendo aos preceitos do plano e do progrma abc

Nesses ambientes, após a cultura do arroz irrigado, é necessário drenagem e incorporação da palhada ao solo visando a sua estruturação, aumento de matéria orgânica do solo (MOS) e redução de emissão de metano (CH4) ao ambiente. Para que isso ocorra, é necessária a cobertura permanente do solo, o que é realizada pelas pastagens de inverno e verão, durante os períodos de pousio da cultura do arroz.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 279](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 279 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0280 — Para uso das pastagens em sistema de ILP para terras baixas da região Sul, qual sistema de produção animal é mais indicado, leite ou corte?

**Variantes:** Me tira uma dúvida: para uso das pastagens em sistema de ILP para terras baixas da região Sul, qual sistema de produção animal é mais indicado, leite ou corte? · uso pastagens sistema ilp terras baixas região? · para uso das pastagens em sistema de ilp pra terras baixas da regiao sul, qual sistema de produao animal e mais indicado, leite ou corte

A definição da produção animal dependerá dos objetivos da propriedade, da escala de produção, do tamanho da área, do nível de investimento e planejamento. Em pequenas propriedades, o leite é a atividade mais utilizada e é mais recomendada pela rentabilidade e pelo manejo familiar. No entanto, há modelos em grande escala com alto nível de profissionalização e com alta eficiência produtiva. O uso das pastagens em sistema de ILP nessas regiões, de forma geral, é mais comum com a bovinocultura de corte e em sistemas mais especialistas, em que a recria e a terminação de animais são mais indicadas, considerando o período de uso das pastagens de inverno e de verão em modelos que as utilizem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 280](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 280 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0282 — Quais são as raças de bovinos leiteiros que melhor se adaptam ou melhor respondem em termos de produtividade às condições de sistema de ILPF?

**Variantes:** Me explica uma coisa: quais são as raças de bovinos leiteiros que melhor se adaptam ou melhor respondem em termos de produtividade às condições de sistema de ILPF? · raças bovinos leiteiros melhor adaptam melhor respondem? · quais sao as racas de bovinos leiteios q melhor se adaptam ou melhor respondem em termos de produtividade as condicoes de sistema de ilpf

Raças especializadas em leite são as mais adequadas para esses sistemas, como, por exemplo, Holandesa, Jersey, Girolando, etc. A utilização de gado de baixo potencial produtivo, mestiços com raças de corte ou animais com eficiência produtiva e reprodutiva comprometida, traze um baixo aproveitamento do sistema e, com isso, ineficiência econômica. O sistema de ILPF é misto e complexo e exige conhecimento técnico para sua plena execução. Por outro lado, é um sistema completo que proporciona aos animais uma pastagem produtiva com sombreamento, amenizando o estresse pelo calor. Nesse sistema, é produzida a lavoura, normalmente, milho ou sorgo para silagem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 282](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 282 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0283 — Como deve ser feito o manejo das vacas leiteiras em sistema de integração?

**Variantes:** Tu sabe me dizer: como deve ser feito o manejo das vacas leiteiras em sistema de integração? · feito manejo vacas leiteiras sistema integração? · como deve ser feito o manejo das vacas leiteiras em sistema de integraao

O manejo das vacas leiteiras é um ponto chave em sistema de integração, principalmente o manejo alimentar. Como a produção de alimentos é diversificada em sistema de integração, há a necessidade de classificar os alimentos produzidos por qualidade e custo, assim como o grupo de animais conforme sua produção e exigência nutricional. Com esse escalonamento, o produtor faz a combinação entre lotes, em que os menos exigentes recebem alimentos mais baratos e de qualidade inferior, e lotes mais exigentes recebem alimentos de custo mais elevado e/ou qualidade superior.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 283](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 283 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Orientação técnica geral: recomendar confirmar com agrônomo, veterinário ou Emater para o caso específico.

### SUST-ILPF-0284 — Como ocorre o manejo das pastagens em sistema de integração piquetes nesse tipo de sistema?

**Variantes:** Me explica uma coisa: como ocorre o manejo das pastagens em sistema de integração piquetes nesse tipo de sistema? · ocorre manejo pastagens sistema integração piquetes nesse? · como ocorre o manejo das pastagns em sistema de integracao piquetes nesse tipo de sistema

O manejo de pastagens deve ocorrer quando ela atingir uma determinada altura dependendo da espécie, que é correspondente a 95% da interceptação luminosa. Na prática, o produtor deverá entrar com os animais na pastagem de Panicum maximum cv. Mombaça, por exemplo, quando esta estiver com 90 cm de altura, ao passo que, em outras cultivares da mesma espécie, as alturas variam, como, por exemplo: Tanzânia-1, 70 cm; Massai, 50 cm. Para a Urochloa brizantha (syn.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 284](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 284 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0287 — Como se dá a escolha dos componentes no sistema de ILPF visando à produção de leite?

**Variantes:** Uma pergunta: como se dá a escolha dos componentes no sistema de ILPF visando à produção de leite? · dá escolha componentes sistema ilpf visando produção? · como se da a escolha dos componenes no sistema de ilpf visando a producao de leite

O milho para silagem apresenta altas produtividades, bom valor nutritivo e facilidade de cultivo, sendo uma cultura tradicionalmente utilizada com esse viés. As gramíneas africanas são escolhidas por apresentarem adaptação às condições edafoclimáticas da região. O eucalipto, por ser uma planta que se adapta ao clima e aos solos, possui demanda de mercado, crescimento rápido, copa alta e pouca densidade; além disso, não apresenta efeitos negativos sobre pastagens, lavoura e animais. Além dessas características, é importante lembrar que há muito conhecimento técnico para o manejo do eucalipto, ao contrário das outras culturas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 287](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 287 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0292 — Por que não há necessidade de adubação convencional na implantação da pastagem nos sistemas de integração?

**Variantes:** Uma pergunta: por que não há necessidade de adubação convencional na implantação da pastagem nos sistemas de integração? · não necessidade adubação convencional implantação pastagem sistemas? · pq n ha necessidade de adubacao convencioal na implantacao da pastagem nos sistemas de integracao

Como o plantio da forrageira é realizado junto com a semeadura do milho, não há necessidade de considerar o manejo de estabelecimento da pastagem de forma tradicional. Na implantação do sistema de ILPF, a lavoura, no caso o milho, é o foco da produção devido ao ciclo curto; portanto, é necessário garantir a produtividade do milho para a ensilagem, ou mesmo para grãos a serem vendidos ou mesmo para uso na mistura da ração na própria fazenda. É importante salientar que o correto manejo da calagem e da adubação para a cultura do milho já garantirá os nutrientes necessários para o desenvolvimento da forrageira a ser utilizada para o pastejo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 292](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 292 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0293 — Como é realizada a calagem na implantação da pastagem em sistema de ILPF?

**Variantes:** Uma pergunta: como é realizada a calagem na implantação da pastagem em sistema de ILPF? · realizada calagem implantação pastagem sistema ilpf? · como e realizada a calagem na implantacao da pastaem em sistema de ilpf

Em relação à correção da acidez do solo, a calagem de uma área a ser utilizada com o sistema de ILPF é feita com base na recomendação para a cultura (utilizada para a produção de grãos ou de silagem) a ser implantada. No caso de sistema cujo objeto principal será a exploração de leite, o milho ou o sorgo para a silagem são as culturas mais indicadas como recurso forrageiro a ser ensilado e utilizado como volumoso e devem ser fornecidos no cocho aos animais na época da seca, quando a escassez de alimentos volumosos se agrava. Dessa forma, a recomendação de calagem para essas culturas atende perfeitamente tanto à pastagem quanto à espécie arbórea.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 293](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 293 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0296 — Como é feita a adubação de cobertura/manutenção do componente pastagem, em sistema de integração?

**Variantes:** Me explica uma coisa: como é feita a adubação de cobertura/manutenção do componente pastagem, em sistema de integração? · feita adubação cobertura manutenção componente pastagem sistema? · como e feita a adubacao de cobertura/manutencao do componente pastagem, em sistema de integraao

Se a pastagem for dessecada a cada ano para novo plantio de uma cultura, para ser ensilada ou para colheita de grão (lavoura), a quantidade de adubo de cobertura a ser utilizado deverá ser proporcional ao tempo de permanência dessa pastagem na área. Caso não seja feito anualmente novo plantio da lavoura, a quantidade de adubo de cobertura a ser aplicado deverá considerar o intervalo de 1 ano, sempre com base nos resultados de análise de solo e na resposta da forrageira utilizada para pastejo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 296](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 296 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0303 — ILPF: quais são os fatores que favorecem o aumento das populações de plantas daninhas em pastagens?

**Variantes:** Uma pergunta: quais são os fatores que favorecem o aumento das populações de plantas daninhas em pastagens (ilpf)? · fatores favorecem aumento populações plantas daninhas pastagens (ilpf)? · quais sao os fatores q favorecem o aumento das populacoes de plantas daninas em pastagens (ilpf)

Nas pastagens naturais ou implantadas, os animais tendem a procurar as plantas mais palatáveis. Alimentam-se da espécie forrageira, deixando de lado as plantas daninhas, que, completam seu ciclo, aumentando o banco de sementes do solo. Os principais fatores que influenciam na dinâmica das populações de espécies daninhas são: • Adaptabilidade da espécie forrageira: espécies forrageiras pouco adaptadas às condições edafoclimáticas de cada região não produzem massa de matéria verde suficiente para cobrir os espaços livres do solo. Com o passar do tempo, as plantas daninhas vão ocupando esses espaços, tornando cada vez mais acirrada a competição.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 303](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 303 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0304 — Quanto tempo após o estabelecimento de uma área com sistema de ILPF com componente florestal vacas leiteiras podem entrar no sistema para pastejo?

**Variantes:** Queria entender: quanto tempo após o estabelecimento de uma área com sistema de ILPF com componente florestal vacas leiteiras podem entrar no sistema para pastejo? · tempo após estabelecimento área sistema ilpf componente? · quanto tempo apos o estabelecimento de uma area com sistema de ilpf com componente florestal vacas leiteias podem entrar no sistema pra pastejo

O plantio das espécies utilizadas em sistema de ILPF, por exemplo, milho (para produção de silagem ou grãos), Urochloa brizantha cv. Marandú e o componente florestal, via de regra o eucalipto, ocorre no mesmo dia. Após a colheita do milho, e passados 30 a 60 dias, a pastagem está em condições de uso pelo animal. Esse uso poderá ser sob condições de pastejo ou ensilado, para uso na época seca do ano, como alternativa volumosa. Se a opção for para o uso sob a forma de silagem, após o corte, e passados outros 30 a 60 dias, a gramínea poderá ser pastejada. O pastejo, no primeiro ano de implantação do sistema, só poderá ser realizado mediante a proteção das linhas de plantio do eucalipto.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 304](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 304 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0313 — Quais são as atividades pecuárias mais indicadas para sistema de integração, e em que condições?

**Variantes:** Tu sabe me dizer: quais são as atividades pecuárias mais indicadas para sistema de integração, e em que condições? · atividades pecuárias indicadas sistema integração condições? · quais sao as atividades pecuaras mais indicadas pra sistema de integracao, e em q condicoes

Em sistema de ILP e ILPF, podem ser exploradas diversas formas de atividades de pecuária, em função das características produtivas da região, das condições locais e do interesse e conhecimento do produtor. Em região onde predomina a pecuária de corte, como o Centro-Oeste, são mais utilizados os sistemas de exploração de bovinos de corte, com as suas fases características de cria, recria e engorda; mas, de modo geral, o mais comumente utilizado é a recria-engorda com produção de bovinos precoces, pela facilidade de aquisição de animais de criadores locais. Isso também é frequente nas regiões Sudeste e Sul.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 313](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 313 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0315 — Em que regiões brasileiras já existem experiências de sucesso com a adoção da estratégia de ILPF em propriedades de pecuária de corte?

**Variantes:** Uma pergunta: em que regiões brasileiras já existem experiências de sucesso com a adoção da estratégia de ILPF em propriedades de pecuária de corte? · regiões brasileiras experiências sucesso adoção estratégia ilpf? · em q regioes brasileiras ja existem experiencias de sucesso com a adocao da estrategia de ilpf em propriedaes de pecuaria de corte

Praticamente em todas as regiões do Brasil. Destacam-se propriedades rurais nos estados do Mato Grosso do Sul, Mato Grosso, Paraná, Rio Grande do Sul, Goiás, Minas Gerais, Tocantins, Maranhão, Bahia e Pará.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 315](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 315 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0316 — ILPF: quais são os índices de produtividade (agronômica, zootécnica e florestal) observados nestas propriedades?

**Variantes:** Bah, uma dúvida: quais são os índices de produtividade (agronômica, zootécnica e florestal) observados nestas propriedades (ilpf)? · índices produtividade agronômica zootécnica florestal observados nestas (ilpf)? · quais sao os indices de produtividade (agronomica, zootecnica e florestal) observaos nestas propriedades (ilpf)

De modo geral, os índices de produtividade são semelhantes ou até superiores aos sistemas convencionais. A produção de grãos de soja e milho, por exemplo, em muitos casos são maiores em sistema de ILP, pois o seu cultivo sobre forrageiras proporcionam melhores condições para o sistema de plantio direto (SPD) e, portanto, tem melhor estabilidade produtiva. Por exemplo, no Mato Grosso do Sul e no Mato Grosso, as produtividades de soja têm sido de 45 sacas/ha a 65 sacas/ha em condições razoáveis a boas. O milho safra tem resultado em produtividades de 90 sacas/ha a 130 sacas/ha em boas condições.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 316](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 316 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0318 — Quais são os principais usos da floresta cultivada em sistema de ILPF?

**Variantes:** Tu sabe me dizer: quais são os principais usos da floresta cultivada em sistema de ILPF? · principais usos floresta cultivada sistema ilpf? · quais sao os principais usos da floreta cultivada em sistema de ilpf

O plantio de árvores no sistema de ILPF deve ter como objetivo principal a produção de toras de madeira, para uso mais nobre como: madeira serrada, laminação, componentes para móveis, produtos de maior valor agregado (portas, portais, janelas e móveis), postes, entre outros. No entanto, desbastes devem ser realizados durante o ciclo de condução do sistema, que gerarão madeira para usos mais comuns, como lenha, carvão, madeira para construções (escoras, postes de menor tamanho, mourões), madeira para a produção de aglomerados, chapas de fibra e celulose. O destino da madeira obtida nos desbastes será em função, principalmente, da distância da propriedade rural do centro consumidor.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 318](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 318 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0321 — ILPF: quais são as principais vantagens da utilização do sistema São Mateus para a pecuária de corte?

**Variantes:** Me tira uma dúvida: quais são as principais vantagens da utilização do sistema São Mateus para a pecuária de corte (ilpf)? · principais vantagens utilização sistema mateus pecuária corte (ilpf)? · quais sao as principais vantagens da utilizacao do sistema sao mateus pra a pecuaia de corte (ilpf)

A utilização da pastagem de boa qualidade por 6 a 9 meses antes do plantio das lavouras de grãos poderá produzir 8 arrobas/ha a 12 arrobas/ha de equivalente carcaça de carne, aumentando a rentabilidade da pecuária, como também proporcionar a adequação química e física do solo. A produção de palhada para o plantio direto reduz os riscos climáticos, aumentando a produtividade da soja em 3 sacas/ha a 12 sacas/ha em relação ao sistema tradicional, podendo obter lucro já no primeiro ano de cultivo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 321](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 321 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0322 — Quais são os principais problemas enfrentados pela grande maioria de técnicos e produtores rurais, na adoção de sistema de ILP de forma tradicional?

**Variantes:** Bah, uma dúvida: quais são os principais problemas enfrentados pela grande maioria de técnicos e produtores rurais, na adoção de sistema de ILP de forma tradicional? · principais problemas enfrentados grande maioria técnicos produtores? · quais sao os principis problemas enfrentados pela grande maioria de tecnicos e produtores rurais, na adocao de sistema de ilp de forma tradicional

São observadas frequentes frustrações na produtividade de lavouras de soja, feijão e milho quando elas são desenvolvidas de forma tradicional, com preparo do solo e aplicação de corretivos (calcário, gesso e fósforo) no período seco do ano, que geralmente ocorre de maio a setembro, não possibilitando a reação dos corretivos. Com o plantio das culturas de grãos em solos ácidos, de baixa fertilidade e sem palhada para o plantio direto, normalmente obtêm-se baixas produtividades de grãos e que não remuneram os custos de produção no primeiro ano de cultivo, desestimulando os produtores a realizarem a recuperação das pastagens com o uso de sistema de ILP.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 322](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 322 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0346 — ILPF: quanto do pasto pode ser sombreado, sem que ocorra perda de produtividade?

**Variantes:** Me explica uma coisa: quanto do pasto pode ser sombreado, sem que ocorra perda de produtividade (ilpf)? · pasto sombreado ocorra perda produtividade (ilpf)? · quanto do pasto pode ser sombreado, sem q ocorra perda de produtividde (ilpf)

Em pastagens adequadamente arborizadas, a cobertura de copa das árvores deve estar entre 10% e 40%, para não comprometer a produção da pastagem, e dependerá muito da densidade e altura de inserção da copa. Ainda não há consenso na literatura em relação à quantidade de sombreamento da pastagem que é recomendada. É provável que, na região Norte do país, a cobertura de copa possa ser maior do que nos estados do Sul e Sudeste, mas fatores como, características morfológicas das espécies utilizadas e altura de desrama podem também influenciar a taxa de cobertura aceitável. Na prática, consegue-se fazer desrama até 6 m ou 7 m de altura, caso seja realizada por pessoa no piso do sistema.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 346](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 346 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0357 — ILPF: como ocorrem as emissões de GEE provocadas pelo setor agropecuário?

**Variantes:** Uma pergunta: como ocorrem as emissões de GEE provocadas pelo setor agropecuário (ilpf)? · ocorrem emissões gee provocadas setor agropecuário (ilpf)? · como ocorrem as emissoes de gee provocadas pelo setor agropecuaio (ilpf)

As atividades agropecuárias geram emissões diretas e indiretas de GEE por diversos processos, tais como: fermentação entérica dos alimentos nos herbívoros ruminantes (metano), na decomposição de dejetos de animais (metano e óxido nitroso); degradação da matéria orgânica do solo (MOS) ocasionada pelo preparo convencional do solo (CO2 ou dióxido de carbono); decomposição da celulose em condições anaeróbias, como no cultivo de arroz inundado (metano), durante a liberação de carbono proveniente da queima de resíduos agrícolas (dióxido de carbono, metano, óxido nitroso, entre outros); emissão de CO2 e óxido nitroso em solos pelo uso de corretivos e por meio da desnitrificação de fertilizantes nitrogenados; queima pelo consumo de combustíveis fósseis (dióxido de carbono) na produção e no transporte de produtos agrícolas e utilização de insumos que para sua produção demandam consumo de energia na industrialização (fertilizantes, herbicidas, fungicidas).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 357](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 357 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Produtos e registros de defensivos mudam: indicar consulta ao Agrofit/MAPA e receituário agronômico. Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0360 — ILPF: como podem ser reduzidas as emissões de GEE pela agropecuária?

**Variantes:** Me explica uma coisa: como podem ser reduzidas as emissões de GEE pela agropecuária (ilpf)? · reduzidas emissões gee agropecuária (ilpf)? · como podem ser reduzias as emissoes de gee pela agropecuaria (ilpf)

CO2 CO2 Estratégias relevantes para CO2 mitigação ou redução da emissão dos GEE consistem em redução da queima de combustíveis fósseis (petróleo, gasolina, diesel, carvão mineral), minimização de desmatamentos e queimadas, manejo nutricional adequado de animais, manejo adequado das pastagens, manejo adequado do solo e estratégias de maximização das remoções de CO2, popularmente chamadas de sequestro de carbono da atmosfera. Na produção animal, existem estratégias nutricionais que utilizam aditivos específicos, suplementos e dietas balanceadas que podem reduzir a emissão de metano entérico.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 360](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 360 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0361 — ILPF: como ocorre o sequestro de carbono e como essa estratégia pode ajudar na redução de emissões de GEE pela agropecuária?

**Variantes:** Me tira uma dúvida: como ocorre o sequestro de carbono e como essa estratégia pode ajudar na redução de emissões de GEE pela agropecuária (ilpf)? · ocorre sequestro carbono estratégia ajudar redução emissões (ilpf)? · como ocorre o sequestro de carbono e como essa estrategia pode ajudar na reducao de emissoes de gee pela agropecuaia (ilpf)

O sequestro ou remoção do carbono ocorre normalmente pela captura do CO2 da atmosfera pelas plantas verdes que o transforma em compostos orgânicos por meio da fotossíntese. Após esse processo de remoção do carbono da atmosfera e da incorporação pelas plantas verdes, o elemento passa a desempenhar inúmeras funções na formação da biomassa e no metabolismo vegetal, e é o componente de diversos compostos orgânicos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 361](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 361 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0362 — ILPF: como os sistemas de produção podem mitigar ou reduzir as emissões de GEE?

**Variantes:** Queria entender: como os sistemas de produção podem mitigar ou reduzir as emissões de GEE (ilpf)? · sistemas produção mitigar reduzir emissões gee (ilpf)? · como os sisteas de producao podem mitigar ou reduzir as emissoes de gee (ilpf)

O acúmulo de MOS no sistema de plantio direto (SPD) e nos sistemas de integração, como a integração lavoura-pecuária (ILP) e o sistema de ILPF, bem como o seu potencial para a remoção de CO2, já foram comprovados por vários trabalhos de pesquisa nas diferentes regiões e biomas brasileiros. Solos manejados sob SPD e sistemas integrados passam da condição de fonte de CO2 rumo à atmosfera para a condição de dreno ou assimilação de CO2 para o solo e biomassa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 362](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 362 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0363 — Qual é o potencial de sequestro de carbono de sistemas de integração nos diferentes biomas brasileiros?

**Variantes:** Uma pergunta: qual é o potencial de sequestro de carbono de sistemas de integração nos diferentes biomas brasileiros? · potencial sequestro carbono sistemas integração diferentes biomas? · qual e o potencial de sequestro de carbono de sistemas de integracao nos diferenes biomas brasileiros

O incremento nos estoques de carbono do solo provenientes da adoção de sistemas de ILP sob SPD é maior quando comparados aos de áreas sob SPD sem a presença da pecuária ou quando a forrageira é utilizada somente para produção de palhada. A elevação dos níveis de MOS e a melhoria da qualidade física do solo com a introdução das pastagens em áreas agrícolas demonstram que o sistema de ILP tem potencial para reduzir o impacto ambiental das atividades produtivas, reduzindo as emissões de GEE.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 363](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 363 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0364 — Como é a dinâmica dos incrementos de carbono no sistema de ILP?

**Variantes:** Queria entender: como é a dinâmica dos incrementos de carbono no sistema de ILP? · dinâmica incrementos carbono sistema ilp? · como e a dinamica dos incremenos de carbono no sistema de ilp

Normalmente, o sistema de ILP é implantado por meio da sucessão de cultura anual com forrageira anual ou perene; do consórcio de culturas anuais com forrageiras (ex.: sistema Santa Fé); ou da rotação de cultura anual com forrageira perene (ex.: sistema São Mateus). De uma forma geral, o que se tem é a presença do componente forrageiro (intercalado com culturas anuais) por um período que pode variar de alguns meses (por exemplo, na entressafra seca ou no inverno) a alguns anos, dependendo do sistema adotado na fazenda. Nesse sentido, o componente forrageiro é utilizado para pastejo e produção animal por um período e pode ser transformado em palhada para o SPD da cultura subsequente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 364](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 364 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0369 — Quais são as políticas de fomento para adoção de sistemas integrados visando à mitigação de emissões de GEE, as quais podem contribuir para uma agricultura e pecuária mais sustentáveis?

**Variantes:** Uma pergunta: quais são as políticas de fomento para adoção de sistemas integrados visando à mitigação de emissões de GEE, as quais podem contribuir para uma agricultura e pecuária mais sustentáveis? · políticas fomento adoção sistemas integrados visando mitigação? · quais sao as politicas de fomento pra adocao de sistemas integrados visando a mitigacao de emissoes de gee, as quais podem contribuir pra uma agricultra e pecuaria mais sustentaveis

Na 15ª Conferência das Partes (COP-15), realizada no ano de 2009, em Copenhague, Dinamarca, com o intuito de informar as Partes da Convenção, o governo brasileiro indicou um compromisso nacional voluntário, mais conhecido como Ações de Mitigação Nacionalmente Apropriadas – em inglês, Nationally Appropriate Mitigation Actions (Nama) –, com potencial da redução das emissões de GEE entre 36,1% e 38,9% em relação às emissões brasileiras projetadas até 2020. Para tanto, está implantando diferentes ações em diversos setores da economia.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007, VIS-006
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 369](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 369 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0372 — Como os sistemas de integração são fomentados no Plano ABC?

**Variantes:** Queria entender: como os sistemas de integração são fomentados no Plano ABC? · sistemas integração fomentados plano abc? · como os sistemas de integracao sao fomentaos no plano abc

Os sistemas de integração (ILP, IPF, ILF e ILPF) aparecem como tecnologias elencadas para compor os compromissos brasileiros de redução de emissões específicas para o setor agropecuário. Dessa forma, a contribuição de sistemas de integração na mitigação de GEE ocorrerá pela expansão de área de adoção desses sistemas em 4 milhões de hectares até 2020. Para tal, e como as demais tecnologias do Plano ABC, existem várias ações planejadas visando a esse aumento da adoção de sistemas de integração nas diferentes regiões brasileiras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 372](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 372 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0407 — ILPF: quais são as regiões onde há ocorrência significativa de solos arenosos no Brasil?

**Variantes:** Queria entender: quais são as regiões onde há ocorrência significativa de solos arenosos no Brasil (ilpf)? · regiões ocorrência significativa solos arenosos brasil (ilpf)? · quais sao as regioes onde ha ocorrenia significativa de solos arenosos no brasil (ilpf)

Os solos arenosos ocorrem em praticamente todo o território nacional e são encontrados de sul a norte do País. Ocupam uma extensa faixa, que vai do noroeste de Minas Gerais, oeste da Bahia, Tocantins, Mato Grosso do Sul, Mato Grosso, sul do Piauí e do Maranhão e nordeste do Pará. Predominam em paisagens com relevo de plano a ondulado suave e normalmente ocupam as chapadas e depressões. São solos importantes também nas áreas de fronteira agrícola e tradicionais de pecuária, localizadas nos estados do Maranhão, do Tocantins, do Piauí, da Bahia, de Goiás, de Mato Grosso do Sul e de Mato Grosso, ocupados também com pastagens degradadas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 407](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 407 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Pergunta original do livro sem menção explícita ao tema; prefixo "ILPF" adicionado para dar contexto.

### SUST-ILPF-0430 — Quais espécies de braquiária são mais utilizadas e recomendadas como condicionadoras de solo sob ILP e ILPF?

**Variantes:** Queria entender: quais espécies de braquiária são mais utilizadas e recomendadas como condicionadoras de solo sob ILP e ILPF? · espécies braquiária utilizadas recomendadas condicionadoras solo sob? · quais especies de braquiaria sao mais utilizadas e recomendadas como condicionadoas de solo sob ilp e ilpf

Entre as espécies comumente utilizadas, as braquiárias U. decumbens, U. brizantha e U. ruziziensis têm se destacado pela elevada capacidade de produção de massa de matéria seca, tolerância à deficiência hídrica, absorção de nutrientes em camadas mais profundas do solo e reciclagem de nutrientes, desenvolvendo-se em condições ambientais em que a maioria das culturas produtoras de grãos e das espécies utilizadas para cobertura do solo não se desenvolveriam, garantindo-as como excelentes alternativas para a produção de fitomassa durante a entressafra de regiões de inverno seco. No entanto, não só essas espécies podem trazer benefícios múltiplos ao solo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 430](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 430 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0445 — Por que se deve cultivar braquiária em consórcio com milho ou sorgo no sistema de ILP com culturas de menor porte, como soja, arroz ou feijão?

**Variantes:** Alguém me explica: por que se deve cultivar braquiária em consórcio com milho ou sorgo no sistema de ILP com culturas de menor porte, como soja, arroz ou feijão? · cultivar braquiária consórcio milho sorgo sistema ilp? · pq se deve cultiar braquiaria em consorcio com milho ou sorgo no sistema de ilp com culturas de menor porte, como soja, arroz ou feijao

O cultivo consorciado de milho com braquiária no sistema de ILP e ILPF já é bem conhecido e proporciona exploração do solo por raízes de diferentes diâmetros e exigências de fertilidade e umidade, crescendo em profundidade, durante o ano todo e deixando mais poroso o solo. Além disso, é uma forma de introduzir as forrageiras no sistema de produção sem deixar de produzir grãos, ou seja, utiliza-se a janela de plantio para duas culturas, sendo uma delas graníferas e de maior retorno econômico. É uma forma mais eficiente de uso da terra.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 445](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 445 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

### SUST-ILPF-0468 — Quais são as linhas de crédito disponíveis para o produtor rural financiar a implantação do sistema de integração?

**Variantes:** Bah, uma dúvida: quais são as linhas de crédito disponíveis para o produtor rural financiar a implantação do sistema de integração? · linhas crédito disponíveis produtor rural financiar implantação? · quais sao as linhas de credito disponiveis pra o produtor rural financiar a implantaao do sistema de integracao

O produtor rural pode optar pelo Programa de Agricultura de Baixa Emissão de Carbono (ABC), que é uma linha de crédito rural oficial, instituída em 17 de agosto de 2010 pelo Ministério da Agricultura, Pecuária e Abastecimento (Mapa), a qual foi inserida já no Plano Safra 2010–2011 com valor disponibilizado de R$ 2 bilhões. As linhas de crédito do Programa ABC têm a finalidade de financiar a recuperação de áreas e pastagens degradadas, a implantação de sistemas de ILP, ILF, IPF ou ILPF, bem como a adoção de sistema de plantio direto (SPD), florestas plantadas, fixação biológica de nitrogênio (FBN), entre outros.

*kind:* `dado` · *status:* `parcial` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 468](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 468 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Contém números/estatísticas de 2015 ou anteriores: dizer "segundo a Embrapa, em publicação de 2015" e avisar que podem estar desatualizados; para dados atuais usar IBGE/Conab.
*Lacunas:* Atualizar estatísticas de 2015 com fonte recente (IBGE/Conab)

### SUST-ILPF-0469 — Quais são os itens financiáveis e as condições para acessar linhas de créditos que financiam projetos de ILP e de ILPF?

**Variantes:** Uma pergunta: quais são os itens financiáveis e as condições para acessar linhas de créditos que financiam projetos de ILP e de ILPF? · itens financiáveis condições acessar linhas créditos financiam? · quais sao os itens financiavis e as condicoes pra acessar linhas de creditos q financiam projetos de ilp e de ilpf

De acordo com a linha de crédito do Programa ABC, o limite de crédito é de R$ 1 milhão por beneficiário e por ano/safra, independentemente de outros créditos que o produtor ou cooperativa já tenham recebido. Atualmente, a taxa de juros é de 5,5% ao ano e o tempo de carência varia conforme o tipo de financiamento. Por exemplo, a implantação de viveiros de mudas florestais tem carência de 2 anos; para recuperação de pastagens e sistemas de ILP, IPF ou ILPF, o prazo de carência é de 3 anos.

*kind:* `dado` · *status:* `parcial` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 469](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 469 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015). Contém números/estatísticas de 2015 ou anteriores: dizer "segundo a Embrapa, em publicação de 2015" e avisar que podem estar desatualizados; para dados atuais usar IBGE/Conab.
*Lacunas:* Atualizar estatísticas de 2015 com fonte recente (IBGE/Conab)

### SUST-ILPF-0488 — Quais são os objetivos de uma URT de sistemas de integração?

**Variantes:** Tu sabe me dizer: quais são os objetivos de uma URT de sistemas de integração? · objetivos urt sistemas integração? · quais sao os objetivos de uma urt de sistemas de integraao

A URT de sistemas de integração objetiva reproduzir sistemas de produção diversificados de grãos, fibra, carne, leite, lã, produtos florestais madeireiros e não madeireiros, entre outros, realizados na mesma área, em plantio consorciado, em sucessão ou rotação, porém em escala reduzida. Os sistemas devem ser planejados e implantados de forma a maximizar a utilização dos ciclos biológicos das plantas, dos animais e de seus respectivos resíduos, assim como efeitos residuais de corretivos e nutrientes, minimizar/aperfeiçoar a utilização de agroquímicos, aumentar a eficiência no uso de máquinas, equipamentos e mão de obra.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 488](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)
*Notas:* Resposta resumida do item nº 488 do livro da Embrapa "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde" (2015).

## ESG e carbono

### SUST-WK-0001 — O que é sustentabilidade?

**Variantes:** Sustentabilidade: o que significa? · Me explica o que é sustentabilidade · oq é sustentabilidade · sustentabilidade? · Defina sustentabilidade

Sustentabilidade é uma característica ou condição de um processo ou de um sistema que permite a sua permanência, em certo nível, por um determinado prazo. Ultimamente, este conceito tornou-se um princípio segundo o qual o uso dos recursos naturais para a satisfação de necessidades presentes não pode comprometer a satisfação das necessidades das gerações futuras. Este novo princípio foi ampliado para a expressão "sustentabilidade no longo prazo", um "longo prazo" de termo indefinido.[carece de fontes]?

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*KB Fenasoja:* EVT-006
*Fontes:* [Wikipédia (pt) – Sustentabilidade](https://pt.wikipedia.org/wiki/Sustentabilidade) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Sustentabilidade" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0002 — O que é desenvolvimento sustentável?

**Variantes:** Desenvolvimento sustentável: o que significa? · Me explica o que é desenvolvimento sustentável · oq é desenvolvimento sustentavel · desenvolvimento sustentável? · Defina desenvolvimento sustentável

Desenvolvimento sustentável é um conceito sistêmico que se traduz num modelo de desenvolvimento global que incorpora os aspectos de um sistema de consumo em massa no qual a preocupação com a natureza, via de extração da matéria-prima, é máxima. Foi usado pela primeira vez em 1987, no Relatório Brundtland, um relatório elaborado pela Comissão Mundial sobre Meio Ambiente e Desenvolvimento, criada em 1983 pela Assembleia das Nações Unidas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Desenvolvimento sustentável](https://pt.wikipedia.org/wiki/Desenvolvimento_sustent%C3%A1vel) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Desenvolvimento sustentável" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0003 — O que são Objetivos de Desenvolvimento Sustentável?

**Variantes:** Objetivos de Desenvolvimento Sustentável: o que significa? · Me explica o que são Objetivos de Desenvolvimento Sustentável · oq sao objetivos de desenvolvimento sustentavel · Objetivos de Desenvolvimento Sustentável? · Defina Objetivos de Desenvolvimento Sustentável · O que é agenda 2030?

Os Objetivos de Desenvolvimento Sustentável (ODS) (ou Objetivos Mundiais para o Desenvolvimento Sustentável) são uma coleção de 17 metas globais, estabelecidas pela Assembleia Geral das Nações Unidas e o Conselho Econômico das Nações Unidas. Os ODS são parte da Resolução 70/1 da Assembleia Geral das Nações Unidas: "Transformando o nosso mundo: a Agenda 2030 para o Desenvolvimento Sustentável", que depois foi encurtado para Agenda 2030. As metas são amplas e interdependentes, mas cada uma tem uma lista separada de metas a serem alcançadas. Atingir as 169 metas indicaria a realização de todos os 17 objetivos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Objetivos de Desenvolvimento Sustentável](https://pt.wikipedia.org/wiki/Objetivos_de_Desenvolvimento_Sustent%C3%A1vel) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Objetivos de Desenvolvimento Sustentável" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0004 — O que é pegada de carbono?

**Variantes:** Pegada de carbono: o que significa? · Me explica o que é pegada de carbono · oq é pegada de carbono · pegada de carbono? · Defina pegada de carbono

Uma pegada de carbono (ou pegada de gases de efeito estufa) é um valor ou índice calculado que permite comparar a quantidade total de gases do efeito estufa que uma atividade, produto, empresa ou país adiciona à atmosfera. As pegadas de carbono são geralmente relatadas em toneladas de emissões (CO2 equivalente) por unidade de comparação. Essas unidades podem ser, por exemplo, toneladas de CO2 por ano, por quilograma de proteína para consumo, por quilômetro percorrido, por peça de roupa e assim por diante. A pegada de carbono de um produto inclui as emissões para todo o ciclo de vida.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Wikipédia (pt) – Pegada de carbono](https://pt.wikipedia.org/wiki/Pegada_de_carbono) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Pegada de carbono" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0005 — O que é crédito de carbono?

**Variantes:** Crédito de carbono: o que significa? · Me explica o que é crédito de carbono · oq é credito de carbono · crédito de carbono? · Defina crédito de carbono

Créditos de carbono ou Redução Certificada de Emissões (RCE) são certificados emitidos para uma pessoa ou empresa que reduziu a sua emissão de gases do efeito estufa (GEE). Os valores que giram em torno dessa atividade econômica são 0,1% do mercado de títulos. Quando um crédito de carbono é utilizado para compensar uma emissão, ele não pode ser reutilizado Por convenção, 1 tonelada de dióxido de carbono (CO2) corresponde a um crédito de carbono. Este crédito pode ser negociado no mercado internacional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Wikipédia (pt) – Créditos de carbono](https://pt.wikipedia.org/wiki/Cr%C3%A9ditos_de_carbono) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Créditos de carbono" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0006 — O que é mercado de carbono?

**Variantes:** Mercado de carbono: o que significa? · Me explica o que é mercado de carbono · oq é mercado de carbono · mercado de carbono? · Defina mercado de carbono

O comércio de emissões para o dióxido de carbono (CO2) e outros gases estufa (GEE) é uma forma de precificação de carbono, também conhecido como cap and trade (CAT) ou precificação de carbono. É uma abordagem para limitar mudanças climáticas por meio da criação de um mercado com permissões limitadas para emissões. Isso pode diminuir a competitividade dos combustíveis fósseis e acelerar os investimentos em fontes de energia de baixo carbono, como energia eólica e fotovoltaica. Os combustíveis fósseis são o principal motor para a mudança climática.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Wikipédia (pt) – Comércio de emissões de carbono](https://pt.wikipedia.org/wiki/Com%C3%A9rcio_de_emiss%C3%B5es_de_carbono) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Comércio de emissões de carbono" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0007 — O que é sequestro de carbono?

**Variantes:** Sequestro de carbono: o que significa? · Me explica o que é sequestro de carbono · oq é sequestro de carbono · sequestro de carbono? · Defina sequestro de carbono

Sequestro de carbono (também conhecido com captura de carbono) é o processo de remoção de gás carbônico da atmosfera. Tal processo ocorre principalmente em oceanos, florestas e outros locais onde os organismos, por meio da fotossíntese, capturam o carbono e lançam oxigênio na atmosfera. É a captura e estocagem segura de gás carbônico (CO2) que evita sua emissão e permanência na atmosfera terrestre. O desmatamento é um forte "contraventor" do sequestro pois diminui o efeito deste quando elimina o número de seres fotossintetizantes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Sequestro de carbono](https://pt.wikipedia.org/wiki/Sequestro_de_carbono) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Sequestro de carbono" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0008 — O que são gases do efeito estufa?

**Variantes:** Gases do efeito estufa: o que significa? · Me explica o que são gases do efeito estufa · oq sao gases do efeito estufa · gases do efeito estufa? · Defina gases do efeito estufa

Os gases de efeito de estufa (português europeu) ou gases do efeito estufa (português brasileiro) (GEE) são gases que absorvem e emitem energia radiante dentro da faixa do infravermelho térmico, causando o efeito de estufa. Os principais gases de efeito de estufa na atmosfera da Terra são o vapor de água (H2O), dióxido de carbono (CO2), metano (CH4), óxido nitroso (N2O) e ozono (O3). Sem gases de efeito de estufa, a temperatura média da superfície da Terra seria de cerca de -18°C, em vez da média atual de 15°C. As atmosferas de Vénus, Marte e Titã também contêm gases de efeito estufa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Gases do efeito estufa](https://pt.wikipedia.org/wiki/Gases_do_efeito_estufa) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Gases do efeito estufa" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0009 — O que é efeito estufa?

**Variantes:** Efeito estufa: o que significa? · Me explica o que é efeito estufa · oq é efeito estufa · efeito estufa? · Defina efeito estufa

O efeito estufa (português brasileiro) ou efeito de estufa (português europeu) é um processo físico que ocorre quando uma parte da radiação infravermelha (percebida como calor) é emitida pela superfície terrestre e absorvida por determinados gases presentes na atmosfera, os chamados gases do efeito estufa ou gases estufa. Como consequência disso, parte do calor é irradiado de volta para a superfície, não sendo libertado para o espaço. O efeito estufa dentro de uma determinada faixa é de vital importância pois, sem ele, a vida como a conhecemos não poderia existir. Serve para manter o planeta aquecido e, assim, garantir a manutenção da vida.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Efeito estufa](https://pt.wikipedia.org/wiki/Efeito_estufa) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Efeito estufa" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0010 — O que é dióxido de carbono?

**Variantes:** Dióxido de carbono: o que significa? · Me explica o que é dióxido de carbono · oq é dioxido de carbono · dióxido de carbono? · Defina dióxido de carbono

Dióxido de carbono (fórmula química CO2) é um composto químico formado por moléculas, cada uma com um átomo de carbono ligado covalentemente a dois átomos de oxigênio. Encontra-se no estado gasoso à temperatura ambiente. No ar, o dióxido de carbono é transparente à luz visível, mas absorve a radiação infravermelha, agindo como um gás de efeito estufa. É um gás traço na atmosfera da Terra em 421 partes por milhão (ppm), ou cerca de 0,04% em volume (em maio de 2022), tendo subido dos níveis pré-industriais de 280 ppm.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Dióxido de carbono](https://pt.wikipedia.org/wiki/Di%C3%B3xido_de_carbono) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Dióxido de carbono" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0011 — O que é metano?

**Variantes:** Metano: o que significa? · Me explica o que é metano · oq é metano · metano? · Defina metano

O metano é um gás incolor, sua molécula é tetraédrica e apolar ( CH4), de pouca solubilidade na água e, quando adicionado ao ar se transforma em mistura de alto teor inflamável. É o mais simples dos hidrocarbonetos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Metano](https://pt.wikipedia.org/wiki/Metano) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Metano" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0012 — O que é óxido nitroso?

**Variantes:** Óxido nitroso: o que significa? · Me explica o que é óxido nitroso · oq é oxido nitroso · óxido nitroso? · Defina óxido nitroso

O óxido nitroso, protóxido de nitrogênio (português brasileiro) ou protóxido de azoto (português europeu), também conhecido como gás hilariante, é apresentado na forma de um gás incolor, composto de duas partes de nitrogênio e uma de oxigênio, cuja fórmula química é N2O. É um composto químico que age como agente anestésico fraco em forma de gás respiratório inorgânico e inodoro que tem efeitos analgésicos significativos e baixa solubilidade no sangue. O N2O causa modestos aumentos da frequência respiratória e quando administrado isoladamente pode aumentar de forma expressiva o fluxo sanguíneo cerebral e a pressão intracraniana.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Óxido nitroso](https://pt.wikipedia.org/wiki/%C3%93xido_nitroso) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Óxido nitroso" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0013 — O que é Protocolo de Quioto?

**Variantes:** Protocolo de Quioto: o que significa? · Me explica o que é Protocolo de Quioto · oq é protocolo de quioto · Protocolo de Quioto? · Defina Protocolo de Quioto

O Protocolo de Quioto é um tratado internacional ambiental de 1997 com compromissos mais rígidos para a redução da emissão dos gases que produzem o efeito estufa (causa do atual aquecimento global). O acordo é consequência de uma série de eventos iniciada com a Toronto Conference on the Changing Atmosphere, no Canadá (outubro de 1988), seguida pelo IPCC's First Assessment Report em Sundsvália, Suécia (agosto de 1990) e que culminou com a Convenção-Quadro das Nações Unidas sobre a Mudança Climática na ECO-92 no Rio de Janeiro, Brasil (junho de 1992). Também reforça seções da CQNUMC.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Protocolo de Quioto](https://pt.wikipedia.org/wiki/Protocolo_de_Quioto) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Protocolo de Quioto" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0014 — O que é Conferência das Nações Unidas sobre as Mudanças Climáticas?

**Variantes:** Conferência das Nações Unidas sobre as Mudanças Climáticas: o que significa? · Me explica o que é Conferência das Nações Unidas sobre as Mudanças Climáticas · oq é conferencia das nacoes unidas sobre as mudancas climaticas · Conferência das Nações Unidas sobre as Mudanças Climáticas? · Defina Conferência das Nações Unidas sobre as Mudanças Climáticas

As Conferências das Nações Unidas sobre Mudanças Climáticas, ou Conferência das Partes, são eventos anuais da Organização das Nações Unidas realizados no âmbito da Convenção-Quadro das Nações Unidas sobre a Mudança do Clima (UNFCCC). Eles servem como reunião formal dos integrantes da UNFCCC (a Conferência das Partes – COP) para avaliar o progresso no enfrentamento das mudanças climáticas. Desde meados da década de 1990, ocorrem para negociar o Protocolo de Quioto, estabelecendo obrigações juridicamente vinculativas para os países desenvolvidos reduzirem suas emissões de gases de efeito estufa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [Wikipédia (pt) – Conferências das Nações Unidas sobre as Mudanças Climáticas](https://pt.wikipedia.org/wiki/Confer%C3%AAncias_das_Na%C3%A7%C3%B5es_Unidas_sobre_as_Mudan%C3%A7as_Clim%C3%A1ticas) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Conferências das Nações Unidas sobre as Mudanças Climáticas" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0015 — O que é COP 30?

**Variantes:** COP 30: o que significa? · Me explica o que é COP 30 · oq é cop 30 · COP 30? · Defina COP 30

Conferência das Nações Unidas sobre as Mudanças Climáticas de 2025, ou 30th Conference Of the Parties (abreviado COP30), informalmente chamada de COP da Amazônia, foi a 30.ª Conferência das Nações Unidas sobre as Mudanças Climáticas. Ocorreu entre os dias 10 e 21 de novembro de 2025, na cidade brasileira de Belém (no estado do Pará), segundo o anúncio da ONU em 18 de maio de 2023. A candidatura da cidade brasileira já havia sido anunciada pelo presidente brasileiro Lula da Silva durante sua participação na COP27, realizada na cidade de Xarm el-Xeikh, no Egito, e oficializada, finalmente, em janeiro de 2023.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Conferência das Nações Unidas sobre as Mudanças Climáticas de 2025](https://pt.wikipedia.org/wiki/Confer%C3%AAncia_das_Na%C3%A7%C3%B5es_Unidas_sobre_as_Mudan%C3%A7as_Clim%C3%A1ticas_de_2025) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Conferência das Nações Unidas sobre as Mudanças Climáticas de 2025" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0016 — O que é neutralidade de carbono?

**Variantes:** Neutralidade de carbono: o que significa? · Me explica o que é neutralidade de carbono · oq é neutralidade de carbono · neutralidade de carbono? · Defina neutralidade de carbono

A neutralidade de carbono é um estado de emissões líquidas zero de dióxido de carbono. Isso pode ser alcançado equilibrando as emissões de dióxido de carbono com sua remoção (muitas vezes através da compensação de carbono) ou eliminando as emissões da sociedade (a transição para a "economia pós-carbono"). O termo é usado no contexto de processos de liberação de dióxido de carbono associados ao transporte, produção de energia, agricultura e indústria. Embora o termo "carbono neutro" seja usado, uma pegada de carbono também inclui outros gases de efeito estufa, medidos em termos de sua equivalência de dióxido de carbono.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007, F26-010
*Fontes:* [Wikipédia (pt) – Neutralidade de carbono](https://pt.wikipedia.org/wiki/Neutralidade_de_carbono) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Neutralidade de carbono" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0017 — O que é economia circular?

**Variantes:** Economia circular: o que significa? · Me explica o que é economia circular · oq é economia circular · economia circular? · Defina economia circular

A economia circular é um modelo de produção e consumo de recursos que envolve compartilhamento, empréstimos, reutilização, reparo, reforma e reciclagem de materiais e produtos existentes pelo maior tempo possível. O conceito visa enfrentar desafios globais como mudanças climáticas, perda de biodiversidade, desperdício e poluição, enfatizando a implementação dos três princípios básicos do modelo, que são: projetar para eliminar desperdícios e poluição, manter produtos e materiais em uso e regenerar sistemas naturais. A economia circular é definida em contaste com a economia linear tradicional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Economia circular](https://pt.wikipedia.org/wiki/Economia_circular) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Economia circular" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0018 — O que é economia verde?

**Variantes:** Economia verde: o que significa? · Me explica o que é economia verde · oq é economia verde · economia verde? · Defina economia verde

Uma economia verde é uma economia que busca reduzir os riscos ambientais e a escassez ecológica, e que visa o desenvolvimento sustentável sem a degradação do meio ambiente. Ela se relaciona ao conceito de economia ecológica, mas apresenta um enfoque mais político. Uma das características distintivas da economia verde em relação aos modelos econômicos precedentes é valoração direta do capital natural e serviços ecológicos. Outra distinção é a implementação de um regime de contabilidade de custo total, em que as externalidades ambientais negativas são rastreadas de maneira confiável e contabilizadas como passivos da entidade que danifica ou negligencia um ativo ambiental.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Economia verde](https://pt.wikipedia.org/wiki/Economia_verde) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Economia verde" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0019 — O que é energia renovável?

**Variantes:** Energia renovável: o que significa? · Me explica o que é energia renovável · oq é energia renovavel · energia renovável? · Defina energia renovável

Energia renovável é aquela que vem de recursos naturais que são naturalmente reabastecidos, como sol, vento, chuva, marés e energia geotérmica. É importante notar que nem todo recurso natural é renovável, por exemplo, o urânio, carvão e petróleo são retirados da natureza, porém existem em quantidade limitada. Em 2008, cerca de 19% do consumo mundial de eletricidade veio de fontes renováveis, com 13% provenientes da tradicional biomassa, que é usada principalmente para aquecimento, e 3,2% a partir da hidroeletricidade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Energia renovável](https://pt.wikipedia.org/wiki/Energia_renov%C3%A1vel) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Energia renovável" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0020 — O que é energia solar fotovoltaica?

**Variantes:** Energia solar fotovoltaica: o que significa? · Me explica o que é energia solar fotovoltaica · oq é energia solar fotovoltaica · energia solar fotovoltaica? · Defina energia solar fotovoltaica

A energia solar fotovoltaica é a energia obtida através da conversão direta da luz em eletricidade por meio do efeito fotovoltaico. A célula fotovoltaica, um dispositivo fabricado com material semicondutor, é a unidade fundamental desse processo de conversão. Este tipo de energia usa-se para alimentar uma grande variedade de aplicativos e aparelhos autónomos, para abastecer refúgios ou moradias isoladas da rede elétrica e para produzir eletricidade a grande escala através de redes de distribuição. Devido à crescente demanda de energias renováveis, a fabricação de células solares e instalações fotovoltaicas tem avançado consideravelmente nos últimos anos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Energia solar fotovoltaica](https://pt.wikipedia.org/wiki/Energia_solar_fotovoltaica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Energia solar fotovoltaica" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0021 — O que é energia eólica?

**Variantes:** Energia eólica: o que significa? · Me explica o que é energia eólica · oq é energia eolica · energia eólica? · Defina energia eólica

Energia eólica é a transformação da energia do vento em energia útil, tal como na utilização de aerogeradores para produzir eletricidade, moinhos de vento para produzir energia mecânica ou velas para impulsionar veleiros. A energia eólica, enquanto alternativa aos combustíveis fósseis, é renovável, está permanentemente disponível, pode ser produzida em qualquer região, é limpa, não produz gases de efeito de estufa durante a produção e requer menos terreno. O impacto ambiental é geralmente menos problemático do que o de outras fontes de energia.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Energia eólica](https://pt.wikipedia.org/wiki/Energia_e%C3%B3lica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Energia eólica" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0022 — O que é biocombustível?

**Variantes:** Biocombustível: o que significa? · Me explica o que é biocombustível · oq é biocombustivel · biocombustível? · Defina biocombustível

Biocombustível ou agrocombustível é o combustível de origem biológica não fóssil, produzido a partir de processos sob a biomassa. Como a biomassa pode ser usada diretamente como combustível (exemplo disso são os troncos de madeira, vale salientar que desde de o descobrimento do fogo pelo ser humano se utiliza os biocombustíveis[carece de fontes]?), algumas pessoas consideram a biomassa como sinônimo de biocombustível. Entretanto, a biomassa simplesmente denota a matéria-prima biológica da qual o combustível é fabricado ou algum produto final sólido termicamente/quimicamente alterado, como os pellets e os briquetes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Biocombustível](https://pt.wikipedia.org/wiki/Biocombust%C3%ADvel) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biocombustível" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0023 — O que é etanol?

**Variantes:** Etanol: o que significa? · Me explica o que é etanol · oq é etanol · etanol? · Defina etanol

O etanol (também chamado álcool etílico ou simplesmente álcool) é um composto orgânico com a fórmula CH3CH2OH, também escrita C2H6O. É um líquido incolor, inodor, volátil e inflamável. É utilizado há milênios e em diversas culturas como droga recreativa por meio de bebidas alcoólicas, como cerveja, vinho e aguardente. O etanol é o mais comum dos álcoois, que são compostos com grupos hidroxila ligados a átomos de carbono sp3 (ou seja, cadeias carbônicas saturadas).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Etanol](https://pt.wikipedia.org/wiki/Etanol) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Etanol" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0024 — O que são serviços ambientais?

**Variantes:** Serviços ambientais: o que significa? · Me explica o que são serviços ambientais · oq sao servicos ambientais · serviços ambientais? · Defina serviços ambientais · O que é serviços ambientais?

Serviços ambientais, ecossistêmicos ou naturais são os serviços que a natureza fornece ao homem e que são indispensáveis à sua sobrevivência, estando associados à qualidade de vida e bem estar da sociedade. Os exemplos incluem proteção contra desastres naturais, controle da erosão, polinização, fertilização do solo pelas fezes de animais, decomposição de animais e plantas por microrganismos. As florestas fornecem madeira, alimentos, substâncias medicinais e fibras, purificam a água, regulam o clima e produzem recursos genéticos. Os sistemas fluviais disponibilizam água doce, energia e recreio.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Serviços ambientais](https://pt.wikipedia.org/wiki/Servi%C3%A7os_ambientais) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Serviços ambientais" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0025 — O que é Moratória da Soja?

**Variantes:** Moratória da Soja: o que significa? · Me explica o que é Moratória da Soja · oq é moratoria da soja · Moratória da Soja? · Defina Moratória da Soja

Moratória da soja é o nome que recebeu o pacto ambiental havido entre as entidades representativas dos produtores de soja no Brasil, ONGs ambientais e, mais tarde, do próprio governo, prevendo a adoção de medidas contra o desmatamento da amazônia, e que inicialmente teve o prazo de duração de dois anos a contar de 24 de julho de 2006. Na prática, a Moratória da soja proíbe a compra de soja proveniente de áreas recém desmatadas na Amazônia. Em maio de 2016 a Moratória foi renovada indefinidamente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Moratória da Soja](https://pt.wikipedia.org/wiki/Morat%C3%B3ria_da_Soja) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Moratória da Soja" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0026 — O que é desmatamento?

**Variantes:** Desmatamento: o que significa? · Me explica o que é desmatamento · oq é desmatamento · desmatamento? · Defina desmatamento

Desflorestação, desflorestamento, desmate ou desmatamento é o processo de desaparecimento completo e permanente de florestas, atualmente causado em sua maior parte por atividades humanas. Embora o conceito se aplique em senso estrito à perda de florestas, formações vegetais cujo principal componente são as árvores, muitas vezes ele é aplicado às perdas de cobertura vegetal de formações naturalmente esparsas, arbustivas ou rasteiras, como as savanas, as pradarias e o cerrado, significando, em seu sentido lato, a perda permanente de todo tipo de cobertura vegetal original em determinada área.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Desflorestação](https://pt.wikipedia.org/wiki/Desfloresta%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Desflorestação" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0027 — O que é desmatamento no Brasil?

**Variantes:** Desmatamento no Brasil: o que significa? · Me explica o que é desmatamento no Brasil · oq é desmatamento no brasil · desmatamento no Brasil? · Defina desmatamento no Brasil

O desmatamento no Brasil é um dos grandes problemas ambientais que o país enfrenta na atualidade. Várias são suas causas, e elas têm peso distinto nas diversas regiões, sendo as mais importantes a conversão das terras para a agricultura ou para a pecuária, a exploração madeireira, a grilagem de terras, a urbanização e a criação de infraestruturas como pontes, estradas e barragens. Os estados do Mato Grosso, Pará e Rondônia são os mais atingidos pelo desmatamento recente. Desde que o homem chegou ao atual território do Brasil, há milhares de anos, passou a produzir impacto ambiental em ciclos repetidos de desmatamento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Desmatamento no Brasil](https://pt.wikipedia.org/wiki/Desmatamento_no_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Desmatamento no Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0028 — O que é greenwashing?

**Variantes:** Greenwashing: o que significa? · Me explica o que é greenwashing · oq é greenwashing · greenwashing? · Defina greenwashing

O anglicismo greenwashing (do inglês green, verde, e whitewash, branquear ou encobrir) ou banho verde indica a injustificada apropriação de virtudes ambientalistas por parte de organizações (empresas, governos, etc.) ou pessoas, mediante o uso de técnicas de marketing e relações públicas. Tal prática tem como objetivo criar uma imagem positiva, diante a opinião pública, acerca do grau de responsabilidade ambiental dessas organizações ou pessoas (bem como de suas atividades e seus produtos), ocultando ou desviando a atenção de impactos ambientais negativos por elas gerados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Greenwashing](https://pt.wikipedia.org/wiki/Greenwashing) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Greenwashing" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Legislação ambiental

### SUST-LEG-018 — O que é a Lei de Crimes Ambientais?

**Variantes:** Bah, uma dúvida: o que é a Lei de Crimes Ambientais? · lei crimes ambientais? · o q e a lei de crimes ambientis

A Lei nº 9.605/1998 trata das sanções penais e administrativas para condutas e atividades lesivas ao meio ambiente. Ela prevê que pessoas jurídicas podem ser responsabilizadas administrativa, civil e penalmente quando a infração for cometida por decisão de seu representante ou órgão colegiado, sem excluir a responsabilidade das pessoas físicas envolvidas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* baixa
*Fontes:* [Lei nº 9.605/1998 – Lei de Crimes Ambientais (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l9605.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-019 — O que é a Política Nacional do Meio Ambiente?

**Variantes:** Bah, uma dúvida: o que é a Política Nacional do Meio Ambiente? · política nacional meio ambiente? · o q e a politca nacional do meio ambiente

A Lei nº 6.938/1981 dispõe sobre a Política Nacional do Meio Ambiente, seus fins e mecanismos de formulação e aplicação. Ela constitui o Sistema Nacional do Meio Ambiente (Sisnama), que tem o Conselho Nacional do Meio Ambiente (Conama) como órgão consultivo e deliberativo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* baixa
*Fontes:* [Lei nº 6.938/1981 – Política Nacional do Meio Ambiente (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l6938.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-WK-0029 — O que é área de preservação permanente?

**Variantes:** Área de preservação permanente: o que significa? · Me explica o que é área de preservação permanente · oq é area de preservacao permanente · área de preservação permanente? · Defina área de preservação permanente

Área de Preservação Permanente (APP) é uma área protegida pela legislação ambiental brasileira, que pode ser coberta por vegetação natural ou não. O principal objetivo dessas áreas é proporcionar aos seres humanos um meio ambiente ecologicamente equilibrado, através da preservação ambiental dos recursos hídricos, da paisagem, da estabilidade do solo e do conjunto de seres vivos ali existente. Em áreas consideradas área de preservação permanente, em regra, não pode ocorrer a intervenção humana, ou seja, não é possível utilizar ou explorar os recursos daquela área.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Área de Preservação Permanente](https://pt.wikipedia.org/wiki/%C3%81rea_de_Preserva%C3%A7%C3%A3o_Permanente) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Área de Preservação Permanente" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0030 — O que é reserva legal?

**Variantes:** Reserva legal: o que significa? · Me explica o que é reserva legal · oq é reserva legal · reserva legal? · Defina reserva legal

Reserva Legal, no Brasil, é um tipo de instrumento de proteção de espaços naturais previsto na Lei de Proteção da Vegetação Nativa (Lei nº 12.651/2012, popularmente chamada "Código Florestal"). É uma área localizada no interior de uma propriedade rural, privada ou pública, que não seja a Área de Preservação Permanente (APP), necessária ao uso sustentável dos recursos naturais, à conservação e reabilitação dos processos ecológicos, à conservação da biodiversidade e ao abrigo e proteção de fauna e flora nativas. O Código Florestal, em seu art. 12, estabelece diferentes percentuais mínimos de Reserva Legal.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Reserva Legal](https://pt.wikipedia.org/wiki/Reserva_Legal) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Reserva Legal" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0031 — O que é licenciamento ambiental?

**Variantes:** Licenciamento ambiental: o que significa? · Me explica o que é licenciamento ambiental · oq é licenciamento ambiental · licenciamento ambiental? · Defina licenciamento ambiental

Licenciamento ambiental é um procedimento administrativo em que o Poder Público autoriza o funcionamento de atividades potencialmente nocivas ao meio ambiente, como a instalação e operação de fábricas, empresas e obras construção civil. O empreendimento licenciado é submetido à fiscalização do Poder Público, que realiza o controle e acompanhamento das atividades visando evitar danos ambientais (BRASIL, 2016).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Licenciamento ambiental no Brasil](https://pt.wikipedia.org/wiki/Licenciamento_ambiental_no_Brasil) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Licenciamento ambiental no Brasil" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0032 — O que é Lei de Crimes Ambientais?

**Variantes:** Lei de Crimes Ambientais: o que significa? · Me explica o que é Lei de Crimes Ambientais · oq é lei de crimes ambientais · Lei de Crimes Ambientais? · Defina Lei de Crimes Ambientais

O meio ambiente ecologicamente equilibrado – dentro do qual estão inclusos o físico, o artificial, o do trabalho e o cultural – é um bem jurídico protegido pelo ordenamento interno, bem como por diversos tratados e convenções internacionais que foram ratificados pelo Brasil. Ele entrou para o rol de direitos fundamentais determinados pela Constituição de 1988 como um direito de terceira geração, sendo assim de titularidade coletiva. Cabe destacar que os direitos de terceira geração não se baseiam, como os demais, em uma atuação negativa ou positiva do Estado, mas são direitos em que há um dever de cuidado compartilhado entre ele e a sociedade civil.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Lei de Crimes Ambientais](https://pt.wikipedia.org/wiki/Lei_de_Crimes_Ambientais) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Lei de Crimes Ambientais" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0033 — O que é mata ciliar?

**Variantes:** Mata ciliar: o que significa? · Me explica o que é mata ciliar · oq é mata ciliar · mata ciliar? · Defina mata ciliar

A vegetação ripária (ou ripícola, ribeirinha) é um tipo de vegetação presente em espaços próximos a corpos da água, isto é, na zona ripária. Pode assumir fisionomia campestre ou florestal e, neste último caso, é chamada mata ripária (ou mata ciliar, em sentido amplo). Inclui vários subtipos, entre eles, a mata ciliar (em sentido restrito), a mata ripária (em sentido restrito), a mata de galeria, a mata paludosa, etc.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Vegetação ripária](https://pt.wikipedia.org/wiki/Vegeta%C3%A7%C3%A3o_rip%C3%A1ria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Vegetação ripária" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0034 — O que é unidade de conservação?

**Variantes:** Unidade de conservação: o que significa? · Me explica o que é unidade de conservação · oq é unidade de conservacao · unidade de conservação? · Defina unidade de conservação

No Brasil, o Sistema Nacional de Unidades de Conservação da Natureza (SNUC) é um conjunto de normas e procedimentos oficiais que possibilitam às esferas governamentais federal, estadual e municipal, bem como à iniciativa privada, criar, implementar e gerir no país as unidades de conservação (que são as representantes no Brasil do que internacionalmente é conhecido como área protegida), sistematizando assim a conservação da natureza no país.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Sistema Nacional de Unidades de Conservação da Natureza](https://pt.wikipedia.org/wiki/Sistema_Nacional_de_Unidades_de_Conserva%C3%A7%C3%A3o_da_Natureza) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Sistema Nacional de Unidades de Conservação da Natureza" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0035 — O que é Ibama?

**Variantes:** Ibama: o que significa? · Me explica o que é Ibama · oq é ibama · Ibama? · Defina Ibama

O Instituto Brasileiro do Meio Ambiente e dos Recursos Naturais Renováveis, mais conhecido pelo acrônimo IBAMA, é uma autarquia governamental federal brasileira criada em 1989 (Lei 7.735), vinculada ao Ministério do Meio Ambiente e Mudança do Clima; é o órgão executivo responsável pela execução da Política Nacional do Meio Ambiente (PNMA, lei 6.938), e por desenvolver atividades para a preservação e conservação do patrimônio natural, exercendo o controle e a fiscalização sobre o uso dos recursos naturais (água, flora, fauna, solo, etc.).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Instituto Brasileiro do Meio Ambiente e dos Recursos Naturais Renováveis](https://pt.wikipedia.org/wiki/Instituto_Brasileiro_do_Meio_Ambiente_e_dos_Recursos_Naturais_Renov%C3%A1veis) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Instituto Brasileiro do Meio Ambiente e dos Recursos Naturais Renováveis" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0036 — O que é Instituto Chico Mendes de Conservação da Biodiversidade?

**Variantes:** Instituto Chico Mendes de Conservação da Biodiversidade: o que significa? · Me explica o que é Instituto Chico Mendes de Conservação da Biodiversidade · oq é instituto chico mendes de conservacao da biodiversidade · Instituto Chico Mendes de Conservação da Biodiversidade? · Defina Instituto Chico Mendes de Conservação da Biodiversidade

Instituto Chico Mendes de Conservação da Biodiversidade (ICMBio) é uma autarquia brasileira criado em 2007 (lei n°11.516), vinculada ao Ministério do Meio Ambiente e integrada ao Sistema Nacional do Meio Ambiente (SISNAMA). Possui as atribuições de planejar e fiscalizar as unidades de conservação federais, também de aumentar e executar pesquisas, além de proteger a biodiversidade no Brasil. Atualmente, a presidência do ICMBio é exercida pelo cientista social, servidor de carreira, Mauro Oliveira Pires, desde 25 de maio de 2023. Foi criado pela lei n.º 11 516 de 28 de agosto de 2007 e tem sua estrutura regida e aprovada pelo decreto n.º 10.234, de 11 de fevereiro de 2020.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Instituto Chico Mendes de Conservação da Biodiversidade](https://pt.wikipedia.org/wiki/Instituto_Chico_Mendes_de_Conserva%C3%A7%C3%A3o_da_Biodiversidade) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Instituto Chico Mendes de Conservação da Biodiversidade" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0037 — O que é mata Atlântica?

**Variantes:** Mata Atlântica: o que significa? · Me explica o que é mata Atlântica · oq é mata atlantica · mata Atlântica? · Defina mata Atlântica

Mata Atlântica é um bioma de floresta tropical que abrange a costa leste, nordeste, sudeste e sul do Brasil, leste do Paraguai e a província de Misiones, na Argentina. Seus processos ecológicos evoluíram a partir do Eoceno, quando os continentes já estavam relativamente dispostos como estão hoje. A região é ocupada por seres humanos há mais de 10 000 anos. A partir da colonização europeia, e principalmente, no século XX, a Mata Atlântica passou por intenso desmatamento, restando menos de 20% da cobertura vegetal original.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*KB Fenasoja:* VIS-003
*Fontes:* [Wikipédia (pt) – Mata Atlântica](https://pt.wikipedia.org/wiki/Mata_Atl%C3%A2ntica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Mata Atlântica" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0038 — O que são recursos hídricos?

**Variantes:** Recursos hídricos: o que significa? · Me explica o que são recursos hídricos · oq sao recursos hidricos · recursos hídricos? · Defina recursos hídricos

Recursos hídricos são as águas superficiais ou subterrâneas disponíveis para qualquer tipo de uso de região ou bacias. À partida, sendo a água um recurso renovável estaria sempre disponível para o homem utilizar. No entanto, como o consumo tem excedido a renovação da mesma, atualmente verifica-se um stress hídrico, ou seja, falta de água doce principalmente junto aos grandes centros urbanos e também a diminuição da qualidade da água, sobretudo devido à poluição hídrica por esgotos domésticos e industriais.[carece de fontes]?

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Recursos hídricos](https://pt.wikipedia.org/wiki/Recursos_h%C3%ADdricos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Recursos hídricos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0039 — O que é comitê de bacia hidrográfica?

**Variantes:** Comitê de bacia hidrográfica: o que significa? · Me explica o que é comitê de bacia hidrográfica · oq é comite de bacia hidrografica · comitê de bacia hidrográfica? · Defina comitê de bacia hidrográfica

Comitês de bacia hidrográfica (CBH) são fóruns regionais que integram o Sistema Nacional de Gestão dos Recursos Hídricos do Brasil. Possuem representação da sociedade civil e suas funções incluem discutir e deliberar sobre o uso dos recursos hídricos junto ao poder público. Os comitês têm como atribuição legal deliberar sobre a gestão da água.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Comitês de bacia hidrográfica](https://pt.wikipedia.org/wiki/Comit%C3%AAs_de_bacia_hidrogr%C3%A1fica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Comitês de bacia hidrográfica" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0041 — O que é Política Nacional de Resíduos Sólidos?

**Variantes:** Política Nacional de Resíduos Sólidos: o que significa? · Me explica o que é Política Nacional de Resíduos Sólidos · oq é politica nacional de residuos solidos · Política Nacional de Resíduos Sólidos? · Defina Política Nacional de Resíduos Sólidos

A Política Nacional de Resíduos Sólidos (PNRS) é uma normatização brasileira instituída pela Lei nº 12 305 de 2 de agosto de 2010, para reduzir o impacto dos resíduos sólidos no meio ambiente, através do gerenciamento destes no Brasil. Os princípios desta lei visam o desenvolvimento sustentável, a responsabilidade compartilhada, o reconhecimento do resíduo sólido e, economia geradora de trabalho e renda. Seus objetivos norteiam a proteção da saúde e do meio ambiente e a redução do volume de resíduos sólidos, incentivando a reutilização, a reciclagem e o tratamento de resíduos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Política Nacional de Resíduos Sólidos](https://pt.wikipedia.org/wiki/Pol%C3%ADtica_Nacional_de_Res%C3%ADduos_S%C3%B3lidos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Política Nacional de Resíduos Sólidos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Agricultura de baixo carbono

### SUST-WK-0042 — O que é Plano ABC?

**Variantes:** Plano ABC: o que significa? · Me explica o que é Plano ABC · oq é plano abc · Plano ABC? · Defina Plano ABC

O Plano Agricultura de Baixo Carbono (Plano ABC), ou, conforme seu nome técnico completo, Plano Setorial de Mitigação e de Adaptação às Mudanças Climáticas para a Consolidação de uma Economia de Baixa Emissão de Carbono na Agricultura, foi uma política pública brasileira vigente para o período de 2010 e 2020, que tinha por objetivo ações de mitigação e adaptação climática para o setor agropecuário. Coordenado pela Casa Civil da Presidência da República, pelo Ministério da Agricultura, Abastecimento e Pecuária (Mapa) e pelo Ministério do Desenvolvimento Agrário (MDA), contava com a participação ativa e representatividade da sociedade civil.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Plano Agricultura de Baixo Carbono](https://pt.wikipedia.org/wiki/Plano_Agricultura_de_Baixo_Carbono) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Plano Agricultura de Baixo Carbono" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0043 — O que é sistema agroflorestal?

**Variantes:** Sistema agroflorestal: o que significa? · Me explica o que é sistema agroflorestal · oq é sistema agroflorestal · sistema agroflorestal? · Defina sistema agroflorestal

Agrofloresta ou sistema agroflorestal (SAF) é um sistema que reúne as culturas de importância agronômica em consórcio com a plantas que integram a floresta. Um sistema agroflorestal é um sistema de plantio de alimentos que é sustentável e ainda faz a recuperação vegetal e do solo. Existem evidências do uso de sistemas agroflorestais há 4.500 anos, na Amazônia Oriental. Na Amazônia, os Sistemas Agroflorestais (SAFs) podem ser implementados como estratégias.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Agrofloresta](https://pt.wikipedia.org/wiki/Agrofloresta) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Agrofloresta" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0044 — O que é degradação de pastagens?

**Variantes:** Degradação de pastagens: o que significa? · Me explica o que é degradação de pastagens · oq é degradacao de pastagens · degradação de pastagens? · Defina degradação de pastagens

O processo de degradação da pastagens é um fenômeno complexo que envolve causas e consequências que levam a gradativa diminuição da capacidade de suporte da pastagem, culminando com a degradação propriamente dita. Sendo um processo evolutivo da perda da produtividade, vigorosidade e das condições desejáveis do solo, ligadas aos níveis de produção e qualidade exigidas pelos animais, a degradação de pastagem, pode-se entender como a queda na produção e valor nutritivo da forragem, mesmo nas épocas que são favoráveis ao seu crescimento, em razão de manejos inadequados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Degradação de pastagens](https://pt.wikipedia.org/wiki/Degrada%C3%A7%C3%A3o_de_pastagens) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Degradação de pastagens" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0045 — O que é silvicultura?

**Variantes:** Silvicultura: o que significa? · Me explica o que é silvicultura · oq é silvicultura · silvicultura? · Defina silvicultura

Silvicultura é a ciência dedicada ao estudo dos métodos naturais e artificiais de regenerar e melhorar os povoamentos florestais com vistas a satisfazer as necessidades do mercado e, ao mesmo tempo, aplicação desse estudo para a manutenção, o aproveitamento e o uso racional das florestas. A silvicultura também está relacionada à cultura madeireira. O manejo de uma área de silvicultura exige a participação de técnicos de várias áreas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Silvicultura](https://pt.wikipedia.org/wiki/Silvicultura) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Silvicultura" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0046 — O que é eucalipto?

**Variantes:** Eucalipto: o que significa? · Me explica o que é eucalipto · oq é eucalipto · eucalipto? · Defina eucalipto

Eucalipto é o nome comum dado às espécies de um vasto e complexo gênero de plantas com flor, Eucalyptus (família Myrtaceae), e, por extensão, a gêneros próximos como Corymbia e Angophora. Predominantemente árvores, mas também arbustos, os eucaliptos são nativos da Oceania, onde formam a base da maioria das florestas e bosques da Austrália. Com mais de 700 espécies, o gênero é um dos mais diversos e ecologicamente dominantes do planeta, caracterizando a paisagem australiana de forma única. Desde a sua descoberta pelos europeus, o eucalipto tornou-se a árvore de plantação mais difundida no mundo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Eucalyptus](https://pt.wikipedia.org/wiki/Eucalyptus) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Eucalyptus" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0047 — O que é agricultura regenerativa?

**Variantes:** Agricultura regenerativa: o que significa? · Me explica o que é agricultura regenerativa · oq é agricultura regenerativa · agricultura regenerativa? · Defina agricultura regenerativa

A agricultura regenerativa é uma abordagem de conservação e reabilitação dos sistemas alimentares e agrícolas. Ela se concentra na regeneração do solo fértil, no aumento da biodiversidade, na melhoria do ciclo da água, no aprimoramento dos serviços ambientais, no suporte ao sequestro de carbono, no aumento da resiliência às mudanças climáticas e no fortalecimento da saúde e vitalidade do solo agrícola. A agricultura regenerativa não é uma prática específica. Em vez disso, os proponentes da agricultura regenerativa utilizam uma variedade de outras técnicas agrícolas sustentáveis em combinação.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Agricultura regenerativa](https://pt.wikipedia.org/wiki/Agricultura_regenerativa) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Agricultura regenerativa" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0048 — O que é biodiversidade?

**Variantes:** Biodiversidade: o que significa? · Me explica o que é biodiversidade · oq é biodiversidade · biodiversidade? · Defina biodiversidade

Biodiversidade, ou diversidade biológica, pode ser definida como a variabilidade entre os seres vivos de todas as origens, a terrestre, a marinha e outros ecossistemas aquáticos, e os complexos ecológicos dos quais fazem parte. Essa variabilidade aparece apenas como resultado da natureza em si, sem sofrer intervenção humana. Assim, ela pode variar de acordo com as diferentes regiões ecológicas. Refere-se, portanto, à variedade de vida no planeta Terra, incluindo a variedade genética dentro das populações e espécies, a variedade de espécies da flora, da fauna, de fungos microscópicos e de micro-organismos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Biodiversidade](https://pt.wikipedia.org/wiki/Biodiversidade) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Biodiversidade" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0049 — O que é polinização?

**Variantes:** Polinização: o que significa? · Me explica o que é polinização · oq é polinizacao · polinização? · Defina polinização

Polinização é a transferência de pólen de uma antera de uma planta para o estigma de uma planta, permitindo posteriormente a fertilização e a produção de sementes, na maioria das vezes por um animal ou pelo vento. Agentes polinizadores podem ser animais como insetos, pássaros e morcegos; água; vento; e até as próprias plantas, quando a autopolinização ocorre dentro de uma flor fechada. A polinização geralmente ocorre dentro de uma espécie. Quando a polinização ocorre entre espécies, ela pode produzir descendentes híbridos na natureza e no trabalho de melhoramento de plantas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Polinização](https://pt.wikipedia.org/wiki/Poliniza%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Polinização" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0050 — O que é abelha?

**Variantes:** Abelha: o que significa? · Me explica o que é abelha · oq é abelha · abelha? · Defina abelha

Abelhas são insetos voadores, conhecidos pelo seu importante papel na polinização. Pertencem à ordem Hymenoptera, da superfamília Apoidea, subgrupo Anthophila, e são aparentados das vespas e formigas. O representante mais conhecido é a Apis mellifera, oriunda do Velho Mundo, criada em larga escala para a produção de mel, própolis, geleia real e veneno. As espécies de abelhas nativas das Américas e Oceania são conhecidas como abelhas sem ferrão (ASF) e possuem ferrão atrofiado, sendo, portanto, menos agressivas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Abelha](https://pt.wikipedia.org/wiki/Abelha) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Abelha" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0051 — O que é água?

**Variantes:** Água: o que significa? · Me explica o que é água · oq é agua · água? · Defina água

Água (fórmula química: H2O) é uma substância química cujas moléculas são formadas por dois átomos de hidrogênio e um de oxigênio. É abundante no Universo, nomeadamente na Terra, onde cobre grande parte de sua superfície e é o maior constituinte dos fluidos dos seres vivos. As temperaturas do planeta permitem a ocorrência da água em seus três estados físicos principais. A água líquida, que em pequenas quantidades parece incolor, mas manifesta sua coloração azulada em grandes volumes, constitui os oceanos, rios e lagos que cobrem quase três quartos da superfície do planeta.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Água](https://pt.wikipedia.org/wiki/%C3%81gua) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Água" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### SUST-WK-0052 — O que é manejo sustentável?

**Variantes:** Manejo sustentável: o que significa? · Me explica o que é manejo sustentável · oq é manejo sustentavel · manejo sustentável? · Defina manejo sustentável

O manejo florestal sustentável (MFS), é um modelo que permite a exploração racional dos produtos madeireiros e não madeireiros com técnicas de mínimo impacto ambiental sobre os elementos da natureza. Uma floresta manejada continuará oferecendo suas riquezas para as gerações futuras, pois a madeira e seus outros produtos são recursos renováveis. Uma definição mais precisa de manejo se encontra no próprio decreto que regulamentou a exploração das florestas da Bacia Amazônica (Decreto nº1.282, de 19.10.95).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Manejo sustentável](https://pt.wikipedia.org/wiki/Manejo_sustent%C3%A1vel) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Manejo sustentável" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Código Florestal

### SUST-LEG-001 — O que é o Código Florestal brasileiro?

**Variantes:** Qual é a lei do Código Florestal? · código florestal lei 12.651 · oq é o codigo florestal · Lei de proteção da vegetação nativa

O atual Código Florestal é a Lei nº 12.651/2012, que dispõe sobre a proteção da vegetação nativa e revogou o código anterior de 1965 (Lei nº 4.771). Ela define, entre outros pontos, as Áreas de Preservação Permanente (APP), a Reserva Legal, o Cadastro Ambiental Rural (CAR) e os Programas de Regularização Ambiental (PRA).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 12.651/2012 – Código Florestal (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2012/lei/l12651.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-002 — O que é Área de Preservação Permanente (APP)?

**Variantes:** Uma pergunta: o que é Área de Preservação Permanente (APP)? · área preservação permanente app? · o q e area de preservaao permanente (app)

Pelo Código Florestal (Lei nº 12.651/2012, art. 3º), APP é uma área protegida, coberta ou não por vegetação nativa, com a função ambiental de preservar os recursos hídricos, a paisagem, a estabilidade geológica e a biodiversidade, facilitar o fluxo gênico de fauna e flora, proteger o solo e assegurar o bem-estar das populações humanas. Exemplos são as faixas ao longo de rios, o entorno de nascentes e encostas muito íngremes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 12.651/2012 – Código Florestal (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2012/lei/l12651.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-003 — Qual a largura da APP ao lado de rios?

**Variantes:** Quantos metros de mata ciliar precisa deixar no rio? · largura app rio · qtos metros de app na sanga · Faixa de proteção em margem de arroio

Pelo art. 4º do Código Florestal, a faixa de APP ao longo de cursos d'água naturais perenes e intermitentes, medida desde a borda da calha do leito regular, é de no mínimo 30 metros para rios com menos de 10 metros de largura, 50 metros para rios de 10 a 50 metros e 100 metros para rios de 50 a 200 metros, com faixas maiores para rios mais largos. Para áreas consolidadas, a lei prevê regras de recomposição diferenciadas conforme o tamanho do imóvel.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2012 · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 12.651/2012 – Código Florestal (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2012/lei/l12651.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado. As regras de recomposição em área rural consolidada (art. 61-A) variam por módulos fiscais; não simplificar.

### SUST-LEG-004 — O que é Reserva Legal e qual o percentual no Rio Grande do Sul?

**Variantes:** Quanto de reserva legal precisa ter no RS? · reserva legal percentual · qto de reserva legal tem q ter · Porcentagem de mato que a lei exige na propriedade

Reserva Legal é a área dentro do imóvel rural, coberta por vegetação nativa, destinada ao uso econômico sustentável dos recursos naturais e à conservação da biodiversidade. Pelo art. 12 do Código Florestal, o percentual mínimo é de 80%, 35% ou 20% na Amazônia Legal, conforme o bioma, e de 20% nas demais regiões do país. Como o Rio Grande do Sul está fora da Amazônia Legal, aplica-se em regra 20% da área do imóvel, ressalvadas as exceções previstas na lei.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 12.651/2012 – Código Florestal (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2012/lei/l12651.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-005 — O que é o CAR (Cadastro Ambiental Rural)?

**Variantes:** Para que serve o CAR? · cadastro ambiental rural · oq é o car da propriedade · O CAR é obrigatório?

O CAR foi criado pelo art. 29 do Código Florestal como um registro público eletrônico de âmbito nacional, obrigatório para todos os imóveis rurais. Ele integra as informações ambientais das propriedades e posses rurais (como APP, Reserva Legal e áreas de uso) para controle, monitoramento, planejamento ambiental e econômico e combate ao desmatamento. A inscrição é feita no órgão ambiental competente, pelo sistema do SICAR.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 12.651/2012 – Código Florestal (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2012/lei/l12651.htm) (acesso 2026-10-17); [SICAR – Cadastro Ambiental Rural (car.gov.br)](https://www.car.gov.br/) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-006 — O que é o PRA (Programa de Regularização Ambiental)?

**Variantes:** Me explica uma coisa: o que é o PRA (Programa de Regularização Ambiental)? · programa regularização ambiental? · o q e o pra (programa de regularizaao ambiental)

Pelo art. 59 do Código Florestal, a União, os estados e o Distrito Federal devem implantar Programas de Regularização Ambiental (PRAs) para adequar posses e propriedades rurais às regras de APP e Reserva Legal. A inscrição no CAR é condição para a adesão ao PRA.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 12.651/2012 – Código Florestal (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2012/lei/l12651.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

## Clima e carbono

### SUST-LEG-007 — O que é o SBCE (mercado regulado de carbono do Brasil)?

**Variantes:** O agro vai ter que pagar pelo carbono? · mercado de carbono regulado brasil · sbce oq é · A lei do carbono vale pro produtor rural?

O Sistema Brasileiro de Comércio de Emissões de Gases de Efeito Estufa (SBCE) foi instituído pela Lei nº 15.042/2024 e cria o mercado regulado de carbono no país, com limites de emissão e comercialização de ativos para atividades reguladas. A lei estabelece que a produção primária agropecuária, com seus bens, benfeitorias e infraestrutura no imóvel rural, não é atividade regulada e não se submete às obrigações do SBCE. A mesma lei também define o mercado voluntário, em que créditos de carbono são negociados livremente entre as partes para compensação voluntária de emissões.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007, VIS-006
*Fontes:* [Lei nº 15.042/2024 – Sistema Brasileiro de Comércio de Emissões (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/lei/L15042.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado. A regulamentação do SBCE está em implantação; detalhes operacionais devem ser buscados ao vivo.

### SUST-LEG-008 — O que é Pagamento por Serviços Ambientais (PSA)?

**Variantes:** Tu sabe me dizer: o que é Pagamento por Serviços Ambientais (PSA)? · pagamento serviços ambientais psa? · o q e pagamento por servicos ambientis (psa)

A Lei nº 14.119/2021 instituiu a Política Nacional de Pagamento por Serviços Ambientais. A ideia é remunerar quem mantém, recupera ou melhora serviços ecossistêmicos, que a lei define como benefícios relevantes gerados pelos ecossistemas, como provisão de água e alimentos, ciclagem de nutrientes, fertilidade do solo, polinização e controle de pragas. O pagamento pode ser feito por entes públicos ou privados ao produtor ou proprietário que presta o serviço.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 14.119/2021 – Política Nacional de Pagamento por Serviços Ambientais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/L14119.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

## Resíduos e embalagens

### SUST-LEG-009 — O que é logística reversa?

**Variantes:** Me tira uma dúvida: o que é logística reversa? · logística reversa? · o q e logistca reversa

Pela Política Nacional de Resíduos Sólidos (Lei nº 12.305/2010), logística reversa é o conjunto de ações, procedimentos e meios destinados a viabilizar a coleta e a restituição dos resíduos sólidos ao setor empresarial, para reaproveitamento em seu ciclo ou em outros ciclos produtivos, ou outra destinação final ambientalmente adequada. No campo, um exemplo é a devolução das embalagens vazias de agrotóxicos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 12.305/2010 – Política Nacional de Resíduos Sólidos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2007-2010/2010/lei/l12305.htm) (acesso 2026-10-17); [Lei nº 14.785/2023 – Lei dos Agrotóxicos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/L14785.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-010 — O que fazer com as embalagens vazias de agrotóxicos?

**Variantes:** Me explica uma coisa: o que fazer com as embalagens vazias de agrotóxicos? · fazer embalagens vazias agrotóxicos? · o q fazer com as embalagns vazias de agrotoxicos

As embalagens vazias de agrotóxicos não devem ser reutilizadas nem descartadas no lixo comum: a Lei nº 14.785/2023 prevê regras para devolução, armazenamento, transporte, reciclagem e inutilização dessas embalagens. A orientação geral é seguir as instruções do rótulo e da nota fiscal sobre o local de devolução (em geral, a revenda ou uma central/posto de recebimento indicado).

*kind:* `orientação` · *status:* `parcial` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 14.785/2023 – Lei dos Agrotóxicos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/L14785.htm) (acesso 2026-10-17); [Lei nº 12.305/2010 – Política Nacional de Resíduos Sólidos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2007-2010/2010/lei/l12305.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado. Prazos e procedimentos de tríplice lavagem não foram extraídos do texto consultado; orientar a seguir o rótulo e a revenda.
*Lacunas:* Prazo de devolução e endereço de postos de recebimento na região de Santa Rosa não confirmados.

## Defensivos

### SUST-LEG-011 — Precisa de receita para comprar agrotóxico?

**Variantes:** Tchê, me ajuda: precisa de receita para comprar agrotóxico? · precisa receita comprar agrotóxico? · precisa de receita pra comprar agrotoxco

Sim. A Lei nº 14.785/2023 exige receita agronômica emitida por profissional legalmente habilitado para a venda de agrotóxicos, salvo exceções previstas em regulamento. A lei também permite que o profissional prescreva a receita de forma preventiva, antes da ocorrência da praga, para alvos específicos.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2023 · *relevância Fenasoja:* média
*Fontes:* [Lei nº 14.785/2023 – Lei dos Agrotóxicos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/L14785.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-012 — Qual é a lei atual dos agrotóxicos?

**Variantes:** Alguém me explica: qual é a lei atual dos agrotóxicos? · lei atual agrotóxicos? · qual e a lei atual dos agrotoxios

A lei atual é a Lei nº 14.785/2023, que trata de pesquisa, experimentação, produção, embalagem, rotulagem, transporte, armazenamento, comercialização, uso, importação, exportação, destino de resíduos e embalagens, registro, classificação e fiscalização de agrotóxicos, produtos de controle ambiental e afins.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 14.785/2023 – Lei dos Agrotóxicos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/L14785.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

## Bioinsumos

### SUST-LEG-013 — O que é bioinsumo segundo a lei?

**Variantes:** O que são bioinsumos? · bioinsumo definição lei · oq é bioinsumo · lei dos bioinsumos 15.070

Pela Lei nº 15.070/2024, bioinsumo é o produto, processo ou tecnologia de origem vegetal, animal ou microbiana (incluídos os de processo biotecnológico) destinado ao uso na produção, proteção, armazenamento e beneficiamento de produtos agropecuários, aquáticos ou florestais, que interfira no crescimento, no desenvolvimento ou na resposta de animais, plantas, microrganismos e do solo. Exemplos práticos são inoculantes, agentes de controle biológico e biofertilizantes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 15.070/2024 – Lei dos Bioinsumos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/lei/L15070.htm) (acesso 2026-10-17); [Embrapa – Fixação biológica de nitrogênio: perguntas e respostas](https://www.embrapa.br/tema-fixacao-biologica-de-nitrogenio/perguntas-e-respostas) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

### SUST-LEG-014 — O que é uma biofábrica?

**Variantes:** Bah, uma dúvida: o que é uma biofábrica? · biofábrica? · o q e uma biofabrca

Pela Lei nº 15.070/2024, biofábrica é o estabelecimento que produz bioinsumo ou inóculo de bioinsumo com fins comerciais e que dispõe de equipamentos e instalações para controle de qualidade e segurança sanitária e ambiental da produção. A lei também trata da produção de bioinsumos para uso próprio na propriedade, com regras específicas.

*kind:* `conceito` · *status:* `parcial` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 15.070/2024 – Lei dos Bioinsumos (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/lei/L15070.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado. A parte sobre produção on farm não foi detalhada no trecho extraído; tratar como parcial.

## Sementes e biotecnologia

### SUST-LEG-015 — Posso guardar semente de cultivar protegida para plantar de novo?

**Variantes:** Queria entender: posso guardar semente de cultivar protegida para plantar de novo? · posso guardar semente cultivar protegida plantar novo? · posso guardar semente de cultivar protegda pra plantar de novo

A Lei de Proteção de Cultivares (Lei nº 9.456/1997, art. 10) diz que não fere o direito do obtentor quem reserva e planta sementes para uso próprio, em seu estabelecimento ou em estabelecimento de terceiros cuja posse detenha. Também é permitido usar ou vender o produto colhido como alimento ou matéria-prima, mas não para fins reprodutivos. Regras de registro e uso de sementes salvas também seguem a legislação de sementes, e cultivares transgênicas podem ter contratos específicos.

*kind:* `conceito` · *status:* `parcial` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Lei nº 9.456/1997 – Lei de Proteção de Cultivares (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l9456.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado. Não cobre a Lei de Sementes (10.711/2003) nem royalties de biotecnologia; status parcial.
*Lacunas:* Lei 10.711/2003 (sementes e mudas) não consultada.

### SUST-LEG-016 — O que é a CTNBio?

**Variantes:** Uma pergunta: o que é a CTNBio? · ctnbio? · o q e a ctnbio

A Comissão Técnica Nacional de Biossegurança (CTNBio) foi reestruturada pela Lei de Biossegurança (Lei nº 11.105/2005), que estabelece normas de segurança e fiscalização para atividades com organismos geneticamente modificados (OGM) e seus derivados. A mesma lei criou o Conselho Nacional de Biossegurança (CNBS) e a Política Nacional de Biossegurança.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 11.105/2005 – Lei de Biossegurança (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2005/lei/l11105.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado.

## Plano ABC+

### SUST-ABC-001 — O que é o Plano ABC+?

**Variantes:** Para que serve o Plano ABC+? · plano abc mais · oq é o abc+ · Agricultura de baixo carbono ABC

O Plano ABC+ é o Plano Setorial para Adaptação à Mudança do Clima e Baixa Emissão de Carbono na Agropecuária, com vistas ao desenvolvimento sustentável, para o período 2020–2030, instituído pela Portaria MAPA nº 471/2022. Entre as tecnologias incentivadas estão tecnologias como recuperação de pastagens, plantio direto, integração lavoura-pecuária-floresta, bioinsumos, irrigação e tratamento de dejetos animais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [DOU – Portaria MAPA nº 471/2022 (institui o Plano ABC+)](https://www.in.gov.br/en/web/dou/-/portaria-mapa-n-471-de-10-de-agosto-de-2022-421902518) (acesso 2026-10-17); [MAPA – Tecnologias do ABC+ (SPSabc)](https://www.gov.br/agricultura/pt-br/assuntos/sustentabilidade/planoabc-abcmais/abc/tecnologias-do-abc-spsabc) (acesso 2026-10-17); [MAPA – Plano ABC: objetivos, metas e diretrizes](https://www.gov.br/agricultura/pt-br/assuntos/sustentabilidade/planoabc-abcmais/objetivos-e-diretrizes) (acesso 2026-10-17)
*Notas:* Metas do Plano ABC+ (Portaria MAPA nº 471/2022) para o período 2020–2030.

### SUST-ABC-002 — Quais são as metas do Plano ABC+ até 2030?

**Variantes:** Metas do ABC+ · abc+ metas 2030 · qual a meta do plano abc mais · Quantos hectares o ABC+ quer alcançar?

Segundo o MAPA, o ABC+ prevê até 2030 ampliar a adoção de tecnologias em 72,68 milhões de hectares, incluindo 30 milhões de ha de pastagens recuperadas, 12,58 milhões de ha em plantio direto, 10,10 milhões de ha em sistemas de integração, 4 milhões de ha de florestas plantadas, 13 milhões de ha com bioinsumos e 3 milhões de ha irrigados. Também prevê tratar 208,4 milhões de m³ de resíduos animais e terminar 5 milhões de bovinos em sistemas intensivos, com potencial de mitigação de 1,04 bilhão de toneladas de CO2 equivalente.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2022 · *relevância Fenasoja:* alta
*Fontes:* [MAPA – Plano ABC: objetivos, metas e diretrizes](https://www.gov.br/agricultura/pt-br/assuntos/sustentabilidade/planoabc-abcmais/objetivos-e-diretrizes) (acesso 2026-10-17); [DOU – Portaria MAPA nº 471/2022 (institui o Plano ABC+)](https://www.in.gov.br/en/web/dou/-/portaria-mapa-n-471-de-10-de-agosto-de-2022-421902518) (acesso 2026-10-17)
*Notas:* Metas do Plano ABC+ (Portaria MAPA nº 471/2022) para o período 2020–2030.

## Água

### SUST-LEG-017 — Quais são os fundamentos da Lei das Águas?

**Variantes:** Bah, uma dúvida: quais são os fundamentos da Lei das Águas? · fundamentos lei águas? · quais sao os fundamenos da lei das aguas

A Política Nacional de Recursos Hídricos (Lei nº 9.433/1997) estabelece que a água é um bem de domínio público e um recurso natural limitado, dotado de valor econômico. Em situações de escassez, o uso prioritário é o consumo humano e a dessedentação de animais. A bacia hidrográfica é a unidade de gestão, que deve ser descentralizada e participativa. Para irrigação e uso de poços, em geral é necessária a outorga de direito de uso da água junto ao órgão competente.

*kind:* `conceito` · *status:* `parcial` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 9.433/1997 – Política Nacional de Recursos Hídricos (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/l9433.htm) (acesso 2026-10-17)
*Notas:* Lei vigente consultada no Planalto em 17/10/2026; leis podem ser alteradas. Não é aconselhamento jurídico: para casos concretos, orientar a procurar órgão ambiental, Emater/RS ou profissional habilitado. A frase sobre outorga para irrigação é orientação geral; os casos de dispensa (usos insignificantes) dependem do órgão gestor estadual.
