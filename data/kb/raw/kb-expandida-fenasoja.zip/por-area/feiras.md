# KB expandida — Feiras agropecuárias (FEIRAS)

Gerado em 2026-10-17. Índice geral: [../kb-expandida.md](../kb-expandida.md). JSON da área: [feiras.json](feiras.json).

**31 perguntas canônicas · 165 perguntas no total (canônicas + variantes).**

| confirmado | parcial | sem_fonte | conflito | dinâmico |
|---|---|---|---|---|
| 28 | 3 | 0 | 0 | 0 |

| conceito | dado | orientação |
|---|---|---|
| 19 | 10 | 2 |

**Por tipo de fonte:** Curadoria manual sobre fontes oficiais: 14; Wikipédia (pt) – verbete: 17

## Subcategorias

| Subcategoria | Entradas |
|---|---|
| Como funcionam feiras | 10 |
| Feiras do agro | 7 |
| Expointer | 4 |
| Outras feiras | 3 |
| Agrishow | 2 |
| Show Rural | 1 |
| Expodireto | 1 |
| Como funcionam as feiras | 1 |
| Dicas para visitantes | 1 |
| Dicas para expositores | 1 |

## Entradas

## Como funcionam feiras

### FEIRAS-WK-0008 — O que é feira?

**Variantes:** Feira: o que significa? · Me explica o que é feira · oq é feira · feira? · Defina feira

Uma feira é um evento em um espaço público em que as pessoas, em dias e épocas predeterminados, expõem e vendem mercadorias. Também é uma designação complementar dos cinco dias úteis da semana: segunda-feira, terça-feira, quarta-feira, quinta-feira e sexta-feira. Pode ser, ainda, uma exposição ou um parque de diversão. Stagshaw na Inglaterra é documentada por receber feiras anuais a partir de 1293, consistindo-se em comércio de animais.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Feira](https://pt.wikipedia.org/wiki/Feira) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Feira" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0009 — O que é feira de negócios?

**Variantes:** Feira de negócios: o que significa? · Me explica o que é feira de negócios · oq é feira de negocios · feira de negócios? · Defina feira de negócios

Uma feira profissional é uma exposição organizada de forma a que as empresas de uma indústria específica possam expor e demonstrar os seus novos produtos e serviços. Algumas feiras são abertas ao público, enquanto outras só podem ser freqüentadas por profissionais do sector e membros da imprensa. Existem atualmente cerca de 2500 feiras sendo realizadas todos os anos somente nos Estados Unidos da América. Numa linha temporal, existem registos de feiras desde os primórdios do Homem, na medida em que necessitava de trocar os produtos que detinha em excesso, por aqueles que lhe escasseavam.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Feira profissional](https://pt.wikipedia.org/wiki/Feira_profissional) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Feira profissional" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0010 — O que é exposição?

**Variantes:** Exposição: o que significa? · Me explica o que é exposição · oq é exposicao · exposição? · Defina exposição

Uma exposição (do latim expositione), em um amplo sentido, é uma apresentação organizada e exibição de uma seleção de itens. Na prática, as exposições geralmente ocorrem em um ambiente cultural ou educacional, tal como museu, galeria de arte, parque, biblioteca, sala de exposições ou espaços para exposições mundiais. As exposições podem ser dos mais diversos formatos e realizadas com diferentes objetos, como a de arte em museus importantes e galerias menores, as exposições interpretativas, as realizadas em museus de história natural e museus de história, e também de variedades, como as feiras de negócios.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Exposição](https://pt.wikipedia.org/wiki/Exposi%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Exposição" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0011 — O que é feira agropecuária?

**Variantes:** Feira agropecuária: o que significa? · Me explica o que é feira agropecuária · oq é feira agropecuaria · feira agropecuária? · Defina feira agropecuária · O que é exposição agropecuária?

Exposição agropecuária é um evento do agronegócio que possui como tema principal a exposição de animais e produtos agrícolas, geralmente em estandes ou galpões preparados para este fim. Estas exposições normalmente acontecem uma vez por ano, e tem duração de três a dez dias, contando com participação de grandes públicos, especialmente nos espetáculos musicais, que acontecem nas tarde/noites. Um ponto que merece também ser lembrado é presença de companhia de rodeios, com estrutura completa, com destaques aos peões de montaria em touro e cavalo. Geralmente se tem-se durante o evento um concurso para escolha da "rainha" e princesas da festa.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Exposição agropecuária](https://pt.wikipedia.org/wiki/Exposi%C3%A7%C3%A3o_agropecu%C3%A1ria) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Exposição agropecuária" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0012 — O que é leilão?

**Variantes:** Leilão: o que significa? · Me explica o que é leilão · oq é leilao · leilão? · Defina leilão

O leilão ou hasta é uma modalidade de negociação, muito difundida em órgãos públicos e empresas privadas, além de lotas de pesca, na qual a venda e a compra solicitadas pela oferta e a procura de bens ou serviços se encontram de maneira simples e rápida. No caso de leilões públicos de venda, o leiloeiro irá ler as condições de venda descritas no catálogo, as quais deverão ser acompanhadas por todos os compradores. O leiloeiro é um agente público, pertencente à categoria ficção doutrinária do Direito Administrativo Brasileiro. Em seguida os lotes em leilão serão anunciados um a um.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Leilão](https://pt.wikipedia.org/wiki/Leil%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Leilão" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0013 — O que é julgamento de animais?

**Variantes:** Julgamento de animais: o que significa? · Me explica o que é julgamento de animais · oq é julgamento de animais · julgamento de animais? · Defina julgamento de animais

Julgamento de animais se refere a uma série de julgamentos com animais que aconteceram no período da Idade Média na Europa Feudal, onde os julgamentos normalmente aconteciam com animais domesticados. Acredita-se que o julgamento de animais tenha tido origem nas crenças judaicas-cristãs, mais especificadamente no livro Êxodo, capítulo 21, versículo 28. Durante os julgamentos, os animais possuíam o direito de um advogado e o processo se assemelhava ao julgamentos de seres humanos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Julgamento de animais](https://pt.wikipedia.org/wiki/Julgamento_de_animais) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Julgamento de animais" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0014 — O que é turismo de negócios?

**Variantes:** Turismo de negócios: o que significa? · Me explica o que é turismo de negócios · oq é turismo de negocios · turismo de negócios? · Defina turismo de negócios

Turismo de negócio apresenta grande importância para crescimento da economia, pois esse tipo especifico de turista agrega a localidade além da receita financeira, quando satisfeito passa a proporcionar visitas com maior frequência, além do fato de ser um multiplicador de opiniões positivas que atrairão novos turistas ao local.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Turismo de negócios](https://pt.wikipedia.org/wiki/Turismo_de_neg%C3%B3cios) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Turismo de negócios" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0015 — O que é turismo de eventos?

**Variantes:** Turismo de eventos: o que significa? · Me explica o que é turismo de eventos · oq é turismo de eventos · turismo de eventos? · Defina turismo de eventos

O Turismo de eventos é entendido como o deslocamento de pessoas com interesse em participar de eventos focados no enriquecimento técnico, cientifico ou profissional, cultural incluindo ainda o consumo e entretenimento. Tendo como principais sub-categoria o turismo de congresso e o turismo de convenção. O turista deste segmento caracteriza-se pela sua efetiva presença como ouvinte, “participante” ou palestrante em congressos, convenções, assembleias, simpósios, seminários, reuniões, ciclos, sínodos, concílios, feiras, festivais, encontros culturais entre outras tipologias de evento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Turismo de eventos](https://pt.wikipedia.org/wiki/Turismo_de_eventos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Turismo de eventos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0016 — O que é centro de convenções?

**Variantes:** Centro de convenções: o que significa? · Me explica o que é centro de convenções · oq é centro de convencoes · centro de convenções? · Defina centro de convenções

Centro de convenções é o local onde se organizam eventos, palestras, feiras, shows ou congressos. Trata-se de grandes edifícios públicos com espaço bastante para acolher as empresas públicas e privadas em eventos sociais do município e áreas metropolitanas. Os grandes espaços adaptados a feiras são conhecidos como "centros de exposições" ou "parque de exposições", enquanto o termo "centro de convenção" é, também, por vezes empregado em referência aos locais e centros de exposições. "Centros de conferência" comumente designam locais menores destinados a palestras e reuniões.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Centro de convenções](https://pt.wikipedia.org/wiki/Centro_de_conven%C3%A7%C3%B5es) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Centro de convenções" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0017 — O que é e onde fica Patrocínio?

**Variantes:** Onde fica Patrocínio? · Me fala sobre Patrocínio · patrocinio fica onde · Patrocínio?

Patrocínio é um município brasileiro do estado de Minas Gerais, pertencente à mesorregião do Triângulo Mineiro e Alto Paranaíba. O território possui expressiva notoriedade econômica pela sua forte base na agropecuária nacional, destacando-se historicamente entre os maiores produtores do país na cultura do café, com ênfase na espécie comercial Coffea arabica.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Patrocínio](https://pt.wikipedia.org/wiki/Patroc%C3%ADnio) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Patrocínio" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Feiras do agro

### FEIRAS-WK-0001 — O que é Expointer?

**Variantes:** Expointer: o que significa? · Me explica o que é Expointer · oq é expointer · Expointer? · Defina Expointer

A Expointer é uma feira agropecuária de destaque nacional e internacional, realizada no Parque Estadual de Exposições Assis Brasil, na cidade de Esteio, no Rio Grande do Sul. É considerada a maior feira de exposição de animais da América Latina. A exposição ocorre sempre no final do mês de agosto e no início de setembro, abrangendo dois fins de semana, que são os períodos em que recebe mais visitantes.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* GER-015
*Fontes:* [Wikipédia (pt) – Expointer](https://pt.wikipedia.org/wiki/Expointer) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Expointer" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0002 — O que é Agrishow?

**Variantes:** Agrishow: o que significa? · Me explica o que é Agrishow · oq é agrishow · Agrishow? · Defina Agrishow

Agrishow é uma feira internacional de tecnologia agrícola realizada em Ribeirão Preto, no estado de São Paulo. É considerada a segunda maior feira do tipo no mundo e a maior da América Latina. A primeira edição ocorreu em 4 de maio de 1994. Seu presidente atual é o empresário João Carlos Marchesan.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* GER-015
*Fontes:* [Wikipédia (pt) – Agrishow](https://pt.wikipedia.org/wiki/Agrishow) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Agrishow" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0003 — O que é Show Rural Coopavel?

**Variantes:** Show Rural Coopavel: o que significa? · Me explica o que é Show Rural Coopavel · oq é show rural coopavel · Show Rural Coopavel? · Defina Show Rural Coopavel

O Show Rural Coopavel é um evento de difusão de tecnologia agropecuária que acontece anualmente no município brasileiro de Cascavel, no estado do Paraná. Tem como objetivo aumentar a produtividade de pequenas, médias e grandes propriedades rurais. É totalmente organizado pela Cooperativa Agroindustrial de Cascavel - Coopavel, realizado em parque próprio, localizado na Rodovia BR-277, km 577, próximo ao viaduto de acesso à cidade. É considerada a maior feira do agronegócio da América Latina e a maior terceira do mundo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Show Rural Coopavel](https://pt.wikipedia.org/wiki/Show_Rural_Coopavel) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Show Rural Coopavel" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0004 — O que é Bahia Farm Show?

**Variantes:** Bahia Farm Show: o que significa? · Me explica o que é Bahia Farm Show · oq é bahia farm show · Bahia Farm Show? · Defina Bahia Farm Show

Bahia Farm Show é uma feira de tecnologia agrícola e negócios, que ocorre anualmente na cidade de Luís Eduardo Magalhães, no estado brasileiro da Bahia. É considerada a maior feira desse tipo do Norte e Nordeste e a segunda maior do país, atrás da Agrishow, que ocorre em Ribeirão Preto. A feira é organizada pela Associação de Agricultores e Irrigantes da Bahia (Aiba), juntamente com a Associação Baiana dos Produtores de Algodão (Abapa), Fundação Bahia, Associação dos Revendedores de Máquinas e Equipamentos Agrícolas do Oeste da Bahia (Assomiba) e Prefeitura de Luís Eduardo Magalhães. Seu presidente é Júlio Cézar Busato (que também é presidente da Aiba).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* GER-015
*Fontes:* [Wikipédia (pt) – Bahia Farm Show](https://pt.wikipedia.org/wiki/Bahia_Farm_Show) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Bahia Farm Show" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0005 — O que é Fenarroz?

**Variantes:** Fenarroz: o que significa? · Me explica o que é Fenarroz · oq é fenarroz · Fenarroz? · Defina Fenarroz

Feira Nacional do Arroz (Fenarroz) é uma feira de grandes negócios e de atrações turísticas que acontece na cidade de Cachoeira do Sul, estado do Rio Grande do Sul. Ela é o segundo maior evento orizícola do mundo, ocorrendo em intervalos de dois anos no parque que leva seu nome.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Feira Nacional do Arroz](https://pt.wikipedia.org/wiki/Feira_Nacional_do_Arroz) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Feira Nacional do Arroz" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0006 — O que é Oktoberfest de Santa Cruz do Sul?

**Variantes:** Oktoberfest de Santa Cruz do Sul: o que significa? · Me explica o que é Oktoberfest de Santa Cruz do Sul · oq é oktoberfest de santa cruz do sul · Oktoberfest de Santa Cruz do Sul? · Defina Oktoberfest de Santa Cruz do Sul

A Oktoberfest de Santa Cruz do Sul é a edição da Oktoberfest realizada em Santa Cruz do Sul, no Rio Grande do Sul. A festividade celebra as tradições germânicas todo mês de outubro, desde 1984, não havendo edição apenas em 1993, por dificuldades financeiras, e em 2020, em virtude da pandemia de COVID-19. A maior festa do tipo no estado, foi declarada patrimônio cultural estadual em 2006, sendo a segunda maior do país em número de visitantes. Desde 2022, tem duração de três semanas de forma intervalada, de quinta-feira a domingo, inclusive.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Oktoberfest de Santa Cruz do Sul](https://pt.wikipedia.org/wiki/Oktoberfest_de_Santa_Cruz_do_Sul) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Oktoberfest de Santa Cruz do Sul" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### FEIRAS-WK-0007 — O que é Festa Nacional da Uva?

**Variantes:** Festa Nacional da Uva: o que significa? · Me explica o que é Festa Nacional da Uva · oq é festa nacional da uva · Festa Nacional da Uva? · Defina Festa Nacional da Uva

A Festa da Uva, oficialmente Festa Nacional da Uva, é uma feira e uma festa comunitária brasileira realizada atualmente a cada dois anos em Caxias do Sul, no estado do Rio Grande do Sul, comemorando a história, a cultura e a produção agroindustrial da cidade e da região. A Festa da Uva, como hoje é conhecida, evoluiu a partir de uma série de feiras agroindustriais realizadas entre 1881 e 1931, que buscavam primariamente promover a cidade através da exposição dos seus produtos mais típicos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Festa da Uva](https://pt.wikipedia.org/wiki/Festa_da_Uva) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Festa da Uva" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Expointer

### FEIRAS-EXI-001 — O que é a Expointer?

**Variantes:** O que é a Expointer de Esteio? · expointer oq é · q feira é a expointer · Feira de Esteio

A Expointer (Exposição Internacional de Animais, Máquinas, Implementos e Produtos Agropecuários) é a principal feira agropecuária do Rio Grande do Sul, realizada pelo governo do estado no Parque de Exposições Assis Brasil, em Esteio, na Região Metropolitana de Porto Alegre. Reúne julgamentos e leilões de animais, máquinas agrícolas, agricultura familiar e artesanato.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* GER-015
*Fontes:* [Expointer – site oficial (Governo do RS)](https://www.expointer.rs.gov.br/) (acesso 2026-10-17); [Expointer – Expointer registra R$ 6,2 bi em negócios (06/09/2026)](https://www.expointer.rs.gov.br/expointer-registra-r-6-2-bi-em-negocios-sendo-r-14-4-milhoes-nos-509-estandes-da-agricultura-familiar) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

### FEIRAS-EXI-002 — Quando foi a Expointer 2026?

**Variantes:** Me tira uma dúvida: quando foi a Expointer 2026? · foi expointer 2026? · quando foi a expoiner 2026

Segundo o site oficial, a 49ª Expointer foi realizada de 29 de agosto a 6 de setembro de 2026, no Parque de Exposições Assis Brasil, em Esteio-RS, com visitação das 8h às 20h.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-09 · *relevância Fenasoja:* média
*KB Fenasoja:* GER-015
*Fontes:* [Expointer – site oficial (Governo do RS)](https://www.expointer.rs.gov.br/) (acesso 2026-10-17); [Expointer – Expointer registra R$ 6,2 bi em negócios (06/09/2026)](https://www.expointer.rs.gov.br/expointer-registra-r-6-2-bi-em-negocios-sendo-r-14-4-milhoes-nos-509-estandes-da-agricultura-familiar) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

### FEIRAS-EXI-003 — Quanto a Expointer 2026 movimentou em negócios?

**Variantes:** Faturamento da Expointer 2026 · expointer 2026 negocios · qto a expointer vendeu esse ano · Quantas pessoas foram na Expointer 2026?

Segundo o governo do RS, a Expointer 2026 registrou R$ 6,2 bilhões em negócios e mais de 938 mil visitantes. Máquinas e implementos responderam por R$ 5,46 bilhões; automóveis, R$ 668,8 milhões; a agricultura familiar, R$ 14,4 milhões em 509 estandes; e a venda de animais, R$ 21,99 milhões, com 7.926 animais inscritos.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-09-06 · *relevância Fenasoja:* média
*KB Fenasoja:* GER-015
*Fontes:* [Expointer – Expointer registra R$ 6,2 bi em negócios (06/09/2026)](https://www.expointer.rs.gov.br/expointer-registra-r-6-2-bi-em-negocios-sendo-r-14-4-milhoes-nos-509-estandes-da-agricultura-familiar) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

### FEIRAS-EXI-004 — Quando será a Expointer 2027?

**Variantes:** Tu sabe me dizer: quando será a Expointer 2027? · será expointer 2027? · quando sera a expoiner 2027

Segundo o site oficial, a 50ª Expointer está prevista para 28 de agosto a 5 de setembro de 2027, no Parque de Exposições Assis Brasil, em Esteio-RS, segundo anúncio feito no balanço da edição de 2026.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*KB Fenasoja:* GER-015
*Fontes:* [Expointer – Expointer registra R$ 6,2 bi em negócios (06/09/2026)](https://www.expointer.rs.gov.br/expointer-registra-r-6-2-bi-em-negocios-sendo-r-14-4-milhoes-nos-509-estandes-da-agricultura-familiar) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

## Outras feiras

### FEIRAS-BFS-001 — O que é a Bahia Farm Show?

**Variantes:** Me tira uma dúvida: o que é a Bahia Farm Show? · bahia farm show? · o q e a bahia farm show

A Bahia Farm Show é uma feira de tecnologia agrícola organizada pela Associação de Agricultores e Irrigantes da Bahia (Aiba) em Luís Eduardo Magalhães (BA). Em 2026, recebeu 172.328 visitantes, 554 expositores e 1.421 marcas; a 21ª edição está prevista para 7 a 12 de junho de 2027.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026 · *relevância Fenasoja:* baixa
*KB Fenasoja:* VIS-007, F28-004
*Fontes:* [Bahia Farm Show – site oficial](https://bahiafarmshow.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

### FEIRAS-TEC-001 — O que é a Tecnoshow Comigo?

**Variantes:** Me tira uma dúvida: o que é a Tecnoshow Comigo? · tecnoshow comigo? · o q e a tecnosow comigo

A Tecnoshow Comigo é uma feira de tecnologia rural realizada pela cooperativa Comigo em Rio Verde (GO) desde 2002. Segundo o site oficial, recebeu 120 mil visitantes em 2026, e a edição de 2027 será de 5 a 9 de abril.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026 · *relevância Fenasoja:* baixa
*Fontes:* [Tecnoshow Comigo – site oficial](https://www.tecnoshowcomigo.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

### FEIRAS-ABR-001 — O que é a AgroBrasília?

**Variantes:** Tu sabe me dizer: o que é a AgroBrasília? · agrobrasília? · o q e a agrobrasiia

A AgroBrasília é uma feira de agronegócio realizada no Distrito Federal. O site oficial cita 552 expositores, 147 mil visitantes e R$ 3 bilhões em negócios, mas o texto consultado não deixa claro a qual edição esses números se referem.

*kind:* `dado` · *status:* `parcial` · *as_of:* s.d. · *relevância Fenasoja:* baixa
*KB Fenasoja:* VIS-007, F28-004
*Fontes:* [AgroBrasília – site oficial](https://www.agrobrasilia.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.
*Lacunas:* Ano dos números da AgroBrasília não identificado.

## Agrishow

### FEIRAS-AGS-001 — O que é a Agrishow?

**Variantes:** O que é Agrishow? · agrishow ribeirao preto · q feira é a agrishow · Agrishow 2026 números

A Agrishow se apresenta como a maior feira agropecuária do Brasil e uma das maiores do mundo, realizada em Ribeirão Preto (SP), com soluções para diversas culturas, máquinas e tecnologia para o campo. A edição de 2026, a 31ª, reuniu mais de 800 marcas e mais de 197 mil visitantes em 520 mil m².

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026 · *relevância Fenasoja:* média
*KB Fenasoja:* GER-015
*Fontes:* [Agrishow – site oficial](https://www.agrishow.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

### FEIRAS-AGS-002 — Quando será a Agrishow 2027?

**Variantes:** Queria entender: quando será a Agrishow 2027? · será agrishow 2027? · quando sera a agrisow 2027

Segundo o site oficial, a Agrishow 2027 será de 26 a 30 de abril de 2027, em Ribeirão Preto (SP), das 8h às 18h. Como as datas são próximas da Fenasoja (que ocorre no fim de abril/início de maio em anos pares), vale conferir o calendário de feiras ao planejar viagens.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*KB Fenasoja:* GER-001, GER-015
*Fontes:* [Agrishow – site oficial](https://www.agrishow.com.br/) (acesso 2026-10-17); [Fenasoja – site oficial](https://fenasoja.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

## Show Rural

### FEIRAS-SRC-001 — O que é o Show Rural Coopavel?

**Variantes:** Queria entender: o que é o Show Rural Coopavel? · show rural coopavel? · o q e o show rural coopael

O Show Rural Coopavel é uma feira de tecnologia agropecuária realizada pela cooperativa Coopavel desde 1989, em Cascavel (PR). Segundo o site oficial, a 39ª edição será de 1º a 5 de fevereiro de 2027; a feira reúne mais de 600 expositores e mais de 430 mil visitantes.

*kind:* `dado` · *status:* `parcial` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*KB Fenasoja:* VIS-007, F28-004
*Fontes:* [Show Rural Coopavel – site oficial](https://www.showrural.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição. A cidade (Cascavel) não foi confirmada no texto extraído; verificar.

## Expodireto

### FEIRAS-EXD-001 — O que é a Expodireto Cotrijal?

**Variantes:** O que é a Expodireto? · expodireto nao me toque · q feira é a expodireto · Expodireto 2027 data

A Expodireto Cotrijal é uma feira do agronegócio ligada à cooperativa Cotrijal, realizada em parque próprio em Não-Me-Toque (RS). Segundo o site oficial, a 26ª edição ocorreu em março de 2026, a edição de 2027 será de 8 a 12 de março e a área de exposição foi ampliada em 42 mil metros quadrados para 2027.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Expodireto Cotrijal – site oficial](https://www.expodireto.cotrijal.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição.

## Como funcionam as feiras

### FEIRAS-GER-001 — Quais são as principais feiras do agronegócio no Rio Grande do Sul?

**Variantes:** Quais as maiores feiras agro do RS? · feiras agro rio grande do sul · q feiras tem no rs de agro · Calendário de feiras agropecuárias gaúchas

Entre as principais feiras do agro gaúcho estão a Expointer, em Esteio (fim de agosto/início de setembro), a Expodireto Cotrijal, em Não-Me-Toque (março), e a Fenasoja, em Santa Rosa, realizada a cada dois anos no fim de abril e início de maio, com a Exporural como espaço do agronegócio. A Expointer tem forte presença de julgamentos, leilões e exposições de animais, além de máquinas; a Fenasoja combina agronegócio, indústria, comércio e shows.

*kind:* `conceito` · *status:* `parcial` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* GER-001, EXP-001, F28-001
*Fontes:* [Expointer – site oficial (Governo do RS)](https://www.expointer.rs.gov.br/) (acesso 2026-10-17); [Expodireto Cotrijal – site oficial](https://www.expodireto.cotrijal.com.br/) (acesso 2026-10-17); [Fenasoja – site oficial](https://fenasoja.com.br/) (acesso 2026-10-17)
*Notas:* Dados de feiras mudam a cada edição: confirmar datas e números no site oficial da feira antes de responder sobre a próxima edição. "Perfil" de cada feira é síntese editorial a partir dos sites; lista não exaustiva.

## Dicas para visitantes

### FEIRAS-GER-002 — Como se preparar para visitar uma feira de negócios?

**Variantes:** Dicas para visitar uma feira · como aproveitar uma feira · dica pra ir na feira · O que levar para uma feira agropecuária?

O Sebrae recomenda planejar a visita com antecedência: definir objetivos, conferir a programação e o mapa da feira, verificar a credibilidade do organizador e reservar hospedagem com antecedência. No dia, vale usar calçados confortáveis, levar cartões de visita, conferir a previsão do tempo e anotar contatos e propostas para dar retorno depois.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* 2013 · *relevância Fenasoja:* alta
*KB Fenasoja:* VIS-001, VIS-004
*Fontes:* [Sebrae-SP – Feiras e Eventos de Negócios: Diário de Bordo do Empresário Visitante (2013)](https://bibliotecas.sebrae.com.br/chronus/ARQUIVOS_CHRONUS/bds/bds.nsf/d1c1e44be593dd66f3f49c78a4f8fd57/$File/SP_feiraseeventos_16.pdf.pdf) (acesso 2026-10-17)
*Notas:* Guia do Sebrae-SP de 2013 (orientações gerais, ainda válidas).

## Dicas para expositores

### FEIRAS-GER-003 — Como ser expositor na Fenasoja?

**Variantes:** Quero expor na Fenasoja · como alugar estande na fenasoja · como faz pra expor na feira · Reserva de espaço Fenasoja 2028

Para expor na Fenasoja, o caminho é a página "Quero ser expositor" do site oficial ou os contatos da organização. Para a edição de 2028, a comercialização começou em 1º de outubro de 2026 com a renovação de quem já expôs, e as condições detalhadas devem ser confirmadas com a equipe comercial.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* VIS-007, F28-004
*Fontes:* [Fenasoja – Quero ser expositor](https://fenasoja.com.br/quero-ser-expositor/) (acesso 2026-10-17); [Fenasoja – Fenasoja 2028 inicia comercialização dos espaços para expositores](https://fenasoja.com.br/portal-oficial/uncategorized/fenasoja-2028-inicia-comercializacao-dos-espacos-para-expositores/) (acesso 2026-10-17); [Fenasoja – Contato](https://fenasoja.com.br/contato/) (acesso 2026-10-17)
*Notas:* Resposta derivada da KB Fenasoja (VIS-007, F28-004); usar a KB Fenasoja como fonte primária.
