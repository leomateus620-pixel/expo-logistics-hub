# KB expandida — Tecnologia, IA, dados e segurança (TEC)

Gerado em 2026-10-17. Índice geral: [../kb-expandida.md](../kb-expandida.md). JSON da área: [tecnologia.json](tecnologia.json).

**60 perguntas canônicas · 341 perguntas no total (canônicas + variantes).**

| confirmado | parcial | sem_fonte | conflito | dinâmico |
|---|---|---|---|---|
| 59 | 1 | 0 | 0 | 0 |

| conceito | dado | orientação |
|---|---|---|
| 57 | 1 | 2 |

**Por tipo de fonte:** Curadoria manual sobre fontes oficiais: 10; Wikipédia (pt) – verbete: 50

## Subcategorias

| Subcategoria | Entradas |
|---|---|
| IA e dados | 30 |
| Cibersegurança e LGPD | 20 |
| LGPD | 5 |
| Segurança digital | 3 |
| Internet | 1 |
| IA na agricultura | 1 |

## Entradas

## IA e dados

### TEC-WK-0001 — O que é inteligência artificial?

**Variantes:** Inteligência artificial: o que significa? · Me explica o que é inteligência artificial · oq é inteligencia artificial · inteligência artificial? · Defina inteligência artificial

Inteligência artificial (frequentemente abreviada por IA ou AI, do inglês artificial intelligence) é, de forma genérica, a capacidade de máquinas demonstrarem inteligência, raciocínio e aprendizado de forma semelhante ao pensamento humano. O campo busca desenvolver máquinas autónomas ou sistemas especialistas capazes de simular o comportamento humano e realizar tarefas complexas de forma independente. Trata-se de um sistema que permite aos computadores executar funções avançadas, como a análise de dados em grande escala e a formulação de previsões ou recomendações.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Inteligência artificial](https://pt.wikipedia.org/wiki/Intelig%C3%AAncia_artificial) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Inteligência artificial" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0002 — O que é aprendizado de máquina?

**Variantes:** Aprendizado de máquina: o que significa? · Me explica o que é aprendizado de máquina · oq é aprendizado de maquina · aprendizado de máquina? · Defina aprendizado de máquina

Aprendizado automático (português brasileiro) ou aprendizagem automática (português europeu) ou também aprendizado/aprendizagem de máquina é um subcampo da Engenharia e da ciência da computação que evoluiu do estudo de reconhecimento de padrões e da teoria do aprendizado computacional em inteligência artificial. Em 1959, Arthur Samuel definiu aprendizado de máquina como o "campo de estudo que dá aos computadores a habilidade de aprender sem serem explicitamente programados"(livre tradução). O aprendizado automático explora o estudo e construção de algoritmos que podem aprender de seus erros e fazer previsões sobre dados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Aprendizado de máquina](https://pt.wikipedia.org/wiki/Aprendizado_de_m%C3%A1quina) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Aprendizado de máquina" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0003 — O que é aprendizagem profunda?

**Variantes:** Aprendizagem profunda: o que significa? · Me explica o que é aprendizagem profunda · oq é aprendizagem profunda · aprendizagem profunda? · Defina aprendizagem profunda

No aprendizado de máquina, a aprendizagem profunda se concentra na utilização de redes neurais multicamadas para executar tarefas como classificação, regressão e aprendizagem de representação. O campo se inspira na neurociência biológica e é centrado em empilhar neurônios artificiais em camadas e "treiná-los" para processar dados. O adjetivo "profunda" se refere ao uso de múltiplas camadas (variando de três a várias centenas ou milhares) na rede. Os métodos usados podem ser supervisionados, semissupervisionados ou não serem supervisionados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Aprendizagem profunda](https://pt.wikipedia.org/wiki/Aprendizagem_profunda) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Aprendizagem profunda" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0004 — O que é rede neural artificial?

**Variantes:** Rede neural artificial: o que significa? · Me explica o que é rede neural artificial · oq é rede neural artificial · rede neural artificial? · Defina rede neural artificial

Em ciência da computação e campos relacionados, redes neurais artificiais (português brasileiro) ou redes neuronais artificiais (português europeu) (RNAs) são modelos computacionais inspirados pelo sistema nervoso central de um animal (em particular o cérebro) que são capazes de realizar o aprendizado de máquina bem como o reconhecimento de padrões. Redes neurais artificiais geralmente são apresentadas como sistemas de "neurônios interconectados, que podem computar valores de entradas", simulando o comportamento de redes neurais biológicas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Rede neural artificial](https://pt.wikipedia.org/wiki/Rede_neural_artificial) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Rede neural artificial" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0005 — O que é modelo de linguagem de grande escala?

**Variantes:** Modelo de linguagem de grande escala: o que significa? · Me explica o que é modelo de linguagem de grande escala · oq é modelo de linguagem de grande escala · modelo de linguagem de grande escala? · Defina modelo de linguagem de grande escala

Um grande modelo de linguagem (do inglês large language model - LLM) é um modelo computacional projetado para realizar tarefas de processamento de linguagem natural, especialmente a geração de linguagem, usando relações contextuais derivadas de um grande conjunto de dados de treinamento. Os LLMs podem gerar, resumir, traduzir e analisar texto em uma variedade de contextos, e são a base tecnológica dos chatbots modernos. Os LLMs podem imitar com precisão os padrões da linguagem natural porque são treinados em coleções de texto escrito por humanos. Pelo mesmo motivo, dados de treinamento enviesados ou imprecisos podem tornar a saída de um LLM menos confiável.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Modelos de linguagem em grande escala](https://pt.wikipedia.org/wiki/Modelos_de_linguagem_em_grande_escala) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Modelos de linguagem em grande escala" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0006 — O que é inteligência artificial generativa?

**Variantes:** Inteligência artificial generativa: o que significa? · Me explica o que é inteligência artificial generativa · oq é inteligencia artificial generativa · inteligência artificial generativa? · Defina inteligência artificial generativa

Inteligência artificial generativa ou IA generativa é um ramo da inteligência artificial focado na criação de conteúdo novo, baseado em padrões identificados nos conjuntos de dados de treinamento. É possível criar conteúdo como texto, imagens, áudio, vídeo, código de software, podendo ser gerados a partir de pedidos (ou prompts) em linguagem natural, ou até através de imagens para imagens, e de vídeos para vídeos. Essa forma de visualizar esses modelos é uma categorização baseado em formato de entrada e saída, de texto para texto (text-to-text), texto para imagem (text-to-image), entre vários outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Inteligência artificial generativa](https://pt.wikipedia.org/wiki/Intelig%C3%AAncia_artificial_generativa) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Inteligência artificial generativa" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0007 — O que é ChatGPT?

**Variantes:** ChatGPT: o que significa? · Me explica o que é ChatGPT · oq é chatgpt · ChatGPT? · Defina ChatGPT

ChatGPT (do inglês: Chat Generative Pre-trained Transformer) é um chatbot desenvolvido pela OpenAI e lançado em 30 de novembro de 2022. O nome "ChatGPT" combina "Chat", referindo-se à sua funcionalidade de chatbot, e "GPT", que significa Generative Pre-trained Transformer (Transformador Pré-treinado Generativo, em tradução livre), um tipo de modelo de linguagem grande. Baseado em um modelo de linguagem de grande escala (LLM), o ChatGPT utiliza o contexto da conversa, os prompts e as respostas anteriores para prever as palavras mais adequadas à elaboração de uma nova resposta, de acordo com os padrões aprendidos durante seu treinamento.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – ChatGPT](https://pt.wikipedia.org/wiki/ChatGPT) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "ChatGPT" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0008 — O que é processamento de linguagem natural?

**Variantes:** Processamento de linguagem natural: o que significa? · Me explica o que é processamento de linguagem natural · oq é processamento de linguagem natural · processamento de linguagem natural? · Defina processamento de linguagem natural

Processamento de língua natural (PLN) é uma subárea da ciência da computação, inteligência artificial e da linguística que estuda os problemas da geração e compreensão automática de línguas humanas naturais. Sistemas de geração de língua natural convertem informação de bancos de dados de computadores em linguagem compreensível ao ser humano e sistemas de compreensão de língua natural convertem ocorrências de linguagem humana em representações mais formais, mais facilmente manipuláveis por programas de computador. Alguns desafios do PLN são compreensão de língua natural, fazer com que computadores extraiam sentido de linguagem humana ou natural e geração de língua natural.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Processamento de linguagem natural](https://pt.wikipedia.org/wiki/Processamento_de_linguagem_natural) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Processamento de linguagem natural" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0009 — O que é visão computacional?

**Variantes:** Visão computacional: o que significa? · Me explica o que é visão computacional · oq é visao computacional · visão computacional? · Defina visão computacional

Visão computacional é a ciência e tecnologia das máquinas que enxergam. Ela desenvolve teoria e tecnologia para a construção de sistemas artificiais que obtém informação de imagens ou quaisquer dados multidimensionais. Exemplos de aplicações incluem o controle de processos (como robôs industriais ou veículos autônomos), detecção de eventos, organização de informação, modelagem de objetos ou ambientes e interação (atrelado a interação humano-computador). A visão computacional também pode ser descrita como um complemento da visão biológica.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Visão computacional](https://pt.wikipedia.org/wiki/Vis%C3%A3o_computacional) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Visão computacional" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0010 — O que é chatbot?

**Variantes:** Chatbot: o que significa? · Me explica o que é chatbot · oq é chatbot · chatbot? · Defina chatbot

Chatbot (em português, "robô de conversa"; originalmente chatterbot) é um programa de computador que tenta simular um ser humano na conversação com as pessoas. Os chatbots também são conhecidos como bots inteligentes, agentes interativos, assistentes digitais ou entidades de conversação artificiais.O objetivo é responder as perguntas de tal forma que as pessoas tenham a impressão de estar conversando com outra pessoa e não com um programa de computador. Após o envio de perguntas em linguagem natural, o programa consulta uma base de conhecimento e em seguida fornece uma resposta que tenta imitar o comportamento humano.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Chatbot](https://pt.wikipedia.org/wiki/Chatbot) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Chatbot" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0011 — O que é big data?

**Variantes:** Big data: o que significa? · Me explica o que é big data · oq é big data · big data? · Defina big data

Big data (macrodados, megadados, ou grandes dados em português) é a área do conhecimento que estuda como tratar, analisar e obter informações a partir de conjuntos de dados muito grandes. O termo big data surgiu em 1997, e foi inicialmente utilizado para nomear conjuntos de dados não ordenados em rápido crescimento. Nas últimas décadas, os conjuntos de dados têm crescido de forma exponencial.[carece de fontes]? Com o aparecimento da Internet, a quantidade de dados disponíveis aumentou abruptamente: da "era" do terabyte para o petabyte, e a desde 2015, a era do zettabyte.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Big data](https://pt.wikipedia.org/wiki/Big_data) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Big data" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0012 — O que é ciência de dados?

**Variantes:** Ciência de dados: o que significa? · Me explica o que é ciência de dados · oq é ciencia de dados · ciência de dados? · Defina ciência de dados

A ciência de dados é uma área interdisciplinar (abrange "big data" e "mineração de dados"), que localiza-se em uma interface entre a estatística e a ciência da computação e utiliza o método científico; processos, algoritmos e sistemas, para extrair conhecimento e tomar decisões a partir de dados dos diversos tipos, sendo eles ruidosos, nebulosos, estruturados ou não-estruturados. Sendo assim uma área voltada para o estudo e a análise organizada de dados científicos e mercadológicos, financeiros, sociais, geográficos, históricos, biológicos, psicológicos, dentre muitos outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Ciência de dados](https://pt.wikipedia.org/wiki/Ci%C3%AAncia_de_dados) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Ciência de dados" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0013 — O que é análise de dados?

**Variantes:** Análise de dados: o que significa? · Me explica o que é análise de dados · oq é analise de dados · análise de dados? · Defina análise de dados

A análise de dados é um processo de inspeção, limpeza, transformação e modelagem de dados com o objetivo de descobrir informações úteis, informar conclusões e apoiar a tomada de decisões. A análise de dados tem múltiplas facetas e abordagens, abrangendo diversas técnicas sob uma variedade de nomes, e é usada em diferentes domínios dos negócios, ciências e ciências sociais. No mundo dos negócios de hoje, a análise de dados desempenha um papel tornando a tomada de decisões mais científicas e ajudando as empresas a operar com mais eficácia.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Análise de dados](https://pt.wikipedia.org/wiki/An%C3%A1lise_de_dados) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Análise de dados" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0014 — O que é computação em nuvem?

**Variantes:** Computação em nuvem: o que significa? · Me explica o que é computação em nuvem · oq é computacao em nuvem · computação em nuvem? · Defina computação em nuvem

Computação em nuvem é um termo coloquial para a disponibilidade sob demanda de recursos do sistema de computador, especialmente armazenamento de dados e capacidade de computação, sem o gerenciamento ativo direto do utilizador. O termo geralmente é usado para descrever centros de dados disponíveis para muitos utilizadores pela Internet. Nuvens em grande escala, predominantes hoje em dia, geralmente têm funções distribuídas em vários locais dos servidores centrais. Se a conexão com o utilizador for relativamente próxima, pode ser designado um servidor de borda.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Computação em nuvem](https://pt.wikipedia.org/wiki/Computa%C3%A7%C3%A3o_em_nuvem) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Computação em nuvem" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0015 — O que é algoritmo?

**Variantes:** Algoritmo: o que significa? · Me explica o que é algoritmo · oq é algoritmo · algoritmo? · Defina algoritmo

Em matemática e ciência da computação, um algoritmo é uma sequência finita de ações executáveis que visam obter uma solução para um determinado tipo de problema. Segundo Dasgupta, Papadimitriou e Vazirani; "Algoritmos são procedimentos precisos, não ambíguos, padronizados, eficientes e corretos.". As suas características são: finitas, o algoritmo deve eventualmente resolver o problema; bem definidas: os passos devem ser definidos de modo a serem entendidos; efetivas, deve sempre resolver o que tem para solucionar, antecipando falhas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Algoritmo](https://pt.wikipedia.org/wiki/Algoritmo) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Algoritmo" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0016 — O que é banco de dados?

**Variantes:** Banco de dados: o que significa? · Me explica o que é banco de dados · oq é banco de dados · banco de dados? · Defina banco de dados

Na informática, banco de dados (português brasileiro) ou base de dados (português europeu) é um conjunto de arquivos ou dados relacionados, contendo registros sobre pessoas, lugares ou informações em geral, normalmente acessíveis de maneira eletrônica. É um tipo de armazenamento de dados baseado no uso de um sistema de gerenciamento de banco de dados (DBMS) - um software que interage com usuários finais, aplicativos e com o próprio banco de dados, para captura e análise. O DBMS também abrange os recursos essenciais fornecidos para administrar o banco de dados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Banco de dados](https://pt.wikipedia.org/wiki/Banco_de_dados) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Banco de dados" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0017 — O que é internet?

**Variantes:** Internet: o que significa? · Me explica o que é internet · oq é internet · internet? · Defina internet

A Internet é um sistema global de redes de computadores interligadas que utilizam um conjunto próprio de protocolos (Internet Protocol Suite ou TCP/IP) com o propósito de servir progressivamente usuários no mundo inteiro. É uma rede de várias outras redes, que consiste de milhões de empresas privadas, públicas, acadêmicas e de governo, com alcance local e global e que está ligada por uma ampla variedade de tecnologias de rede eletrônica, sem fio e ópticas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Internet](https://pt.wikipedia.org/wiki/Internet) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Internet" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0018 — O que é automação?

**Variantes:** Automação: o que significa? · Me explica o que é automação · oq é automacao · automação? · Defina automação

Automação (do latim Automatus, que significa mover-se por si só) é um sistema automático pelo qual os mecanismos verificam seu próprio funcionamento, efetuando medições e introduzindo correções, sem a necessidade da interferência do homem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Automação](https://pt.wikipedia.org/wiki/Automa%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Automação" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0019 — O que é robótica?

**Variantes:** Robótica: o que significa? · Me explica o que é robótica · oq é robotica · robótica? · Defina robótica

Robótica é um ramo educacional e tecnológico que trata de sistemas compostos por partes mecânicas automáticas em conjunto com circuitos integrados, tornando sistemas mecânicos motorizados controlados por circuitos elétricos e inteligência computacional. A robótica é objeto de estudo de diversas áreas: computação, aeroespacial, mecânica, automação, elétrica, etc. Cada vez mais as pessoas utilizam os robôs para suas tarefas, como por exemplo o robô aspirador, e robôs para cirurgias médicas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Robótica](https://pt.wikipedia.org/wiki/Rob%C3%B3tica) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Robótica" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0020 — O que é gêmeo digital?

**Variantes:** Gêmeo digital: o que significa? · Me explica o que é gêmeo digital · oq é gemeo digital · gêmeo digital? · Defina gêmeo digital

Um gêmeo digital é uma representação virtual que serve como contrapartida digital em tempo real de um objeto ou processo físico. Embora o conceito tenha se originado anteriormente, a primeira definição prática de gêmeo digital surgiu da NASA em uma tentativa de melhorar a simulação de modelos físicos de espaçonaves em 2010. Os gêmeos digitais são o resultado da melhoria contínua na criação de projetos de produtos e atividades de engenharia. Desenhos de produto e especificações de engenharia progrediram de desenhos feitos à mão para desenhos auxiliados por computador e engenharia de sistemas baseada em modelo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Gêmeo digital](https://pt.wikipedia.org/wiki/G%C3%AAmeo_digital) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Gêmeo digital" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0021 — O que é blockchain?

**Variantes:** Blockchain: o que significa? · Me explica o que é blockchain · oq é blockchain · blockchain? · Defina blockchain

A blockchain (também conhecido como “cadeia de blocos”) é uma tecnologia de registro distribuído que visa a descentralização como medida de segurança. São bases de registros e dados distribuídos e compartilhados, que têm a função de criar um índice global para todas as transações que ocorrem em um determinado mercado. Funciona como um livro-razão, só que de forma pública, compartilhada e universal, permitindo mecanismos de consenso e confiança na comunicação direta entre duas partes, ou seja, sem o intermédio de terceiros. Está constantemente crescendo à medida que novos blocos são adicionados a ela por um novo conjunto de registros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Blockchain](https://pt.wikipedia.org/wiki/Blockchain) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Blockchain" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0022 — O que é computação de borda?

**Variantes:** Computação de borda: o que significa? · Me explica o que é computação de borda · oq é computacao de borda · computação de borda? · Defina computação de borda

Edge computing (em português, computação de borda) é um modelo de computação distribuída que aproxima a computação e o armazenamento de dados das fontes de dados. De forma mais ampla, refere-se a qualquer design que empurre a computação fisicamente para mais perto de um usuário, a fim de reduzir a latência em comparação a quando uma aplicação é executada em um data center centralizado. O termo começou a ser usado na década de 1990 para descrever redes de entrega de conteúdo (CDNs) — estas eram usadas para entregar conteúdo de sites e vídeos a partir de servidores localizados próximos aos usuários.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Computação de borda](https://pt.wikipedia.org/wiki/Computa%C3%A7%C3%A3o_de_borda) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Computação de borda" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0023 — O que é alucinação?

**Variantes:** Alucinação: o que significa? · Me explica o que é alucinação · oq é alucinacao · alucinação? · Defina alucinação

Na inteligência artificial (IA), uma alucinação ou alucinação artificial é uma resposta confiante por parte da IA que não parece ser justificada pelos dados de treinamento. Por exemplo, um chatbot alucinatório sem conhecimento sobre a receita de uma empresa de grande porte pode internamente escolher um número aleatório (como "US$ 13.6 bilhões") que o chatbot considere plausível, e então continuar a insistir falsa e repetidamente que a receita da referida empresa é de US$ 13.6 bilhões, sem sinal de consciência interna de que o número foi produto da própria imaginação deste.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Alucinação (inteligência artificial)](https://pt.wikipedia.org/wiki/Alucina%C3%A7%C3%A3o_(intelig%C3%AAncia_artificial)) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Alucinação (inteligência artificial)" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0024 — O que é engenharia de prompts?

**Variantes:** Engenharia de prompts: o que significa? · Me explica o que é engenharia de prompts · oq é engenharia de prompts · engenharia de prompts? · Defina engenharia de prompts

Engenharia de prompts é o processo de estruturar linguagem natural entradas (conhecidas como prompts) para produzir saídas especificadas de um modelo de inteligência artificial generativa. Engenharia de contexto é a área relacionada da engenharia de software que se concentra no gerenciamento dos contextos, relacionados ou não a prompts, fornecidos ao modelo de IA generativa, como instruções de sistema, metadados, ferramentas de API e tokens. Também pode ser definida como a prática de projetar e refinar instruções de entrada fornecidas a um modelo de IA generativa para produzir saídas mais precisas, relevantes ou úteis.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Engenharia de prompts](https://pt.wikipedia.org/wiki/Engenharia_de_prompts) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Engenharia de prompts" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0025 — O que é agente inteligente?

**Variantes:** Agente inteligente: o que significa? · Me explica o que é agente inteligente · oq é agente inteligente · agente inteligente? · Defina agente inteligente

Em inteligência artificial, um agente inteligente é uma entidade que identifica o seu ambiente, toma ações de forma autónoma para atingir objetivos e pode melhorar o seu desempenho através da aprendizagem automática ou adquirindo conhecimento. Os principais manuais de IA definem a inteligência artificial como o "estudo e design de agentes inteligentes", destacando que o comportamento orientado para objetivos é essencial para a inteligência.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Agente inteligente](https://pt.wikipedia.org/wiki/Agente_inteligente) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Agente inteligente" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0026 — O que são dados abertos?

**Variantes:** Dados abertos: o que significa? · Me explica o que são dados abertos · oq sao dados abertos · dados abertos? · Defina dados abertos

O conceito de dados abertos (open data) corresponde à ideia de que certos dados devem estar disponíveis para que todos usem e publiquem, sem restriçõs de direitos autorais e patentes ou outros mecanismos de controle. Segundo a Open Definition dados abertos são dados que podem ser livremente utilizados, reutilizados e redistribuídos por qualquer pessoa – sujeitos, no máximo, à exigência de atribuição à fonte original e ao compartilhamento pelas mesmas licenças em que as informações foram apresentadas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Dados abertos](https://pt.wikipedia.org/wiki/Dados_abertos) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Dados abertos" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0027 — O que é interface de programação de aplicações?

**Variantes:** Interface de programação de aplicações: o que significa? · Me explica o que é interface de programação de aplicações · oq é interface de programacao de aplicacoes · interface de programação de aplicações? · Defina interface de programação de aplicações

Em ciência da computação, a Interface de Programação de Aplicações (do inglês Application Programming Interface, abreviado API) é um conjunto de serviços/funções que foram implementadas em um programa de computador que são disponibilizados para que outros programas/aplicativos possam utiliza-los diretamente de forma simplificada; sem envolver-se em detalhes da implementação do programa de computador principal (função chamada de encapsulamento, usar as funcionalidades através de um código de programação simplificado).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Interface de programação de aplicações](https://pt.wikipedia.org/wiki/Interface_de_programa%C3%A7%C3%A3o_de_aplica%C3%A7%C3%B5es) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Interface de programação de aplicações" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0028 — O que é software como serviço?

**Variantes:** Software como serviço: o que significa? · Me explica o que é software como serviço · oq é software como servico · software como serviço? · Defina software como serviço

Software como serviço, do inglês Software as a service (SaaS), é uma forma de distribuição e comercialização de software via computação em nuvem. No modelo SaaS, o fornecedor do software se responsabiliza por toda a estrutura necessária à disponibilização do sistema (servidores, conectividade, cuidados com segurança da informação), e o cliente utiliza o software via internet, geralmente mediante assinatura ou outro modelo de cobrança. O SaaS desassocia a noção de posse do software do seu uso efetivo. Os sistemas de software geralmente são acessíveis a partir de vários dispositivos, por meio de um navegador web ou outro software instalado localmente.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Software como serviço](https://pt.wikipedia.org/wiki/Software_como_servi%C3%A7o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Software como serviço" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0029 — O que é transformação digital?

**Variantes:** Transformação digital: o que significa? · Me explica o que é transformação digital · oq é transformacao digital · transformação digital? · Defina transformação digital

Transformação digital pode ser definida como um fenômeno que incorpora o uso da tecnologia digital às soluções de problemas tradicionais. Assim, abrange mudanças procedurais em diversos âmbitos de uma sociedade, isto é, essa transformação modifica o paradigma da utilização da tecnologia, por exemplo, das seguintes áreas: governo, economia, mercado de trabalho, educação, medicina, artes, ciência, comunicação global, entre outros. Além disso, a transformação digital tem como capacidade aumentar a integração entre diferentes setores da sociedade, sendo aplicado em assuntos relacionados aos problemas de administração pública.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Transformação digital](https://pt.wikipedia.org/wiki/Transforma%C3%A7%C3%A3o_digital) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Transformação digital" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0030 — O que é indústria 4.0?

**Variantes:** Indústria 4.0: o que significa? · Me explica o que é indústria 4.0 · oq é industria 4.0 · indústria 4.0? · Defina indústria 4.0

Quarta Revolução Industrial ou Indústria 4.0 é um neologismo que descreve o rápido avanço tecnológico no século XXI. Ela segue a Terceira Revolução Industrial (a "Era da Informação"). O termo foi popularizado em 2016 por Klaus Schwab, fundador e presidente executivo do Fórum Econômico Mundial, que afirma que estes desenvolvimentos representam uma mudança significativa no capitalismo industrial. Uma parte desta fase de mudança industrial é a junção de tecnologias como a inteligência artificial, a edição genética e a robótica avançada que esbatem as linhas entre os mundos físico, digital e biológico.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Quarta Revolução Industrial](https://pt.wikipedia.org/wiki/Quarta_Revolu%C3%A7%C3%A3o_Industrial) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Quarta Revolução Industrial" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## Cibersegurança e LGPD

### TEC-WK-0031 — O que é segurança da informação?

**Variantes:** Segurança da informação: o que significa? · Me explica o que é segurança da informação · oq é seguranca da informacao · segurança da informação? · Defina segurança da informação

A segurança da informação (SI) está diretamente relacionada com proteção de um conjunto de informações, no sentido de preservar o valor que possuem para um indivíduo ou uma organização. São propriedades básicas da segurança da informação: confidencialidade, integridade, disponibilidade, autenticidade e legalidade. A SI não está restrita somente a sistemas computacionais, informações eletrônicas ou sistemas de armazenamento. O conceito aplica-se a todos os aspectos de proteção de informações e dados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Segurança da informação](https://pt.wikipedia.org/wiki/Seguran%C3%A7a_da_informa%C3%A7%C3%A3o) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Segurança da informação" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0032 — O que é segurança cibernética?

**Variantes:** Segurança cibernética: o que significa? · Me explica o que é segurança cibernética · oq é seguranca cibernetica · segurança cibernética? · Defina segurança cibernética

Segurança de computadores ou cibersegurança é a proteção de sistemas de computador contra roubo ou danos ao hardware, software ou dados eletrônicos, bem como a interrupção ou desorientação dos serviços que fornecem. O campo está crescendo em importância devido à crescente dependência de sistemas de computadores, internet e redes sem fio, como Bluetooth e Wi-Fi, e devido ao crescimento de dispositivos "inteligentes", incluindo smartphones, televisores e vários dispositivos pequenos que constituem a internet das coisas. Devido à sua complexidade, tanto em termos de política quanto de tecnologia, é também um dos maiores desafios do mundo contemporâneo.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Segurança computacional](https://pt.wikipedia.org/wiki/Seguran%C3%A7a_computacional) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Segurança computacional" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0033 — O que é phishing?

**Variantes:** Phishing: o que significa? · Me explica o que é phishing · oq é phishing · phishing? · Defina phishing

Phishing é uma técnica de engenharia social usada para enganar usuários de internet usando fraude eletrônica para obter informações confidenciais, como nome de usuário, senha e detalhes do cartão de crédito. São comunicações falsificadas praticada por criminosos chamados phishers que parecem vir de uma fonte confiável. Para cometer as fraudes os criminosos utilizam mensagens aparentemente reais. Os usuários geralmente são atraídos por comunicações que parecem vir de redes sociais, sites de leilões, bancos, processadores de pagamento on-line ou administradores de TI.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Phishing](https://pt.wikipedia.org/wiki/Phishing) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Phishing" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0034 — O que é ransomware?

**Variantes:** Ransomware: o que significa? · Me explica o que é ransomware · oq é ransomware · ransomware? · Defina ransomware

Na informática, o ransomware é um software malicioso usado para extorsão por meio de sequestro de dados digitais usando a criptografia; um crime-cibernético que usa como refém arquivos computacionais pessoais da própria vítima, cobrando assim um resgate para restabelecer o acesso a estes arquivos. Este resgate é cobrado em criptomoedas, que, na prática, o torna quase impossível de se rastrear o criminoso. Uma vez que o sistema esteja infectado, o ransomware irá criptografar, em segundo plano, dados sensíveis do usuário. Assim que concluído o processo, emitirá um aviso em tela informando sobre o bloqueio.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Ransomware](https://pt.wikipedia.org/wiki/Ransomware) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Ransomware" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0035 — O que é malware?

**Variantes:** Malware: o que significa? · Me explica o que é malware · oq é malware · malware? · Defina malware

Malware (uma aglutinação de malicious software, ou software malicioso) é qualquer software projetado intencionalmente para causar danos a um computador, servidor, cliente ou rede de computadores, vazar informações privadas, obter acesso não autorizado a informações ou sistemas, privar o acesso a informações ou interferir na segurança do computador e na privacidade do usuário sem o seu conhecimento. Pesquisadores tendem a classificar o malware em um ou mais subtipos (ou seja, vírus de computador, worms, cavalos de Troia, bombas lógicas, ransomware, spyware, adware, softwares rogue, wipers e keyloggers).[carece de fontes]?

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Malware](https://pt.wikipedia.org/wiki/Malware) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Malware" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0036 — O que é engenharia social?

**Variantes:** Engenharia social: o que significa? · Me explica o que é engenharia social · oq é engenharia social · engenharia social? · Defina engenharia social

A engenharia social, no contexto de segurança da informação, refere-se à manipulação psicológica de pessoas para a execução de ações ou para a divulgação de informações confidenciais. Esse é um termo que descreve um tipo psicotécnico de intrusão que depende fortemente da interação humana e envolve enganar outras pessoas para a quebra de procedimentos de segurança. Um ataque clássico na engenharia social é quando uma pessoa se passa por profissional de alto nível dentro das organizações, dizendo possuir problemas urgentes de acesso ao sistema, conseguindo assim o acesso a locais restritos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Engenharia social (segurança)](https://pt.wikipedia.org/wiki/Engenharia_social_(seguran%C3%A7a)) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Engenharia social (segurança)" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0037 — O que é autenticação de dois fatores?

**Variantes:** Autenticação de dois fatores: o que significa? · Me explica o que é autenticação de dois fatores · oq é autenticacao de dois fatores · autenticação de dois fatores? · Defina autenticação de dois fatores

Autenticação de dois fatores (também conhecida como verificação em duas etapas ou 2FA, do inglês two-factor authentication) é um método de autenticação que exige a combinação de dois componentes diferentes para confirmar a identidade de um usuário. Esses componentes podem ser algo que o usuário sabe, algo que o usuário possui ou algo que é inseparável do usuário (biometria). Um bom exemplo da vida cotidiana é a operação de saque em um terminal bancário de autoatendimento: apenas a combinação correta do cartão bancário (algo que o usuário possui) e da senha (algo que o usuário sabe) permite a operação ser completada.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Autenticação de dois fatores](https://pt.wikipedia.org/wiki/Autentica%C3%A7%C3%A3o_de_dois_fatores) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Autenticação de dois fatores" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0038 — O que é senha?

**Variantes:** Senha: o que significa? · Me explica o que é senha · oq é senha · senha? · Defina senha

Senha, palavra-passe, palavra-chave ou password é uma palavra ou código secreto previamente convencionado entre as partes como forma de reconhecimento. Em sistemas de computação, senhas são amplamente utilizadas para autenticar usuários e conceder-lhes privilégios — para agir como administradores de um sistema, por exemplo ou permitir-lhes o acesso a informações personalizadas armazenadas no sistema. Uma das referências mais antigas conhecidas ao uso de senhas é o incidente xibolete, narrado do Antigo Testamento. Senhas já eram usadas na Roma Antiga.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Senha](https://pt.wikipedia.org/wiki/Senha) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Senha" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0039 — O que é criptografia?

**Variantes:** Criptografia: o que significa? · Me explica o que é criptografia · oq é criptografia · criptografia? · Defina criptografia

Criptografia, ou criptologia (do grego antigo: κρυπτός, romanizado: kryptós "oculto, secreto"; e γράφειν graphein, "escrever", ou -λογία -logia, "estudo", respectivamente), é a prática e o estudo de técnicas para comunicação segura na presença de comportamento adversário. De forma mais geral, a criptografia trata da construção e análise de protocolos que impedem terceiros ou o público de ler mensagens privadas. A criptografia moderna existe na intersecção das disciplinas de matemática, ciência da computação, segurança da informação, engenharia elétrica, processamento de sinais digitais, física e outras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Criptografia](https://pt.wikipedia.org/wiki/Criptografia) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Criptografia" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0040 — O que é backup?

**Variantes:** Backup: o que significa? · Me explica o que é backup · oq é backup · backup? · Defina backup

Na informática, cópia de segurança é um termo utilizado para uma atividade que consiste em realizar cópias de segurança de dados digitais de um dispositivo, como fotos, documentos, softwares ou qualquer arquivo digital, com o intuito de recuperá-los em caso de perda dos dados originais, como apagamentos acidentais ou corrupção de dados. Meios de armazenamento de backups incluem CD-ROM, DVD, disco rígido, dispositivos USB, fitas magnéticas, servidores de armazenamento e na nuvem.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Cópia de segurança](https://pt.wikipedia.org/wiki/C%C3%B3pia_de_seguran%C3%A7a) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Cópia de segurança" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0041 — O que é pix?

**Variantes:** Pix: o que significa? · Me explica o que é pix · oq é pix · pix? · Defina pix

Pix (pronuncia-se pikz) é um modo de transferência monetária instantâneo e de pagamento eletrônico instantâneo em real brasileiro (R$). Oferecido pelo Banco Central do Brasil a pessoas físicas e jurídicas, funciona 24 horas ininterruptamente e é o mais recente meio de pagamento do Sistema de Pagamentos Brasileiro, sendo registrado como marca de alto renome pelo Instituto Nacional de Propriedade Intelectual (INPI).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Pix](https://pt.wikipedia.org/wiki/Pix) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Pix" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0042 — O que é Lei Geral de Proteção de Dados Pessoais?

**Variantes:** Lei Geral de Proteção de Dados Pessoais: o que significa? · Me explica o que é Lei Geral de Proteção de Dados Pessoais · oq é lei geral de protecao de dados pessoais · Lei Geral de Proteção de Dados Pessoais? · Defina Lei Geral de Proteção de Dados Pessoais

A Lei Geral de Proteção de Dados Pessoais (com sigla LGPD ou LGPDP), ou Lei nº 13.709/2018, é uma lei federal brasileira promulgada em 2018, que estabelece normas para a proteção e tratamento de dados pessoais em território nacional, bem como a proteção de direitos fundamentais, particularmente a privacidade, a honra e a intimidade. A LGPD também alterou os artigos 7º e 16º do chamado Marco Civil da Internet, lei federal que traz normas legais referentes ao uso da Internet no território brasileiro.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Lei Geral de Proteção de Dados Pessoais](https://pt.wikipedia.org/wiki/Lei_Geral_de_Prote%C3%A7%C3%A3o_de_Dados_Pessoais) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Lei Geral de Proteção de Dados Pessoais" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0043 — O que é Autoridade Nacional de Proteção de Dados?

**Variantes:** Autoridade Nacional de Proteção de Dados: o que significa? · Me explica o que é Autoridade Nacional de Proteção de Dados · oq é autoridade nacional de protecao de dados · Autoridade Nacional de Proteção de Dados? · Defina Autoridade Nacional de Proteção de Dados

A Agência Nacional de Proteção de Dados (ANPD) é uma Autarquia especial federal, vinculada ao Ministério da Justiça e Segurança Pública (MJSP), que possui atribuições relacionadas a proteção de dados pessoais e da privacidade, devendo, sobretudo, realizar a fiscalização do cumprimento da Lei Geral de Proteção de Dados Pessoais (Lei nº 13.709/2018)), conhecida também pela sigla LGPD. A Autoridade Nacional de Proteção de Dados (ANPD) foi oficialmente transformada em Agência Nacional de Proteção de Dados, mantendo a sigla ANPD, por meio da Medida Provisória nº 1.317/2025, publicada em 17 de setembro de 2025.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Agência Nacional de Proteção de Dados](https://pt.wikipedia.org/wiki/Ag%C3%AAncia_Nacional_de_Prote%C3%A7%C3%A3o_de_Dados) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Agência Nacional de Proteção de Dados" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0044 — O que são dados pessoais?

**Variantes:** Dados pessoais: o que significa? · Me explica o que são dados pessoais · oq sao dados pessoais · dados pessoais? · Defina dados pessoais

Informações pessoais ou Informações de identificação pessoal, termo usado em segurança da informação, referem-se a informações que podem ser usadas para identificar, contactar ou localizar uma única pessoa. Também podem ser usadas com outras fontes para identificar um único indivíduo. A abreviação em inglês PII é amplamente aceita, mas a frase que abrevia tem quatro variantes comuns com base em pessoal, pessoalmente, identificáveis e de identificação. Nem todas são equivalentes, e para os efeitos legais, entende eficazes variam de acordo com a competência ea finalidade para a qual o termo está sendo usado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Informação pessoal](https://pt.wikipedia.org/wiki/Informa%C3%A7%C3%A3o_pessoal) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Informação pessoal" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0045 — O que é Regulamento Geral sobre a Proteção de Dados?

**Variantes:** Regulamento Geral sobre a Proteção de Dados: o que significa? · Me explica o que é Regulamento Geral sobre a Proteção de Dados · oq é regulamento geral sobre a protecao de dados · Regulamento Geral sobre a Proteção de Dados? · Defina Regulamento Geral sobre a Proteção de Dados

O Regulamento Geral sobre a Proteção de Dados (RGPD) (UE) 2016/679 é um regulamento do direito europeu sobre privacidade e proteção de dados pessoais, aplicável a todos os indivíduos na União Europeia e Espaço Económico Europeu que foi criado em 2018. Regulamenta também a exportação de dados pessoais para fora da UE e EEE. O RGPD tem como objetivo dar aos cidadãos e residentes formas de controlar os seus dados pessoais e unificar o quadro regulamentar europeu.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Regulamento Geral sobre a Proteção de Dados](https://pt.wikipedia.org/wiki/Regulamento_Geral_sobre_a_Prote%C3%A7%C3%A3o_de_Dados) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Regulamento Geral sobre a Proteção de Dados" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0046 — O que é Marco Civil da Internet?

**Variantes:** Marco Civil da Internet: o que significa? · Me explica o que é Marco Civil da Internet · oq é marco civil da internet · Marco Civil da Internet? · Defina Marco Civil da Internet

O Marco Civil da Internet, oficialmente Lei n° 12 965, de 23 de abril 2014, é a norma legal que disciplina o uso da Internet no Brasil por meio da previsão de princípios, garantias, direitos e deveres para quem faz uso da rede, bem como da determinação de diretrizes para a atuação do Estado. O Marco Civil surgiu em 2009 no Poder Executivo, foi aprovado na Câmara dos Deputados em 25 de março de 2014, no Senado Federal em 22 de abril de 2014, e sancionado no dia seguinte pela então presidente Dilma Rousseff.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Marco Civil da Internet](https://pt.wikipedia.org/wiki/Marco_Civil_da_Internet) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Marco Civil da Internet" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0047 — O que é privacidade?

**Variantes:** Privacidade: o que significa? · Me explica o que é privacidade · oq é privacidade · privacidade? · Defina privacidade

Privacidade (calcado no inglês privacy) é o direito à reserva de informações pessoais e da própria vida pessoal: the right to be let alone (literalmente "o direito de ser deixado em paz"), segundo o jurista norte-americano Louis Brandeis, que foi provavelmente o primeiro a formular o conceito de direito à privacidade, juntamente com Samuel Warren. Brandeis inspirou-se na leitura da obra do filósofo Ralph Waldo Emerson, que propunha a solidão como critério e fonte de liberdade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* baixa
*Fontes:* [Wikipédia (pt) – Privacidade](https://pt.wikipedia.org/wiki/Privacidade) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Privacidade" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0048 — O que é cookie?

**Variantes:** Cookie: o que significa? · Me explica o que é cookie · oq é cookie · cookie? · Defina cookie

Um cookie, no âmbito do protocolo de comunicação HTTP usado na Internet, é um pequeno arquivo de computador ou pacote de dados enviados por um site da World Wide Web para o navegador do usuário, quando o utilizador visita o site. Cada vez que o usuário visita o site novamente, o navegador envia o cookie de volta para o servidor para notificar atividades prévias do usuário. Os cookies foram concebidos para serem um mecanismo confiável para que sítios se lembrem de informações da atividade do usuário, como senhas gravadas, itens adicionados no carrinho de compras em uma loja online, hiperligações que foram clicadas anteriormente, entre outros.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Cookie (informática)](https://pt.wikipedia.org/wiki/Cookie_(inform%C3%A1tica)) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Cookie (informática)" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0049 — O que é open banking?

**Variantes:** Open banking: o que significa? · Me explica o que é open banking · oq é open banking · open banking? · Defina open banking

Banco aberto, ou sistema bancário aberto ou partilhamento de dados bancários pessoais, é um termo da área de serviços financeiros, que é parte da tecnologia financeira, relativo a um conjunto de regras sobre o uso e compartilhamento de dados e informações financeiras entre instituições, que consiste em: Uso de APIs abertas que permitem a outros desenvolvedores (empresas, etc.) a criação de aplicações e serviços à volta de uma instituição financeira; Mais opções de transparência financeira para os correntistas, de dados abertos a dados privativos (por exemplo, os correntistas poderão aprovar que instituições terceiras tenham acesso a seus dados bancários e, com isso, poder-se-á concentrar toda a gestão das finanças num só aplicativo, site ou plataforma); Uso da técnica de código aberto para alcançar os objectivos supracitados.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* média
*Fontes:* [Wikipédia (pt) – Banco aberto](https://pt.wikipedia.org/wiki/Banco_aberto) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Banco aberto" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

### TEC-WK-0050 — O que é deepfake?

**Variantes:** Deepfake: o que significa? · Me explica o que é deepfake · oq é deepfake · deepfake? · Defina deepfake

Deepfake, uma amálgama de "deep learning" e "fake", é uma técnica de síntese de imagens ou sons humanos baseada em técnicas de inteligência artificial. Embora a criação de conteúdo falso a partir de ferramentas tecnológicas não seja novidade, os deepfakes utilizam de forma única técnicas de aprendizado de máquina e inteligência artificial, incluindo algoritmos de reconhecimento facial e redes neurais artificiais, como autoencoders variacionais (VAEs) e redes adversárias generativas (GANs).

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*Fontes:* [Wikipédia (pt) – Deepfake](https://pt.wikipedia.org/wiki/Deepfake) (acesso 2026-10-17)
*Notas:* Definição enciclopédica (introdução do verbete "Deepfake" da Wikipédia em português, resumida). Para números ou fatos recentes, preferir fontes oficiais. Se o usuário quiser detalhe técnico, buscar entradas Embrapa/MAPA relacionadas.

## LGPD

### TEC-LGPD-001 — O que é a LGPD?

**Variantes:** O que é a Lei Geral de Proteção de Dados? · lgpd oq é · lei de dados pessoais · Para que serve a LGPD?

A Lei Geral de Proteção de Dados Pessoais (LGPD), Lei nº 13.709/2018, regula o tratamento de dados pessoais por pessoas e empresas, públicas ou privadas, inclusive nos meios digitais. Ela define direitos dos titulares, bases legais para usar dados e responsabilidades de quem trata essas informações.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) (acesso 2026-10-17)
*Notas:* Lei consultada no Planalto em 17/10/2026. Não é aconselhamento jurídico.

### TEC-LGPD-002 — O que é dado pessoal sensível?

**Variantes:** Bah, uma dúvida: o que é dado pessoal sensível? · dado pessoal sensível? · o q e dado pessoal sensiel

Pela LGPD (art. 5º), dado pessoal sensível é aquele sobre origem racial ou étnica, convicção religiosa, opinião política, filiação a sindicato ou a organização religiosa, filosófica ou política, dado sobre saúde ou vida sexual, e dado genético ou biométrico, quando vinculado a uma pessoa natural. Esses dados têm regras de tratamento mais restritas.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* baixa
*Fontes:* [Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) (acesso 2026-10-17)
*Notas:* Lei consultada no Planalto em 17/10/2026. Não é aconselhamento jurídico.

### TEC-LGPD-003 — Quais são os direitos do titular de dados pela LGPD?

**Variantes:** Tu sabe me dizer: quais são os direitos do titular de dados pela LGPD? · direitos titular dados lgpd? · quais sao os direios do titular de dados pela lgpd

Pelo art. 18 da LGPD, o titular pode pedir ao controlador, a qualquer momento: confirmação de que há tratamento, acesso aos dados, correção de dados incompletos ou desatualizados, anonimização, bloqueio ou eliminação de dados desnecessários, portabilidade e eliminação dos dados tratados com consentimento, entre outros direitos.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) (acesso 2026-10-17)
*Notas:* Lei consultada no Planalto em 17/10/2026. Não é aconselhamento jurídico.

### TEC-LGPD-004 — Quando uma empresa pode usar meus dados pessoais?

**Variantes:** Tu sabe me dizer: quando uma empresa pode usar meus dados pessoais? · empresa usar meus dados pessoais? · quando uma empresa pode usar meus dados pessois

Pela LGPD (art. 7º), o tratamento de dados pessoais só pode ocorrer em hipóteses previstas na lei, como: com consentimento do titular; para cumprir obrigação legal; pela administração pública para políticas públicas; para estudos por órgão de pesquisa; e quando necessário para executar um contrato do qual o titular faz parte, entre outras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* baixa
*Fontes:* [Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) (acesso 2026-10-17)
*Notas:* Lei consultada no Planalto em 17/10/2026. Não é aconselhamento jurídico.

### TEC-LGPD-005 — Qual a multa da LGPD?

**Variantes:** Queria entender: qual a multa da LGPD? · multa lgpd?

Pelo art. 52 da LGPD, a multa simples pode chegar a 2% do faturamento da empresa, grupo ou conglomerado no Brasil no último exercício, excluídos os tributos, limitada a R$ 50 milhões por infração. A lei também prevê advertência, multa diária, publicização da infração e bloqueio ou eliminação dos dados, entre outras sanções.

*kind:* `dado` · *status:* `parcial` · *as_of:* 2018 · *relevância Fenasoja:* baixa
*Fontes:* [Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) (acesso 2026-10-17)
*Notas:* Lei consultada no Planalto em 17/10/2026. Não é aconselhamento jurídico. Sanções além da multa citadas de forma resumida; conferir o art. 52.

## Segurança digital

### TEC-SEG-001 — Como evitar golpes na internet?

**Variantes:** Dicas para não cair em golpe · como evitar golpe online · como n cair em golpe no zap · Golpe do falso ingresso, como evitar?

O CERT.br recomenda desconfiar de mensagens que pedem pressa, prometem vantagem boa demais ou usam ameaça, conferir o endereço (URL) dos sites antes de digitar dados, ter cuidado com QR codes e links recebidos, usar só aplicativos oficiais e ativar a verificação em duas etapas nas contas. Senhas fortes e diferentes para cada serviço também reduzem o risco.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* F26-005, VIS-005
*Fontes:* [CERT.br – Fascículo Golpes: não se deixe enganar](https://cartilha.cert.br/fasciculos/golpes/fasciculo-golpes.pdf) (acesso 2026-10-17); [CERT.br – Fascículo Golpes: evite fraudes](https://cartilha.cert.br/fasciculos/golpes-evite-fraudes/fasciculo-golpes-evite-fraudes.pdf) (acesso 2026-10-17); [CERT.br – Cartilha de Segurança para Internet](https://cartilha.cert.br/) (acesso 2026-10-17)
*Notas:* Orientações da Cartilha de Segurança para Internet do CERT.br (fascículos sobre golpes), consultadas em 17/10/2026. Para golpes envolvendo ingressos/estacionamento da Fenasoja, reforçar que canais oficiais estão no site fenasoja.com.br.

### TEC-SEG-002 — O que fazer se eu cair em um golpe?

**Variantes:** Tu sabe me dizer: o que fazer se eu cair em um golpe? · fazer cair golpe? · o q fazer se eu cair em um golpe

O CERT.br orienta: interromper o contato com o golpista, trocar as senhas das contas afetadas e ativar a verificação em duas etapas, avisar o banco imediatamente e, se o pagamento foi por Pix, pedir a contestação pelo Mecanismo Especial de Devolução (MED); em compras com cartão, contestar a cobrança. Também é recomendado registrar boletim de ocorrência e guardar provas (prints, comprovantes).

*kind:* `orientação` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [CERT.br – Fascículo Golpes: caiu? veja o que fazer](https://cartilha.cert.br/fasciculos/golpes-o-que-fazer/fasciculo-golpes-o-que-fazer.pdf) (acesso 2026-10-17)
*Notas:* Orientações da Cartilha de Segurança para Internet do CERT.br (fascículos sobre golpes), consultadas em 17/10/2026.

### TEC-SEG-003 — O que é verificação em duas etapas?

**Variantes:** Queria entender: o que é verificação em duas etapas? · verificação duas etapas? · o q e verificaao em duas etapas

Verificação em duas etapas (ou autenticação de dois fatores) é um recurso que exige, além da senha, uma segunda confirmação, como um código enviado ao celular ou gerado por aplicativo. O CERT.br recomenda ativá-la porque, mesmo que alguém descubra a senha, ainda precisará do segundo fator para entrar na conta.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [CERT.br – Cartilha de Segurança para Internet](https://cartilha.cert.br/) (acesso 2026-10-17); [CERT.br – Fascículo Golpes: evite fraudes](https://cartilha.cert.br/fasciculos/golpes-evite-fraudes/fasciculo-golpes-evite-fraudes.pdf) (acesso 2026-10-17)
*Notas:* Orientações da Cartilha de Segurança para Internet do CERT.br (fascículos sobre golpes), consultadas em 17/10/2026.

## Internet

### TEC-MCI-001 — O que é o Marco Civil da Internet?

**Variantes:** Uma pergunta: o que é o Marco Civil da Internet? · marco civil internet? · o q e o marco civil da interet

O Marco Civil da Internet (Lei nº 12.965/2014) estabelece princípios, garantias, direitos e deveres para o uso da internet no Brasil. Entre os direitos do usuário estão a inviolabilidade da intimidade e da vida privada, o sigilo das comunicações pela internet (salvo ordem judicial) e a não suspensão da conexão, salvo por débito decorrente do uso.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* baixa
*Fontes:* [Lei nº 12.965/2014 – Marco Civil da Internet (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/lei/l12965.htm) (acesso 2026-10-17)
*Notas:* Lei consultada no Planalto em 17/10/2026. Não é aconselhamento jurídico.

## IA na agricultura

### TEC-AGD-001 — O que é a Embrapa Agricultura Digital?

**Variantes:** Queria entender: o que é a Embrapa Agricultura Digital? · embrapa agricultura digital? · o q e a embrapa agricultra digital

A Embrapa Agricultura Digital é a unidade da Embrapa em Campinas (SP) dedicada a tecnologias digitais para o agro. Ela desenvolve ferramentas e APIs como o Zarc Plantio Certo, a API Agrofit (produtos registrados para controle de pragas) e a API Responde Agro, além de pesquisas com inteligência artificial.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*Fontes:* [Embrapa Agricultura Digital – portal](https://www.embrapa.br/agricultura-digital) (acesso 2026-10-17)
