# KB expandida — Bot Fenasoja (pt-BR)

Gerado em 2026-10-17 · versão 1.0. Complementa a KB Fenasoja ([../fenasoja-kb.md](../fenasoja-kb.md)); a KB Fenasoja tem prioridade em qualquer assunto da feira.

**Total: 2414 perguntas canônicas e 10889 perguntas (canônicas + variantes).**

## Totais por área

| Área | Canônicas | Perguntas | confirmado | parcial | sem_fonte | conflito | dinâmico | Arquivo |
|---|---|---|---|---|---|---|---|---|
| Agronegócio (AGRO) | 1527 | 6549 | 1475 | 50 | 0 | 0 | 2 | [md](por-area/agro.md) · [json](por-area/agro.json) |
| Feiras agropecuárias (FEIRAS) | 31 | 165 | 28 | 3 | 0 | 0 | 0 | [md](por-area/feiras.md) · [json](por-area/feiras.json) |
| Inovação e agtech (AGTECH) | 247 | 1103 | 247 | 0 | 0 | 0 | 0 | [md](por-area/agtech.md) · [json](por-area/agtech.json) |
| Tecnologia, IA, dados e segurança (TEC) | 60 | 341 | 59 | 1 | 0 | 0 | 0 | [md](por-area/tecnologia.md) · [json](por-area/tecnologia.json) |
| Mercado e economia (MERC) | 105 | 572 | 95 | 1 | 0 | 0 | 9 | [md](por-area/mercado.md) · [json](por-area/mercado.json) |
| Sustentabilidade (SUST) | 212 | 959 | 206 | 6 | 0 | 0 | 0 | [md](por-area/sustentabilidade.md) · [json](por-area/sustentabilidade.json) |
| Rio Grande do Sul, Noroeste/Missões e Santa Rosa (RS) | 225 | 1166 | 223 | 2 | 0 | 0 | 0 | [md](por-area/rs-regiao.md) · [json](por-area/rs-regiao.json) |
| FAQ geral do visitante (FAQ) | 7 | 34 | 4 | 0 | 3 | 0 | 0 | [md](por-area/faq-visitante.md) · [json](por-area/faq-visitante.json) |
| **Total** | **2414** | **10889** | 2337 | 63 | 3 | 0 | 11 | [kb-expandida.json](kb-expandida.json) · [csv](kb-expandida.csv) |

**Por kind:** conceito: 1847; dado: 371; orientação: 196

**Por tipo de fonte:** Embrapa – Coleção 500 Perguntas 500 Respostas: 1525; IBGE – SIDRA (API): 301; Curadoria manual sobre fontes oficiais: 109; Wikipédia (pt) – verbete: 479

**Por relevância para a Fenasoja:** alta: 1583; média: 638; baixa: 193

## Como ler os campos

- `kind`: **conceito** (explicação estável), **dado** (número/data: citar "segundo [fonte], em [as_of]"), **orientação** (recomendação prática; sugerir confirmar com profissional/organização).
- `status`: **confirmado** (sustentado pela fonte consultada), **parcial** (sustentado em parte, dado antigo ou detalhe não verificado), **sem_fonte** (nada confirma; o bot deve dizer que não há informação oficial), **conflito** (fontes divergem; nenhum caso nesta versão), **dinâmico** (valor volátil: nunca responder com número fixo, seguir `dynamic_instructions`).
- `as_of`: data/ano de referência do conteúdo (ano do livro da Embrapa, ano da pesquisa do IBGE, data da notícia/lei). `sources[].accessed` = data em que a fonte foi consultada (2026-10-17).
- `fenasoja_kb_links`: ids da KB Fenasoja relacionados (ex.: VIS-007, F28-004).

## Metodologia (resumo)

1. **Embrapa – Coleção 500 Perguntas 500 Respostas** (16 livros, PDFs baixados da Infoteca-e): perguntas e respostas extraídas do texto, filtradas por qualidade e relevância para o Noroeste gaúcho e recortadas do texto original (até 5 frases ou ~720 caracteres; trechos literais, sem paráfrase). Respostas com estatísticas viram `dado`/`parcial` com aviso de data.
2. **IBGE/SIDRA (API)**: produção agrícola municipal (PAM 2025), pecuária (PPM 2025), Censo 2022, para Brasil, RS e os 77 municípios da Região Intermediária de Ijuí (inclui a Região Imediata de Santa Rosa).
3. **Wikipédia (pt)**: introduções de verbetes para conceitos gerais (agro, mercado, tecnologia, sustentabilidade, RS/Missões). Fonte terciária: tratar como conceito introdutório.
4. **Curadoria manual** sobre fontes oficiais consultadas: leis no Planalto, MAPA, Embrapa, Agência Brasil, IDR-Paraná, FAESP, NOAA, CEPEA, BCB, CERT.br, Ministério da Saúde, Sebrae, sites oficiais das feiras, UNESCO, Fenasoja.
5. **Variantes** geradas por regras determinísticas a partir da pergunta canônica (coloquial com marcas gaúchas, forma curta por palavras-chave, versão sem acento/abreviada/com erro de digitação). Entradas manuais têm variantes escritas à mão.
6. **Validação**: ids únicos; perguntas canônicas duplicadas removidas; todas as 616 URLs citadas foram consultadas com HTTP 200 (páginas, APIs ou PDFs). Os números das respostas manuais foram conferidos contra o texto das fontes.

## Amostras por área

### Agronegócio

### AGRO-SOJ-0001 — Qual é a origem da soja?

**Variantes:** Me explica uma coisa: qual é a origem da soja? · origem soja? · qual e a origem da soja

A soja é originária da Ásia, mais provavelmente do nordeste da China, onde surgiu como uma planta rasteira, muito distinta da soja comercial que cultivamos hoje. Sua evolução iniciou-se, aparentemente, a partir de plantas oriundas de cruzamentos naturais entre duas espécies de soja selvagem, cujo produto foi domesticado e melhorado por cientistas da antiga China.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2019 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Soja: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2019), pergunta 1](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1118408/2/500PERGUNTASSojaed012019.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Soja: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1118408) (acesso 2026-10-17)

### AGRO-MIL-0336 — Quais os principais problemas que podem ocorrer durante o armazenamento do milho a granel?

**Variantes:** Alguém me explica: quais os principais problemas que podem ocorrer durante o armazenamento do milho a granel? · principais problemas ocorrer durante armazenamento milho granel? · quais os principais probleas q podem ocorrer durante o armazenamento do milho a granel

No armazenamento de milho a granel, seja em silos ou em grandes armazéns horizontais, podem ocorrer áreas com diferentes temperaturas, provocando a migração da umidade, e até mesmo a condensação da água na superfície. Portanto, a migração da umidade pode aumentar o risco de se criar condições ótimas para o desenvolvimento de insetos e fungos, favorecendo a deterioração dos grãos. A migração da umidade pode ser evitada fazendo-se a aeração dos grãos. A aeração consiste na movimentação forçada do ar através da massa de grãos, retirando-se o ar úmido e uniformizando a temperatura e a umidade.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2011 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Milho: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2011), pergunta 336](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/921542/1/500perguntasmilho.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Milho: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/921542) (acesso 2026-10-17)

### AGRO-SPD-0316 — Plantio direto: como funciona o controle de tráfego?

**Variantes:** Me tira uma dúvida: como funciona o controle de tráfego (plantio direto)? · controle tráfego (plantio direto)? · como funciona o contrle de trafego (plantio direto)

O controle de tráfego é efetuado por meio de marcações permanentes estabelecidas no terreno, normalmente em linhas retas, constituindo espécie de caminhos preferenciais dentro da lavoura, por onde devem movimentar-se máquinas e tratores. Essas marcações são anualmente mantidas por meio de escarificação, cuja intensidade é função da profundidade de compactação. Quando não há compactação, a escarificação é feita superficialmente e serve apenas para indicar a localização do caminho, na lavoura. Suas vantagens são o melhor controle da aplicação de insumos, maior controle da ocorrência e da distribuição de compactação na área.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 1998 · *relevância Fenasoja:* alta
*Fontes:* [Embrapa – Sistema plantio direto: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 1998), pergunta 316](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/98258/1/500perguntassistemaplantiodireto.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Sistema plantio direto: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/98258) (acesso 2026-10-17)

### Feiras agropecuárias

### FEIRAS-EXI-001 — O que é a Expointer?

**Variantes:** O que é a Expointer de Esteio? · expointer oq é · q feira é a expointer · Feira de Esteio

A Expointer (Exposição Internacional de Animais, Máquinas, Implementos e Produtos Agropecuários) é a principal feira agropecuária do Rio Grande do Sul, realizada pelo governo do estado no Parque de Exposições Assis Brasil, em Esteio, na Região Metropolitana de Porto Alegre. Reúne julgamentos e leilões de animais, máquinas agrícolas, agricultura familiar e artesanato.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* GER-015
*Fontes:* [Expointer – site oficial (Governo do RS)](https://www.expointer.rs.gov.br/) (acesso 2026-10-17); [Expointer – Expointer registra R$ 6,2 bi em negócios (06/09/2026)](https://www.expointer.rs.gov.br/expointer-registra-r-6-2-bi-em-negocios-sendo-r-14-4-milhoes-nos-509-estandes-da-agricultura-familiar) (acesso 2026-10-17)

### FEIRAS-AGS-001 — O que é a Agrishow?

**Variantes:** O que é Agrishow? · agrishow ribeirao preto · q feira é a agrishow · Agrishow 2026 números

A Agrishow se apresenta como a maior feira agropecuária do Brasil e uma das maiores do mundo, realizada em Ribeirão Preto (SP), com soluções para diversas culturas, máquinas e tecnologia para o campo. A edição de 2026, a 31ª, reuniu mais de 800 marcas e mais de 197 mil visitantes em 520 mil m².

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026 · *relevância Fenasoja:* média
*KB Fenasoja:* GER-015
*Fontes:* [Agrishow – site oficial](https://www.agrishow.com.br/) (acesso 2026-10-17)

### FEIRAS-BFS-001 — O que é a Bahia Farm Show?

**Variantes:** Me tira uma dúvida: o que é a Bahia Farm Show? · bahia farm show? · o q e a bahia farm show

A Bahia Farm Show é uma feira de tecnologia agrícola organizada pela Associação de Agricultores e Irrigantes da Bahia (Aiba) em Luís Eduardo Magalhães (BA). Em 2026, recebeu 172.328 visitantes, 554 expositores e 1.421 marcas; a 21ª edição está prevista para 7 a 12 de junho de 2027.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026 · *relevância Fenasoja:* baixa
*KB Fenasoja:* VIS-007, F28-004
*Fontes:* [Bahia Farm Show – site oficial](https://bahiafarmshow.com.br/) (acesso 2026-10-17)

### Inovação e agtech

### AGTECH-GEO-0014 — Quais satélites o Brasil tem em órbita?

**Variantes:** Queria entender: quais satélites o Brasil tem em órbita? · satélites brasil órbita? · quais satelies o brasil tem em orbita

O primeiro satélite brasileiro foi o SCD-1, lançado no nosso espaço aéreo em 9 de fevereiro de 1993, com 1 m de diâmetro e 1,45 m de altura. Ele pesa 115 kg e percorre uma órbita circular de 750 km de altitude. É equipado com baterias de níquel-cádmio recarregadas por painéis solares, formados por células de silício. O SCD-1 capta sinais de estações automáticas de coleta de dados ambientais distribuídas pelo Brasil, estimadas em mais de 750, e retransmite para a central de processamento. Os dados são usados na meteorologia, para prever o tempo ou para planejamento agrícola.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 14](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)

### AGTECH-GEO-0250 — Geotecnologias: como se estima a produção de sedimento de uma bacia hidrográfica?

**Variantes:** Uma pergunta: como se estima a produção de sedimento de uma bacia hidrográfica (geotecnologias)? · estima produção sedimento bacia hidrográfica (geotecnologias)? · como se estima a produao de sedimento de uma bacia hidrografica (geotecnologias)

Por meio de ferramentas que unem os sistemas de informação geográfica (SIG) aos modelos hidrossedimentológicos, possibilitando a espacialização da produção de sedimento de uma bacia hidrográfica. Um exemplo é a Equação Universal de Perda de Solos Modificada (Modified Universal Soil Loss Equation – MUSLE), que integra o modelo hidrológico Soil and Water Assessment Tool (SWAT). O SWAT simula diferentes processos físicos em bacia hidrográfica agrícola (evapotranspiração, infiltração, escoamento superficial, subsuperficial e subterrâneo). Para o ambiente SIG foi desenvolvida uma ferramenta específica para o modelo SWAT, denominada de ArcSWAT.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 250](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)

### AGTECH-GEO-0425 — O que é e o que representa o Sistema de Gestão Fundiária (SIGEF)?

**Variantes:** Tchê, me ajuda: o que é e o que representa o Sistema de Gestão Fundiária (SIGEF)? · representa sistema gestão fundiária sigef? · o q e e o q representa o sistema de gestao fundiaia (sigef)

O SIGEF é um sistema desenvolvido pelo Incra e pelo Ministério de Desenvolvimento Agrário (MDA) para a gestão de informações fundiárias do meio rural brasileiro, no qual serão efetuadas a recepção, a regularização e a disponibilização das informações georreferenciadas de limites dos imóveis rurais, públicos e privados, para certificação de dados e consequente subsídio à governança fundiária do território nacional.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2014 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2014), pergunta 425](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/988805/1/500P-Geotecnologias-e-geoinformacao-ed01-2014.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Geotecnologias e geoinformação: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/988805) (acesso 2026-10-17)

### Tecnologia, IA, dados e segurança

### TEC-LGPD-001 — O que é a LGPD?

**Variantes:** O que é a Lei Geral de Proteção de Dados? · lgpd oq é · lei de dados pessoais · Para que serve a LGPD?

A Lei Geral de Proteção de Dados Pessoais (LGPD), Lei nº 13.709/2018, regula o tratamento de dados pessoais por pessoas e empresas, públicas ou privadas, inclusive nos meios digitais. Ela define direitos dos titulares, bases legais para usar dados e responsabilidades de quem trata essas informações.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) (acesso 2026-10-17)

### TEC-LGPD-004 — Quando uma empresa pode usar meus dados pessoais?

**Variantes:** Tu sabe me dizer: quando uma empresa pode usar meus dados pessoais? · empresa usar meus dados pessoais? · quando uma empresa pode usar meus dados pessois

Pela LGPD (art. 7º), o tratamento de dados pessoais só pode ocorrer em hipóteses previstas na lei, como: com consentimento do titular; para cumprir obrigação legal; pela administração pública para políticas públicas; para estudos por órgão de pesquisa; e quando necessário para executar um contrato do qual o titular faz parte, entre outras.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* baixa
*Fontes:* [Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) (acesso 2026-10-17)

### TEC-SEG-001 — Como evitar golpes na internet?

**Variantes:** Dicas para não cair em golpe · como evitar golpe online · como n cair em golpe no zap · Golpe do falso ingresso, como evitar?

O CERT.br recomenda desconfiar de mensagens que pedem pressa, prometem vantagem boa demais ou usam ameaça, conferir o endereço (URL) dos sites antes de digitar dados, ter cuidado com QR codes e links recebidos, usar só aplicativos oficiais e ativar a verificação em duas etapas nas contas. Senhas fortes e diferentes para cada serviço também reduzem o risco.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* F26-005, VIS-005
*Fontes:* [CERT.br – Fascículo Golpes: não se deixe enganar](https://cartilha.cert.br/fasciculos/golpes/fasciculo-golpes.pdf) (acesso 2026-10-17); [CERT.br – Fascículo Golpes: evite fraudes](https://cartilha.cert.br/fasciculos/golpes-evite-fraudes/fasciculo-golpes-evite-fraudes.pdf) (acesso 2026-10-17); [CERT.br – Cartilha de Segurança para Internet](https://cartilha.cert.br/) (acesso 2026-10-17)

### Mercado e economia

### MERC-PS-001 — O que é o Plano Safra?

**Variantes:** Uma pergunta: o que é o Plano Safra? · plano safra? · o q e o plano safra

O Plano Safra é o pacote anual do governo federal que define o volume de recursos, as linhas e as taxas de juros do crédito rural para custeio, comercialização e investimento da agropecuária. Ele vale de julho de um ano a junho do seguinte e tem uma versão para a agricultura empresarial (médios e grandes produtores, pelo MAPA) e outra para a agricultura familiar (Pronaf, pelo MDA). No ciclo 2025/2026, foram R$ 516,2 bilhões para a agricultura empresarial e R$ 89 bilhões para a familiar.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2025-07-01 · *relevância Fenasoja:* alta
*Fontes:* [IDR-Paraná – Plano Safra nacional terá R$ 516,2 bilhões; agricultura familiar fica com R$ 89 bilhões (01/07/2025)](https://www.idrparana.pr.gov.br/Noticia/Plano-Safra-nacional-tera-R-5162-bilhoes-agricultura-familiar-fica-com-R-89-bilhoes) (acesso 2026-10-17); [Agência Brasil – Plano Safra 25/26 prevê R$ 89 bilhões para agricultura familiar (30/06/2025)](https://agenciabrasil.ebc.com.br/economia/noticia/2025-06/plano-safra-25-26-preve-rs-89-bilhoes-para-agricultura-familiar) (acesso 2026-10-17); [MAPA – Plano Safra 2025/2026: + Infraestrutura](https://www.gov.br/agricultura/pt-br/assuntos/politica-agricola/plano-safra/2025-2026/infraestrutura) (acesso 2026-10-17)

### MERC-CPR-002 — O que é o Fiagro?

**Variantes:** Me explica uma coisa: o que é o Fiagro? · fiagro? · o q e o fiagro

O Fiagro (Fundos de Investimento nas Cadeias Produtivas Agroindustriais) foi criado pela Lei nº 14.130/2021, que alterou a lei dos fundos imobiliários para permitir fundos que investem em imóveis rurais, participações em empresas do agro, ativos financeiros e títulos de crédito do agronegócio (como CRA e CPR). Assim, investidores podem aplicar no setor agropecuário por meio de cotas negociadas no mercado.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [Lei nº 14.130/2021 – Fiagro (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/L14130.htm) (acesso 2026-10-17)

### MERC-DYN-004 — Qual o preço do boi gordo hoje?

**Variantes:** preço da arroba do boi · boi gordo hoje · qto ta a arroba · cotação do gado

A cotação do boi gordo muda diariamente. A referência nacional é o Indicador do Boi Gordo CEPEA/B3 (base São Paulo), em R$ por arroba; no RS há também cotações regionais divulgadas pela Emater/RS. Consultar ao vivo.

*kind:* `dado` · *status:* `dinâmico` · *as_of:* — · *relevância Fenasoja:* média
*Fontes:* [CEPEA/Esalq-USP – Indicador do Boi Gordo](https://www.cepea.org.br/br/indicador/boi-gordo.aspx) (acesso 2026-10-17); [Emater/RS-Ascar – portal](https://www.emater.tche.br/site/) (acesso 2026-10-17)
*Instrução dinâmica:* Dado volátil: NUNCA responder com valor fixo da base. Consultar a fonte ao vivo e informar data/hora; se não houver acesso ao vivo, explicar onde consultar.

### Sustentabilidade

### SUST-ILPF-0001 — O que é integração lavoura-pecuária-floresta (ILPF)?

**Variantes:** Me explica uma coisa: o que é integração lavoura-pecuária-floresta (ILPF)? · integração lavoura-pecuária-floresta ilpf? · o q e integraao lavoura-pecuaria-floresta (ilpf)

É um sistema de produção sustentável que integra atividades agrícolas, pecuárias e florestais, realizadas na mesma área, em cultivo consorciado, em sucessão ou em rotação, e busca efeitos sinérgicos entre os componentes do agroecossistema, contemplando a adequação ambiental, a valorização do homem e a viabilidade econômica da atividade agropecuária.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 1](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)

### SUST-ILPF-0161 — Quais são as principais opções de sucessão ou rotação de culturas existentes para o sistema de ILP na região Sul?

**Variantes:** Queria entender: quais são as principais opções de sucessão ou rotação de culturas existentes para o sistema de ILP na região Sul? · principais opções sucessão rotação culturas existentes sistema? · quais sao as principais opcoes de sucessao ou rotacao de culturas existenes pra o sistema de ilp na regiao sul

No contexto atual, o cenário mais encontrado na região subtropical é o cultivo de aveia-preta, aveia-branca (Avena sativa) ou aveia + azevém, implantados após a colheita da soja ou do milho de verão. Como a rotação de culturas ocorre apenas em pequeno percentual da área, na primavera, após o período de pastejo, a soja retorna à área e isso caracteriza uma sucessão de culturas. Em áreas com rotação de culturas, a principal opção para rotação com a soja é o milho de verão. Com menor área cultivada, o feijão entra como uma opção de cultivo de verão, que, por ter ciclo curto em relação à soja e ao milho, proporciona mais tempo à produção forrageira de inverno.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* alta
*KB Fenasoja:* SOJ-015
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 161](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)

### SUST-ILPF-0274 — Quanto tempo se pode pastejar áreas implantadas em sistema de ILP nas terras baixas sem afetar o bom desempenho de forrageiras temperadas/subtropicais?

**Variantes:** Me explica uma coisa: quanto tempo se pode pastejar áreas implantadas em sistema de ILP nas terras baixas sem afetar o bom desempenho de forrageiras temperadas/subtropicais? · tempo pastejar áreas implantadas sistema ilp terras? · quanto tempo se pode pastear areas implantadas em sistema de ilp nas terras baixas sem afetar o bom desempenho de forrageiras temperadas/subtropicais

No primeiro inverno, após a implantação das pastagens na sucessão da cultura do arroz, o início do pastejo poderá ocorrer entre 40 e 60 dias após a semeadura das forrageiras (maio-junho), desde que sejam observadas as recomendações técnicas de incorporação da palhada do arroz, drenagem do terreno e recuperação da fertilidade do solo. Quando não são observadas essas recomendações, o início do pastejo vai ocorrer entre 120 e 150 dias após a semeadura, o que se dará entre agosto e setembro. Nesse primeiro ano, o tempo de pastejo poderá ser de 60 ou de 120 dias ou mais, em razão do manejo empregado pelos produtores.

*kind:* `conceito` · *status:* `confirmado` · *as_of:* 2015 · *relevância Fenasoja:* média
*Fontes:* [Embrapa – Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde (Coleção 500 Perguntas 500 Respostas, 2015), pergunta 274](https://www.infoteca.cnptia.embrapa.br/infoteca/bitstream/doc/1019632/2/500-perguntas-integracao-lavoura-pecuaria.pdf) (acesso 2026-10-17); [Infoteca-e Embrapa – registro do livro "Integração lavoura-pecuária-floresta: o produtor pergunta, a Embrapa responde"](https://www.infoteca.cnptia.embrapa.br/infoteca/handle/doc/1019632) (acesso 2026-10-17)

### Rio Grande do Sul, Noroeste/Missões e Santa Rosa

### RS-IBGE-TOPMUN-SOJ — Quais municípios gaúchos mais produzem soja?

**Variantes:** Qual o maior município produtor de soja do RS? · ranking municípios soja rs · qual cidade do rs produz mais soja · Maiores produtores de soja no Rio Grande do Sul por município

Segundo a PAM/IBGE de 2025, os 10 maiores produtores de soja do RS foram: 1º Palmeira das Missões (322,5 mil toneladas); 2º Dom Pedrito (318,3 mil toneladas); 3º Vacaria (238,0 mil toneladas); 4º Cruz Alta (225,5 mil toneladas); 5º Cachoeira do Sul (223,1 mil toneladas); 6º Tupanciretã (207,0 mil toneladas); 7º São Gabriel (198,0 mil toneladas); 8º Júlio de Castilhos (186,3 mil toneladas); 9º Muitos Capões (184,8 mil toneladas); 10º Santa Bárbara do Sul (178,4 mil toneladas).

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2025 · *relevância Fenasoja:* alta
*KB Fenasoja:* SR-007
*Fontes:* [IBGE – Produção Agrícola Municipal (PAM), Tabela 5457 – API SIDRA](https://apisidra.ibge.gov.br/values/t/5457/n6/in%20n3%2043/v/214/p/last/c782/40124,40122,40127,40102) (acesso 2026-10-17); [IBGE – metadados da Tabela 5457 (PAM)](https://servicodados.ibge.gov.br/api/v3/agregados/5457/metadados) (acesso 2026-10-17)

### RS-IBGE-POP-4307831 — Quantos habitantes tem Eugênio de Castro (RS)?

**Variantes:** Qual a população de Eugênio de Castro? · população Eugênio de Castro rs · qtos habitantes tem eugenio de castro · Eugênio de Castro é uma cidade grande?

Segundo o Censo Demográfico 2022 do IBGE, Eugênio de Castro tinha 2.633 habitantes. O município pertence à Região Geográfica Imediata de Santo Ângelo, dentro da Região Intermediária de Ijuí, no Noroeste do RS.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2022 · *relevância Fenasoja:* alta
*Fontes:* [IBGE – Censo Demográfico 2022, Tabela 9514 (população residente) – API SIDRA](https://apisidra.ibge.gov.br/values/t/9514/n6/4300208,4300307,4300455,4301503,4301859,4302204,4302378,4302501,4302584,4302600,4303301,4303707,4304002,4304309,4305009,4305207,4305405,4305702,4305871,4305900,4306007,4306320,4306353,4306734,4306932,4307450,4307831,4308656,4309001,4309506,4309605,4309704,4310207,4310405,4310413,4311155,4312179,4312302,4313011,4313334,4313425,4313904,4314308,4314555,4315008,4315057,4315073,4315107,4315404,4315958,4316303,4316477,4317202,4317509,4317707,4317806,4317905,4318499,4318903,4319109,4319158,4319208,4319307,4319372,4319737,4320230,4320321,4320578,4321402,4321477,4321808,4321907,4322103,4322301,4322343,4323705,4323754/v/93/p/2022/c2/6794/c287/100362/c286/113635) (acesso 2026-10-17); [IBGE – API de Localidades: municípios da Região Geográfica Intermediária de Ijuí](https://servicodados.ibge.gov.br/api/v1/localidades/regioes-intermediarias/4305/municipios) (acesso 2026-10-17)

### RS-IBGE-POP-4317806 — Quantos habitantes tem Santo Augusto (RS)?

**Variantes:** Qual a população de Santo Augusto? · população Santo Augusto rs · qtos habitantes tem santo augusto · Santo Augusto é uma cidade grande?

Segundo o Censo Demográfico 2022 do IBGE, Santo Augusto tinha 13.902 habitantes. O município pertence à Região Geográfica Imediata de Ijuí, dentro da Região Intermediária de Ijuí, no Noroeste do RS.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2022 · *relevância Fenasoja:* média
*Fontes:* [IBGE – Censo Demográfico 2022, Tabela 9514 (população residente) – API SIDRA](https://apisidra.ibge.gov.br/values/t/9514/n6/4300208,4300307,4300455,4301503,4301859,4302204,4302378,4302501,4302584,4302600,4303301,4303707,4304002,4304309,4305009,4305207,4305405,4305702,4305871,4305900,4306007,4306320,4306353,4306734,4306932,4307450,4307831,4308656,4309001,4309506,4309605,4309704,4310207,4310405,4310413,4311155,4312179,4312302,4313011,4313334,4313425,4313904,4314308,4314555,4315008,4315057,4315073,4315107,4315404,4315958,4316303,4316477,4317202,4317509,4317707,4317806,4317905,4318499,4318903,4319109,4319158,4319208,4319307,4319372,4319737,4320230,4320321,4320578,4321402,4321477,4321808,4321907,4322103,4322301,4322343,4323705,4323754/v/93/p/2022/c2/6794/c287/100362/c286/113635) (acesso 2026-10-17); [IBGE – API de Localidades: municípios da Região Geográfica Intermediária de Ijuí](https://servicodados.ibge.gov.br/api/v1/localidades/regioes-intermediarias/4305/municipios) (acesso 2026-10-17)

### FAQ geral do visitante

### FAQ-GER-001 — Como se proteger do calor em uma feira ao ar livre?

**Variantes:** Dicas para o calor na feira · como evitar insolação · ta mt quente, oq fazer · Protetor solar na Fenasoja

O Ministério da Saúde recomenda evitar a exposição ao sol entre 10h e 16h, usar roupas leves e claras, chapéu e protetor solar com FPS acima de 30, beber água ao longo do dia mesmo sem sede e moderar o consumo de bebidas alcoólicas. Sinais como tontura, dor de cabeça, náusea e pele muito quente podem indicar problema causado pelo calor e exigem procurar atendimento.

*kind:* `orientação` · *status:* `confirmado` · *as_of:* — · *relevância Fenasoja:* alta
*KB Fenasoja:* VIS-008
*Fontes:* [Ministério da Saúde (BVS) – Como se proteger das altas temperaturas](https://bvsms.saude.gov.br/saiba-como-se-proteger-das-altas-temperaturas-e-da-baixa-umidade-do-ar-no-pais/) (acesso 2026-10-17); [Ministério da Saúde – Insolação](https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/i/insolacao) (acesso 2026-10-17)

### FAQ-GER-003 — Quando será a próxima Fenasoja?

**Variantes:** Quando é a Fenasoja 2028? · proxima fenasoja data · qdo vai ser a fenasoja · Data da Fenasoja

A próxima Fenasoja será de 28 de abril a 7 de maio de 2028, no Parque de Exposições de Santa Rosa. Programação, atrações e ingressos ainda devem ser confirmados no site oficial fenasoja.com.br.

*kind:* `dado` · *status:* `confirmado` · *as_of:* 2026-10-17 · *relevância Fenasoja:* alta
*KB Fenasoja:* F28-001, F28-007, F28-008
*Fontes:* [Fenasoja – Definidas data e comissão central da Fenasoja 2028](https://fenasoja.com.br/portal-oficial/geral/definidas-data-e-comissao-central-da-fenasoja-2028/) (acesso 2026-10-17)

### FAQ-SF-001 — Posso levar meu cachorro na Fenasoja?

**Variantes:** Pode entrar com pet na Fenasoja? · cachorro na fenasoja · posso leva meu dog na feira? · Animais de estimação são permitidos?

SEM FONTE CONFIRMADA. Não encontramos nas fontes oficiais consultadas uma regra sobre entrada de animais de estimação no parque. A orientação é perguntar à organização pelos contatos oficiais antes da visita.

*kind:* `orientação` · *status:* `sem_fonte` · *as_of:* — · *relevância Fenasoja:* média
*KB Fenasoja:* VIS-005, F26-013
*Fontes:* [Fenasoja – Contato](https://fenasoja.com.br/contato/) (acesso 2026-10-17)
*Lacunas:* Regra de pets no parque não localizada.

## Outros arquivos

- [lacunas-expandida.md](lacunas-expandida.md) — lacunas, itens parciais/sem fonte, fontes que falharam.
- [prompt-integracao-kb-expandida.md](prompt-integracao-kb-expandida.md) — prompt (modo plano) para integrar ao bot.
- `src/` scripts de geração; `raw/` dados e textos brutos consultados.